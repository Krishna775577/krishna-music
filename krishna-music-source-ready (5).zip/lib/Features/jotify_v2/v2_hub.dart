import 'dart:math' as math;
import 'dart:async';
import 'dart:io';

import 'package:audio_service/audio_service.dart';
import 'package:flutter/material.dart';
import 'package:get_it/get_it.dart';
import 'package:hive/hive.dart';
import 'package:jotify/CustomWidgets/equalizer.dart';
import 'package:jotify/Features/jotify_v2/v2_library.dart';
import 'package:jotify/Helpers/lyrics.dart';
import 'package:jotify/Screens/Player/audioplayer.dart';
import 'package:jotify/Screens/Search/search.dart';
import 'package:jotify/Screens/Settings/app_ui.dart';
import 'package:jotify/Screens/Settings/music_playback.dart';
import 'package:jotify/Screens/Settings/theme.dart';
import 'package:jotify/Services/player_service.dart';

/// V2 builds on existing working audio providers. No new dependencies.
class JotifyV2Hub extends StatefulWidget {
  const JotifyV2Hub({super.key});

  @override
  State<JotifyV2Hub> createState() => _JotifyV2HubState();
}

class _JotifyV2HubState extends State<JotifyV2Hub> {
  final _search = TextEditingController();
  String _mood = 'Bhakti';
  int _sleepMinutes = 30;
  bool _working = false;
  late final AudioPlayerHandler _audio = GetIt.I<AudioPlayerHandler>();
  Box get _settings => Hive.box('settings');

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  void _open(Widget screen) {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => screen));
  }

  void _info(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> _playMood() async {
    final songs = V2Library.moodMix(_mood);
    if (songs.isEmpty) {
      _info('Save or play some songs first to build your personal mood mix.');
      return;
    }
    setState(() => _working = true);
    try {
      await PlayerInvoke.init(songsList: songs, index: 0);
    } catch (error) {
      _info('This mix could not start: $error');
    } finally {
      if (mounted) setState(() => _working = false);
    }
  }

  Future<void> _saveMix(String label, List<Map<String, dynamic>> songs) async {
    try {
      final name = await V2Library.saveAutoMix(label, songs);
      _info('Saved "$name" in Your Playlists.');
    } catch (error) {
      _info('Could not save mix: $error');
    }
  }

  Widget _section(String title, IconData icon, Widget content, {String? subtitle}) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
      child: Padding(
        padding: const EdgeInsets.all(17),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              Icon(icon, color: Theme.of(context).colorScheme.secondary),
              const SizedBox(width: 10),
              Expanded(child: Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800))),
            ]),
            if (subtitle != null) ...[
              const SizedBox(height: 5),
              Text(subtitle, style: Theme.of(context).textTheme.bodySmall),
            ],
            const SizedBox(height: 13),
            content,
          ],
        ),
      ),
    );
  }

  Widget _action(String label, VoidCallback onPressed, {IconData icon = Icons.arrow_forward}) =>
      OutlinedButton.icon(onPressed: onPressed, icon: Icon(icon, size: 18), label: Text(label));

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final recent = V2Library.recent;
    final favorites = V2Library.favorites;
    final topSongs = V2Library.topSongs;
    final words = V2Library.spellingVariants(_search.text);
    return Scaffold(
      appBar: AppBar(title: const Text('Jotify V2 Studio')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(14, 12, 14, 32),
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(24),
              gradient: LinearGradient(colors: [colors.secondary.withOpacity(.38), colors.surface]),
            ),
            child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Your music. Your vibe.', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
              SizedBox(height: 5),
              Text('Personal mixes, listening DNA, and premium controls — powered by your own library.'),
            ]),
          ),
          const SizedBox(height: 20),
          _section('Jotify Vibes — Mood DJ', Icons.auto_awesome_rounded,
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Wrap(spacing: 7, runSpacing: 6, children: V2Library.moodWords.keys.map((mood) =>
                ChoiceChip(label: Text(mood), selected: mood == _mood,
                  onSelected: (_) => setState(() => _mood = mood))).toList()),
              const SizedBox(height: 10),
              Text('${V2Library.moodMix(_mood).length} saved/recent songs in this mix',
                style: Theme.of(context).textTheme.bodySmall),
              const SizedBox(height: 9),
              Wrap(spacing: 8, runSpacing: 4, children: [
                FilledButton.icon(onPressed: _working ? null : _playMood,
                  icon: const Icon(Icons.play_arrow), label: const Text('Play mood mix')),
                _action('Save playlist', () => _saveMix(_mood, V2Library.moodMix(_mood)),
                  icon: Icons.playlist_add),
              ]),
            ]),
            subtitle: 'Uses song titles, genre tags and favorites on your device. No paid AI API.'),
          _section('Advanced Smart Search', Icons.manage_search_rounded,
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              TextField(
                controller: _search,
                decoration: InputDecoration(
                  hintText: 'Song or artist, e.g. Khama Ray Khama',
                  prefixIcon: const Icon(Icons.search),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
                  suffixIcon: IconButton(icon: const Icon(Icons.arrow_forward), onPressed: () {
                    if (_search.text.trim().isNotEmpty) _open(SearchPage(query: _search.text.trim(), searchType: 'saavn'));
                  }),
                ),
                textInputAction: TextInputAction.search,
                onSubmitted: (q) { if (q.trim().isNotEmpty) _open(SearchPage(query: q.trim(), searchType: 'saavn')); },
                onChanged: (_) => setState(() {}),
              ),
              if (words.isNotEmpty) ...[
                const SizedBox(height: 8),
                Wrap(spacing: 5, runSpacing: 3, children: words.map((v) =>
                  ActionChip(label: Text(v), onPressed: () => _open(SearchPage(query: v, searchType: 'saavn')))).toList()),
              ],
            ]),
            subtitle: 'Search Saavn with suggested alternate spellings. Your existing search pagination stays intact.'),
          _section('Jotify DNA — Listening Stats', Icons.bar_chart_rounded,
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Wrap(spacing: 16, runSpacing: 10, children: [
                _metric('Total plays', '${V2Library.totalPlays}'),
                _metric('Unique tracks', '${topSongs.length}'),
                _metric('Saved songs', '${favorites.length}'),
              ]),
              const SizedBox(height: 12),
              if (V2Library.topArtists.isEmpty)
                const Text('Your artist chart grows as you listen to songs in Jotify.')
              else
                ...V2Library.topArtists.take(4).map((entry) => Padding(
                  padding: const EdgeInsets.symmetric(vertical: 3),
                  child: Row(children: [Expanded(child: Text(entry.key, overflow: TextOverflow.ellipsis)),
                    Text('${entry.value} plays')]),
                )),
            ]),
            subtitle: 'Real play counts from existing local statistics; no invented listening minutes.'),
          _section('Automatic Playlists', Icons.queue_music_rounded,
            Wrap(spacing: 8, runSpacing: 5, children: [
              _action('Favorites Mix (${favorites.length})', () => _saveMix('Favorites', favorites), icon: Icons.favorite),
              _action('Recently Played (${recent.length})', () => _saveMix('Recent', recent), icon: Icons.history),
            ]), subtitle: 'Creates actual saved playlists; never overwrites an existing playlist.'),
          _section('Motion Player + Visualizer', Icons.graphic_eq,
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              SwitchListTile.adaptive(
                contentPadding: EdgeInsets.zero,
                title: const Text('Enable motion preview'),
                subtitle: const Text('Smooth animated bars; this is a visual animation, not audio FFT.'),
                value: _settings.get('v2Motion', defaultValue: true) == true,
                onChanged: (v) { _settings.put('v2Motion', v); setState(() {}); },
              ),
              _action('Open Motion Player', () => _open(const JotifyMotionPlayer()), icon: Icons.play_circle),
            ])),
          _section('Lyrics Studio', Icons.lyrics_outlined,
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              SwitchListTile.adaptive(
                contentPadding: EdgeInsets.zero,
                title: const Text('Look up lyrics online'),
                value: _settings.get('getLyricsOnline', defaultValue: true) == true,
                onChanged: (v) { _settings.put('getLyricsOnline', v); setState(() {}); },
              ),
              _action('Open Lyrics Studio', () => _open(const JotifyLyricsStudio()), icon: Icons.article_outlined),
            ]), subtitle: 'Lyrics depend on third-party availability/rights; synced display remains in the classic player.'),
          _section('Smart Sleep Timer', Icons.bedtime_outlined,
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Wrap(spacing: 6, children: [10, 20, 30, 45, 60].map((n) =>
                ChoiceChip(label: Text('$n min'), selected: _sleepMinutes == n,
                  onSelected: (_) => setState(() => _sleepMinutes = n))).toList()),
              const SizedBox(height: 8),
              Wrap(spacing: 8, children: [
                FilledButton(onPressed: () async {
                  await _audio.customAction('sleepTimer', {'time': _sleepMinutes});
                  _info('Sleep timer set for $_sleepMinutes minutes.');
                }, child: const Text('Start timer')),
                _action('Cancel timer', () async {
                  await _audio.customAction('sleepTimer', {'time': 0});
                  _info('Sleep timer canceled.');
                }, icon: Icons.close),
              ]),
            ]), subtitle: 'Uses Jotify’s existing playback sleep timer, including while the app is in the background.'),
          _section('Gesture Controls', Icons.swipe,
            Column(children: [
              _toggle('Player swipe gestures', 'enableGesture', true),
              _toggle('Volume swipe gestures', 'volumeGestureEnabled', false),
              _action('Advanced UI controls', () => _open(const AppUIPage()), icon: Icons.tune),
            ])),
          _section('Smart Audio Settings', Icons.tune,
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Wrap(spacing: 8, runSpacing: 5, children: [
                _action('Streaming quality', () => _open(const MusicPlaybackPage()), icon: Icons.high_quality),
                _action('Equalizer', () => showDialog<void>(context: context,
                  builder: (_) => const Equalizer()), icon: Icons.equalizer),
              ]),
              const SizedBox(height: 7),
              Text('Existing quality and equalizer controls. Crossfade and loudness normalization require separate audio-engine testing.',
                style: Theme.of(context).textTheme.bodySmall),
            ])),
          _section('Themes Studio', Icons.palette_outlined,
            _action('Open premium themes & gradients', () => _open(const ThemePage()), icon: Icons.color_lens_outlined),
            subtitle: 'Keeps Classic plus the original customizable colors/gradients and premium presets.'),
        ],
      ),
    );
  }

  Widget _metric(String label, String value) => Container(
    padding: const EdgeInsets.symmetric(vertical: 9, horizontal: 12),
    decoration: BoxDecoration(borderRadius: BorderRadius.circular(14), color: Theme.of(context).colorScheme.secondary.withOpacity(.08)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(value, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 22)),
      Text(label, style: Theme.of(context).textTheme.bodySmall),
    ]),
  );

  Widget _toggle(String title, String key, bool fallback) => SwitchListTile.adaptive(
    title: Text(title), contentPadding: EdgeInsets.zero,
    value: _settings.get(key, defaultValue: fallback) == true,
    onChanged: (v) { _settings.put(key, v); setState(() {}); },
  );
}

/// A lightweight animation that follows the existing audio handler state.
/// It never opens extra audio decoders, so Saavn playback is unchanged.
class JotifyMotionPlayer extends StatefulWidget {
  const JotifyMotionPlayer({super.key});
  @override
  State<JotifyMotionPlayer> createState() => _JotifyMotionPlayerState();
}

class _JotifyMotionPlayerState extends State<JotifyMotionPlayer> with SingleTickerProviderStateMixin {
  late final AnimationController _motion;
  late final StreamSubscription<PlaybackState> _playbackSubscription;
  final _audio = GetIt.I<AudioPlayerHandler>();
  @override
  void initState() {
    super.initState();
    _motion = AnimationController(vsync: this, duration: const Duration(milliseconds: 1100));
    _playbackSubscription = _audio.playbackState.listen((state) {
      if (!mounted) return;
      if (state.playing && Hive.box('settings').get('v2Motion', defaultValue: true) == true) {
        if (!_motion.isAnimating) _motion.repeat();
      } else {
        _motion.stop();
      }
    });
  }
  @override
  void dispose() { _playbackSubscription.cancel(); _motion.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final enabled = Hive.box('settings').get('v2Motion', defaultValue: true) == true;
    final accent = Theme.of(context).colorScheme.secondary;
    return Scaffold(
      appBar: AppBar(title: const Text('Jotify Motion Player')),
      body: StreamBuilder<MediaItem?>(
        stream: _audio.mediaItem,
        builder: (context, media) {
          final song = media.data;
          return StreamBuilder<PlaybackState>(
            stream: _audio.playbackState,
            builder: (context, state) {
              final playing = state.data?.playing ?? false;
              return GestureDetector(
                onHorizontalDragEnd: (details) {
                  if (Hive.box('settings').get('enableGesture', defaultValue: true) != true) return;
                  final dx = details.primaryVelocity ?? 0;
                  if (dx < -200) _audio.skipToNext();
                  if (dx > 200) _audio.skipToPrevious();
                },
                child: Center(child: SingleChildScrollView(
                  padding: const EdgeInsets.all(22),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    if (song?.artUri != null)
                      ClipRRect(borderRadius: BorderRadius.circular(24),
                        child: Image(image: song!.artUri!.scheme == 'file'
                          ? FileImage(File(song.artUri!.toFilePath())) as ImageProvider
                          : NetworkImage(song.artUri.toString()), height: 235, width: 235,
                          fit: BoxFit.cover, errorBuilder: (_, __, ___) => Icon(Icons.music_note, size: 120, color: accent)))
                    else Icon(Icons.album, size: 150, color: accent),
                    const SizedBox(height: 24),
                    Text(song?.title ?? 'No song playing', textAlign: TextAlign.center,
                      style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
                    Text(song?.artist ?? 'Choose a track in your library', textAlign: TextAlign.center),
                    const SizedBox(height: 24),
                    RepaintBoundary(child: SizedBox(height: 88,
                      child: AnimatedBuilder(animation: _motion, builder: (context, _) =>
                        Row(mainAxisAlignment: MainAxisAlignment.center,
                          children: List.generate(22, (i) {
                            final wave = math.sin((_motion.value * 2 * math.pi) + i * .51).abs();
                            final height = enabled && playing ? 12.0 + 65.0 * wave : 9.0;
                            return Container(width: 5, height: height, margin: const EdgeInsets.symmetric(horizontal: 2),
                              decoration: BoxDecoration(color: accent.withOpacity(.5 + .5 * wave),
                                borderRadius: BorderRadius.circular(6)));
                          }),
                        ),
                      ),
                    )),
                    const SizedBox(height: 16),
                    Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      IconButton(iconSize: 38, onPressed: _audio.skipToPrevious, icon: const Icon(Icons.skip_previous_rounded)),
                      const SizedBox(width: 15),
                      FilledButton.tonal(onPressed: song == null ? null : () { playing ? _audio.pause() : _audio.play(); },
                        child: Icon(playing ? Icons.pause_rounded : Icons.play_arrow_rounded, size: 42)),
                      const SizedBox(width: 15),
                      IconButton(iconSize: 38, onPressed: _audio.skipToNext, icon: const Icon(Icons.skip_next_rounded)),
                    ]),
                    const SizedBox(height: 6),
                    const Text('Swipe left/right to skip when gestures are enabled.', textAlign: TextAlign.center),
                  ]),
                )),
              );
            },
          );
        },
      ),
    );
  }
}

class JotifyLyricsStudio extends StatefulWidget {
  const JotifyLyricsStudio({super.key});
  @override
  State<JotifyLyricsStudio> createState() => _JotifyLyricsStudioState();
}

class _JotifyLyricsStudioState extends State<JotifyLyricsStudio> {
  final _audio = GetIt.I<AudioPlayerHandler>();
  double _fontSize = 18;
  String? _loadedId;
  Future<Map<String, String>>? _lyrics;

  Future<Map<String, String>> _load(MediaItem item) => Lyrics.getLyrics(
    id: item.id,
    title: item.title,
    artist: item.artist ?? '',
    saavnHas: item.genre != 'YouTube',
  ).timeout(const Duration(seconds: 18), onTimeout: () => {
    'lyrics': '', 'type': 'text', 'source': 'Timed out', 'id': item.id,
  }).catchError((Object _) => <String, String>{
    'lyrics': '', 'type': 'text', 'source': 'Unavailable', 'id': item.id,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Lyrics Studio')),
      body: StreamBuilder<MediaItem?>(stream: _audio.mediaItem,
        builder: (context, snapshot) {
          final item = snapshot.data;
          if (item == null) return const Center(child: Text('Play a song first to view available lyrics.'));
          if (_loadedId != item.id) { _loadedId = item.id; _lyrics = _load(item); }
          return Column(children: [
            ListTile(title: Text(item.title), subtitle: Text(item.artist ?? 'Unknown artist'),
              trailing: IconButton(onPressed: () => setState(() => _lyrics = _load(item)),
                icon: const Icon(Icons.refresh))),
            Slider(value: _fontSize, min: 14, max: 32,
              onChanged: (value) => setState(() => _fontSize = value)),
            Expanded(child: FutureBuilder<Map<String, String>>(future: _lyrics,
              builder: (context, data) {
                if (data.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
                final text = data.data?['lyrics'] ?? '';
                if (text.trim().isEmpty) return const Center(child: Padding(
                  padding: EdgeInsets.all(25),
                  child: Text('Lyrics unavailable for this track. Provider access and licensing vary.', textAlign: TextAlign.center)));
                return ListView(padding: const EdgeInsets.all(24), children: [
                  Text('Source: ${data.data?['source'] ?? 'Unknown'}', style: Theme.of(context).textTheme.bodySmall),
                  const SizedBox(height: 12),
                  Text(text, textAlign: TextAlign.center, style: TextStyle(fontSize: _fontSize, height: 1.7)),
                ]);
              },
            )),
          ]);
        },
      ),
    );
  }
}
