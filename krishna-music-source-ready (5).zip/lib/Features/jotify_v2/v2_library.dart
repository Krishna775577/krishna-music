// Jotify V2 features built on top of the existing on-device Hive library.
// Keeps the existing Saavn, YouTube and audio player integrations unchanged.
import 'package:hive/hive.dart';

class V2Library {
  static List<Map<String, dynamic>> _maps(Iterable values) {
    return values.whereType<Map>().map<Map<String, dynamic>>((item) {
      final copy = <String, dynamic>{};
      item.forEach((key, value) { copy[key.toString()] = value; });
      return copy;
    }).toList();
  }

  static List<Map<String, dynamic>> get favorites {
    if (!Hive.isBoxOpen('Favorite Songs')) return [];
    return _maps(Hive.box('Favorite Songs').values);
  }

  static List<Map<String, dynamic>> get recent {
    if (!Hive.isBoxOpen('cache')) return [];
    final value = Hive.box('cache').get('recentSongs', defaultValue: []);
    return value is List ? _maps(value) : [];
  }

  static String _key(Map item) {
    final id = (item['id'] ?? '').toString().trim();
    return id.isNotEmpty ? id : '${item['title']}|${item['artist']}';
  }

  static List<Map<String, dynamic>> unique(Iterable<Map<String, dynamic>> items) {
    final seen = <String>{};
    return items.where((s) => seen.add(_key(s))).toList();
  }

  static List<Map<String, dynamic>> get library => unique([...favorites, ...recent]);

  static const Map<String, List<String>> moodWords = {
    'Bhakti': ['bhajan', 'krishna', 'hanuman', 'ram', 'shiv', 'devotional', 'kirtan', 'aarti', 'mantra', 'bhakti'],
    'Chill': ['chill', 'lofi', 'lo-fi', 'acoustic', 'relax', 'ambient', 'soft'],
    'Romantic': ['love', 'romantic', 'pyaar', 'ishq', 'dil', 'mohabbat'],
    'Workout': ['workout', 'gym', 'dance', 'remix', 'dj', 'party', 'energy'],
    'Sad': ['sad', 'breakup', 'alone', 'heartbreak', 'dard', 'bewafa'],
    'Happy': ['happy', 'smile', 'joy', 'celebration', 'fun', 'masti'],
  };

  static List<Map<String, dynamic>> moodMix(String mood) {
    final all = library;
    final terms = moodWords[mood] ?? [];
    final matches = all.where((s) {
      final text = '${s['title'] ?? ''} ${s['artist'] ?? ''} ${s['genre'] ?? ''} ${s['album'] ?? ''}'.toLowerCase();
      return terms.any(text.contains);
    }).toList();
    // No fake "AI" mood inference: fallback is the user's actual saved songs.
    return matches.isNotEmpty ? matches : all.take(30).toList();
  }

  static List<String> spellingVariants(String query) {
    final original = query.trim();
    if (original.isEmpty) return [];
    final variants = <String>{original};
    final low = original.toLowerCase();
    if (low.contains('khama')) {
      variants.add(original.replaceAll(RegExp('khama', caseSensitive: false), 'khamma'));
      variants.add(original.replaceAll(RegExp('khama', caseSensitive: false), 'khamma ghani'));
    }
    if (low.contains('khamma')) {
      variants.add(original.replaceAll(RegExp('khamma', caseSensitive: false), 'khama'));
    }
    if (low.contains('ray')) variants.add(original.replaceAll(RegExp('ray', caseSensitive: false), 're'));
    if (low.contains('re')) variants.add(original.replaceAll(RegExp(r'\bre\b', caseSensitive: false), 'ray'));
    // Separate keywords provide broader matching without fabricating results.
    if (original.split(RegExp(r'\s+')).length > 1) variants.add(original.split(RegExp(r'\s+')).first);
    return variants.take(5).toList();
  }

  static List<Map<String, dynamic>> get topSongs {
    if (!Hive.isBoxOpen('stats')) return [];
    final box = Hive.box('stats');
    final maps = _maps(box.keys.where((key) => key.toString() != 'mostPlayed').map((key) => box.get(key)));
    final actual = maps.where((s) => s['id'] != null && s['playCount'] is num).toList();
    actual.sort((a, b) => ((b['playCount'] as num).toInt()).compareTo((a['playCount'] as num).toInt()));
    return actual;
  }

  static int get totalPlays => topSongs.fold<int>(0, (sum, s) => sum + ((s['playCount'] as num).toInt()));

  static List<MapEntry<String, int>> get topArtists {
    final counter = <String, int>{};
    for (final song in topSongs) {
      final artist = (song['artist'] ?? 'Unknown').toString().split(',').first.trim();
      if (artist.isNotEmpty) counter.update(artist, (n) => n + (song['playCount'] as num).toInt(),
          ifAbsent: () => (song['playCount'] as num).toInt());
    }
    final result = counter.entries.toList()..sort((a,b) => b.value.compareTo(a.value));
    return result.take(6).toList();
  }

  static Future<String> saveAutoMix(String label, List<Map<String, dynamic>> songs) async {
    if (songs.isEmpty) throw StateError('No songs available to create a mix');
    if (!Hive.isBoxOpen('settings')) throw StateError('Settings database is not open');
    final settings = Hive.box('settings');
    final existing = (settings.get('playlistNames', defaultValue: ['Favorite Songs']) as List).map((e) => e.toString()).toList();
    final base = 'Jotify $label Mix';
    var name = base;
    var suffix = 2;
    while (existing.contains(name) || Hive.isBoxOpen(name)) {
      name = '$base $suffix';
      suffix++;
    }
    // Populate the box before exposing it to the existing Playlists screen.
    final box = await Hive.openBox(name);
    for (final song in unique(songs)) {
      await box.put(_key(song), Map<String, dynamic>.from(song));
    }
    existing.add(name);
    await settings.put('playlistNames', existing);
    return name;
  }
}
