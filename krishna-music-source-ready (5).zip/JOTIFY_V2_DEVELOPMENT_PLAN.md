# Jotify V2 — Development and verification plan

**Base**: Latest locally available Jotify Name-Cleaned Flutter source (2026-11-21). This package is an incremental addition, not a rewrite. `name: jotify`, the existing Android application ID, playlists, local storage, playback providers, in-app YouTube embed, and custom branding are preserved.

## Included in this integration (Phase A)

| Requested feature | Included behavior | Important boundary |
| --- | --- | --- |
| Jotify Vibes — Mood DJ | Classifies saved/recent songs using mood words; plays a queue via existing `PlayerInvoke`; save as actual playlist | Local keyword rules, not a paid AI service; results depend on history |
| Motion Player + Visualizer | Separate smooth motion player reading existing audio-service state, play/pause/skip, optional animated wave | Stylized bars, **not** live FFT audio analysis; Android stream still uses existing engine |
| Advanced Smart Search | Saavn search shortcut, spelling variants (e.g. Khama/Khamma), existing search paging | Can't show songs missing from Saavn's catalogue; variants open a separate search |
| Music DNA + Listening Stats | Total play counts, unique played tracks, saved songs, top artists from existing Hive stats | Does not estimate listening minutes without duration event tracking |
| Lyrics Studio | Current-track lyrics lookup, refresh and font sizing | Provider-dependent text. Existing synchronized lyric player remains intact |
| Smart Sleep Timer | 10/20/30/45/60 minute controls and cancel using existing audio handler | Current handler stops after timer; fade-out is not implemented |
| Automatic Playlists | Save Favorites, Recent and Mood collections into new Hive playlist boxes | Never overwrites an existing playlist; existing playlists preserved |
| Gesture Controls | Existing player gesture/volume-swipe switches, gestures in motion player | Playback screen keeps existing gesture implementation |
| Smart Audio Settings | Access existing streaming quality settings and Android equalizer | True loudness normalization and gapless crossfade not introduced |
| Themes Studio | Direct access to the existing premium theme presets + original custom gradients | Existing colors and user themes kept |

**Entry point**: `Settings > Jotify V2 Studio` (first settings card).

## Non-regression rules

- Saavn audio-only playback stays on the original `just_audio` stack.
- YouTube and YtMusic still use the existing in-app video player, not hidden audio extraction.
- Existing Hive names and Android `applicationId` remain unchanged so updates do not discard user data.
- V2 uses existing dependencies: no new packages or SDK requirements.
- Original open-source legal attribution is retained.

## Build gate (must pass before calling this production-ready)

1. `flutter pub get` with the project SDK (`Flutter 3.19.6 / Dart 3.3.4`).
2. `dart format --output=none --set-exit-if-changed lib/Features/jotify_v2` (format first if needed).
3. `flutter analyze --no-fatal-infos` and examine any errors (pre-existing warnings may occur).
4. `flutter build apk --debug` via GitHub Actions; inspect first error if it fails.
5. Run the APK on a real device, check boot, Settings, V2 hub and theme change without crash.
6. Verify Saavn search, normal playback and next/previous still work.
7. Verify YouTube/YtMusic in-app playback remains unchanged (availability depends on YouTube embedding rules).
8. Create a Mood playlist; relaunch app; confirm it appears in library and plays.
9. Check sleep timer cancellation, gestures, lyrics unavailable state, saved themes.
10. Profile animations on a **profile/release** build, not solely debug; check for dropped frames or low-end devices.

## Phase B — after Phase A passes real builds

- Provider-independent search aggregation and optional query ranking with real API-result testing.
- Accurate listening-time stats using start/pause/seek accounting, retention and privacy controls.
- Opt-in audio-reactive FFT visualization with supported platform API and performance profiling.
- Volume fade-out, loudness normalization/crossfade only if native audio pipeline supports them reliably.
- Lyrics licensing, permission-safe export, and timestamp synchronization where a legitimate source supplies it.
- Better playlist recommendations based on user-approved listening history, on-device only.

## Limitations of delivery

This bundle was programmatically assembled and subjected to source/path integrity checks, **not compiled with Flutter or tested on an Android device in this environment**. Phase A actions are new source code, not a guarantee that every external streaming source functions. Do not overwrite the stable APK until the build and manual tests pass. Keep a backup branch.
