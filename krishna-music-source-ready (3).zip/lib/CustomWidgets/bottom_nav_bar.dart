import 'package:flutter/material.dart';

/// Lightweight bottom navigation with predictable height on narrow phones.
/// Original tab items/onTap API is preserved.
class CustomBottomNavBar extends StatelessWidget {
  const CustomBottomNavBar({
    super.key,
    required this.items,
    this.backgroundColor,
    this.currentIndex = 0,
    this.onTap,
    this.selectedItemColor,
    this.unselectedItemColor,
    this.selectedColorOpacity,
    this.itemShape = const StadiumBorder(),
    this.margin = const EdgeInsets.all(8),
    this.itemPadding = const EdgeInsets.symmetric(vertical: 7, horizontal: 8),
    this.duration = const Duration(milliseconds: 200),
    this.curve = Curves.easeOutCubic,
  });

  final List<CustomBottomNavBarItem> items;
  final int currentIndex;
  final Function(int)? onTap;
  final Color? backgroundColor;
  final Color? selectedItemColor;
  final Color? unselectedItemColor;
  final double? selectedColorOpacity;
  final ShapeBorder itemShape;
  final EdgeInsets margin;
  final EdgeInsets itemPadding;
  final Duration duration;
  final Curve curve;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final Color accent = selectedItemColor ?? theme.colorScheme.secondary;
    final Color inactive = unselectedItemColor ?? theme.iconTheme.color ?? Colors.grey;
    return ColoredBox(
      color: backgroundColor ?? theme.cardColor,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(8, 3, 8, 3),
        child: Row(
          children: <Widget>[
            for (int index = 0; index < items.length; index++)
              Expanded(
                child: Semantics(
                  button: true,
                  selected: currentIndex == index,
                  child: InkWell(
                    borderRadius: BorderRadius.circular(14),
                    onTap: () => onTap?.call(index),
                    child: AnimatedContainer(
                      duration: duration,
                      curve: curve,
                      height: 54,
                      margin: const EdgeInsets.symmetric(horizontal: 2),
                      padding: const EdgeInsets.symmetric(vertical: 4),
                      decoration: BoxDecoration(
                        color: currentIndex == index
                            ? accent.withOpacity(selectedColorOpacity ?? 0.13)
                            : Colors.transparent,
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          IconTheme(
                            data: IconThemeData(
                              color: currentIndex == index ? accent : inactive,
                              size: 22,
                            ),
                            child: currentIndex == index
                                ? items[index].activeIcon ?? items[index].icon
                                : items[index].icon,
                          ),
                          const SizedBox(height: 3),
                          DefaultTextStyle(
                            style: TextStyle(
                              color: currentIndex == index ? accent : inactive,
                              fontSize: 10,
                              fontWeight: currentIndex == index
                                  ? FontWeight.w800 : FontWeight.w500,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            child: items[index].title,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class CustomBottomNavBarItem {
  final Widget icon;
  final Widget? activeIcon;
  final Widget title;
  final Color? selectedColor;
  final Color? unselectedColor;

  CustomBottomNavBarItem({
    required this.icon,
    required this.title,
    this.selectedColor,
    this.unselectedColor,
    this.activeIcon,
  });
}
