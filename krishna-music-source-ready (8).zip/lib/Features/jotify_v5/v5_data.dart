import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:audio_service/audio_service.dart';
import 'package:file_picker/file_picker.dart';
import 'package:get_it/get_it.dart';
import 'package:hive/hive.dart';
import 'package:jotify/Features/jotify_v2/v2_library.dart';
import 'package:jotify/Screens/Player/audioplayer.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

/// V5 stores its own optional data in settings. No migration or existing box
/// schema change; it never overwrites the user's V1-V4 playlists or queue.
class V5Data {
  static Box get settings => Hive.box('settings');
  static bool get privateMode => settings.get('v4PrivateListening', defaultValue: false) == true;

  static List<Map<String, dynamic>> _maps(String key) {
    final raw = settings.get(key, defaultValue: <dynamic>[]);
    if (raw is! List) return <Map<String, dynamic>>[];
    return raw.whereType<Map>().map((m) => m.map<String, dynamic>((k, v) =>
        MapEntry(k.toString(), v))).toList();
  }

  static List<Map<String, dynamic>> get bookmarks => _maps('v5Bookmarks');
  static List<Map<String, dynamic>> get calendar => _maps('v5Calendar');

  static Future<void> bookmark(MediaItem item, Duration position) async {
    final all = bookmarks;
    all.insert(0, <String, dynamic>{
      'id': item.id, 'title': item.title, 'artist': item.artist ?? '',
      'positionMs': position.inMilliseconds,
      'savedAt': DateTime.now().toIso8601String(),
    });
    await settings.put('v5Bookmarks', all.take(150).toList());
  }

  static Future<void> removeBookmark(int index) async {
    final all = bookmarks;
    if (index < 0 || index >= all.length) return;
    all.removeAt(index);
    await settings.put('v5Bookmarks', all);
  }

  static Future<void> logPlay(MediaItem item) async {
    if (privateMode || item.title.trim().isEmpty) return;
    final today = DateTime.now();
    final day = '${today.year.toString().padLeft(4, '0')}-${today.month.toString().padLeft(2, '0')}-${today.day.toString().padLeft(2, '0')}';
    final rows = calendar;
    final existing = rows.indexWhere((m) => m['date'] == day && m['id'] == item.id);
    if (existing < 0) {
      rows.insert(0, <String, dynamic>{
        'date': day, 'id': item.id, 'title': item.title,
        'artist': item.artist ?? '', 'plays': 1,
      });
    } else {
      rows[existing]['plays'] = ((rows[existing]['plays'] as num?)?.toInt() ?? 0) + 1;
    }
    await settings.put('v5Calendar', rows.take(800).toList());
  }

  /// Local recommendation is based on owned library, not an invented catalog.
  static List<Map<String, dynamic>> flowCandidates({String? artist}) {
    final all = V2Library.library.where((m) {
      final source = (m['genre'] ?? '').toString().toLowerCase();
      final url = (m['url'] ?? '').toString();
      final id = (m['id'] ?? '').toString();
      return id.isNotEmpty && url.startsWith('http') &&
          source != 'youtube' && !url.contains('youtube.com') &&
          !url.contains('youtu.be');
    }).toList();
    if (artist == null || artist.isEmpty) return all;
    final matched = all.where((m) => (m['artist'] ?? '').toString().toLowerCase()
        .contains(artist.toLowerCase().split(',').first.trim())).toList();
    return <Map<String, dynamic>>[...matched, ...all.where((m) => !matched.contains(m))];
  }

  static List<Map<String, dynamic>> discover() {
    final library = V2Library.library;
    final known = V2Library.recent.map((e) => (e['id'] ?? '').toString()).toSet();
    final fresh = library.where((m) => !known.contains((m['id'] ?? '').toString())).toList();
    return fresh.isNotEmpty ? fresh.take(25).toList() : library.reversed.take(25).toList();
  }

  /// Share portable human-readable JSON. Import requires user-selected file,
  /// strictly bounded input size and a brand-new non-overwriting playlist.
  static Future<void> exportPlaylist(String name) async {
    if (!Hive.isBoxOpen(name)) await Hive.openBox(name);
    final tracks = Hive.box(name).values.whereType<Map>().take(500).map((m) {
      final item = <String, dynamic>{};
      for (final key in <String>['id', 'title', 'artist', 'album', 'duration',
          'url', 'image', 'language', 'genre', 'allUrls', 'has_lyrics']) {
        final v = m[key];
        if (v == null || v is String || v is num || v is bool || v is List) item[key] = v;
      }
      return item;
    }).toList();
    final output = jsonEncode(<String, dynamic>{
      'format': 'jotify-together-v1', 'playlist': name, 'tracks': tracks,
    });
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/jotify_together.json');
    await file.writeAsString(output, flush: true);
    await Share.shareXFiles(<XFile>[XFile(file.path)],
        text: 'Jotify Together playlist: $name (import through Jotify V5)');
  }

  static Future<String> importPlaylist() async {
    final picker = await FilePicker.platform.pickFiles(
      type: FileType.custom, allowedExtensions: <String>['json'],
      withData: true,
    );
    if (picker == null || picker.files.isEmpty) return 'Import cancelled';
    final picked = picker.files.single;
    if (picked.size > 512 * 1024) throw const FormatException('File exceeds 512 KB limit');
    final bytes = picked.bytes ?? (picked.path == null ? null : await File(picked.path!).readAsBytes());
    if (bytes == null || bytes.length > 512 * 1024) throw const FormatException('Could not read JSON safely');
    final decoded = jsonDecode(utf8.decode(bytes));
    if (decoded is! Map || decoded['format'] != 'jotify-together-v1' || decoded['tracks'] is! List) {
      throw const FormatException('Not a Jotify Together v1 file');
    }
    final tracks = <Map<String, dynamic>>[];
    for (final entry in (decoded['tracks'] as List).take(500)) {
      if (entry is! Map) continue;
      final id = (entry['id'] ?? '').toString().trim();
      final title = (entry['title'] ?? '').toString().trim();
      final url = (entry['url'] ?? '').toString().trim();
      if (id.isEmpty || title.isEmpty || url.isEmpty || url.length > 4096) continue;
      if (!url.startsWith('https://') && !url.startsWith('http://')) continue;
      tracks.add(entry.map<String, dynamic>((k, v) => MapEntry(k.toString(), v)));
    }
    if (tracks.isEmpty) throw const FormatException('No valid supported stream tracks in file');
    final name = (decoded['playlist'] ?? 'Together').toString()
        .replaceAll(RegExp(r'[^\w\s\-]'), '').trim();
    final newName = await V2Library.saveAutoMix('Together ${name.substring(0, min(name.length, 25))}', tracks);
    return 'Imported ${tracks.length} tracks into $newName';
  }

  static Future<void> playBookmarksTrack(int index) async {
    final rows = bookmarks;
    if (index < 0 || index >= rows.length) return;
    final b = rows[index];
    final audio = GetIt.I<AudioPlayerHandler>();
    if (audio.mediaItem.value?.id != b['id']) {
      throw StateError('Play the bookmarked song first, then tap Go to timestamp.');
    }
    final ms = (b['positionMs'] as num?)?.toInt() ?? 0;
    await audio.seek(Duration(milliseconds: max(0, ms)));
  }
}
