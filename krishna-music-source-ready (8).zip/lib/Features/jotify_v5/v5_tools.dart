import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:audio_service/audio_service.dart';
import 'package:crypto/crypto.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get_it/get_it.dart';
import 'package:hive/hive.dart';
import 'package:jotify/Features/jotify_v2/v2_library.dart';
import 'package:jotify/Features/jotify_v5/v5_data.dart';
import 'package:jotify/Screens/Player/audioplayer.dart';
import 'package:jotify/Screens/Search/search.dart';
import 'package:jotify/Services/player_service.dart';

void v5Toast(BuildContext context, String value) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(value)));
}

class JotifyTogether extends StatefulWidget {
  const JotifyTogether({super.key});
  @override State<JotifyTogether> createState() => _JotifyTogetherState();
}
class _JotifyTogetherState extends State<JotifyTogether> {
  String? _name;
  bool _busy = false;
  @override Widget build(BuildContext context) {
    final raw = Hive.box('settings').get('playlistNames', defaultValue: <String>['Favorite Songs']);
    final names = raw is List ? raw.map((e) => e.toString()).toSet().toList() : <String>[];
    return Scaffold(appBar: AppBar(title: const Text('Jotify Together')),
      body: ListView(padding: const EdgeInsets.all(20), children: <Widget>[
        const Text('Exchange playlist JSON files with friends. Each import creates a NEW playlist; nothing is overwritten. This is not a real-time cloud collaboration service.'),
        const SizedBox(height: 24),
        DropdownButtonFormField<String>(value: names.contains(_name) ? _name : null,
          hint: const Text('Choose playlist to share'),
          items: names.map((n) => DropdownMenuItem(value: n, child: Text(n))).toList(),
          onChanged: (v) => setState(() => _name = v)),
        const SizedBox(height: 12),
        FilledButton.icon(icon: const Icon(Icons.ios_share), label: const Text('Share selected playlist'),
          onPressed: _busy || _name == null ? null : () async {
            setState(() => _busy = true);
            try { await V5Data.exportPlaylist(_name!); }
            catch (e) { if (mounted) v5Toast(context, 'Export failed: $e'); }
            finally { if (mounted) setState(() => _busy = false); }
          }),
        OutlinedButton.icon(icon: const Icon(Icons.file_download), label: const Text('Import friend’s Jotify playlist'),
          onPressed: _busy ? null : () async {
            setState(() => _busy = true);
            try { final msg = await V5Data.importPlaylist(); if (mounted) v5Toast(context, msg); }
            catch (e) { if (mounted) v5Toast(context, 'Import failed: $e'); }
            finally { if (mounted) setState(() => _busy = false); }
          }),
        const SizedBox(height: 16),
        const Text('Only publicly reachable compatible stream URLs are imported. Imported tracks may expire or be unavailable later.'),
      ]));
  }
}

class JotifyFocus extends StatefulWidget {
  const JotifyFocus({super.key});
  @override State<JotifyFocus> createState() => _JotifyFocusState();
}
class _JotifyFocusState extends State<JotifyFocus> {
  int _minutes = 25;
  int _remaining = 25 * 60;
  Timer? _timer;
  bool _running = false;
  bool _pauseMusic = false;
  @override void dispose() { _timer?.cancel(); super.dispose(); }
  void _start() {
    if (_remaining <= 0) _remaining = _minutes * 60;
    _timer?.cancel();
    setState(() => _running = true);
    _timer = Timer.periodic(const Duration(seconds: 1), (_) async {
      if (!mounted) { _timer?.cancel(); return; }
      if (_remaining <= 1) {
        _timer?.cancel();
        setState(() { _remaining = 0; _running = false; });
        if (_pauseMusic) await GetIt.I<AudioPlayerHandler>().pause();
        if (mounted) v5Toast(context, 'Focus session completed');
      } else { setState(() => _remaining--); }
    });
  }
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Jotify Focus')),
    body: ListView(padding: const EdgeInsets.all(22), children: <Widget>[
      const Text('Focus timer runs only while this screen stays active. It does not schedule system background alarms.'),
      const SizedBox(height: 25),
      Text('${(_remaining ~/ 60).toString().padLeft(2,'0')}:${(_remaining % 60).toString().padLeft(2,'0')}',
        textAlign: TextAlign.center, style: const TextStyle(fontSize: 58, fontWeight: FontWeight.bold)),
      Wrap(alignment: WrapAlignment.center, spacing: 10, children: <Widget>[
        for (final m in <int>[15,25,45,60]) ChoiceChip(label: Text('$m min'), selected: _minutes == m,
          onSelected: _running ? null : (_) => setState(() { _minutes = m; _remaining = m * 60; })),
      ]),
      SwitchListTile(title: const Text('Pause music when timer completes'), value: _pauseMusic,
        onChanged: (v) => setState(() => _pauseMusic = v)),
      Row(mainAxisAlignment: MainAxisAlignment.center, children: <Widget>[
        FilledButton.icon(onPressed: _running ? null : _start,
          icon: const Icon(Icons.play_arrow), label: Text(_remaining == 0 ? 'Restart' : 'Start / Resume')),
        const SizedBox(width: 9),
        OutlinedButton(onPressed: () { _timer?.cancel(); setState(() => _running = false); }, child: const Text('Pause')),
        IconButton(tooltip: 'Reset', icon: const Icon(Icons.restart_alt),
          onPressed: () { _timer?.cancel(); setState(() { _running = false; _remaining = _minutes * 60; }); }),
      ]),
    ]));
}

class JotifyDiscover extends StatelessWidget {
  const JotifyDiscover({super.key});
  @override Widget build(BuildContext context) {
    final tracks = V5Data.discover();
    return Scaffold(appBar: AppBar(title: const Text('Jotify Discover')),
      body: ListView(padding: const EdgeInsets.all(16), children: <Widget>[
        const Text('Rediscover music already in your library. For new catalog results, use Saavn/YouTube search.'),
        const SizedBox(height: 12),
        FilledButton.icon(onPressed: () => Navigator.of(context).push(MaterialPageRoute<void>(
          builder: (_) => SearchPage(query: 'new releases', searchType: 'saavn'))),
          icon: const Icon(Icons.travel_explore), label: const Text('Search new releases')),
        if (tracks.isEmpty) const ListTile(title: Text('Your library is empty'), subtitle: Text('Save a few songs first.')),
        ...tracks.take(30).map((s) => ListTile(
          leading: const Icon(Icons.music_note_rounded),
          title: Text((s['title'] ?? 'Unknown song').toString(), maxLines: 1),
          subtitle: Text((s['artist'] ?? '').toString(), maxLines: 1),
          onTap: () async { try { await PlayerInvoke.init(songsList: <Map<String,dynamic>>[s], index: 0); }
            catch (e) { if (context.mounted) v5Toast(context, 'Could not play: $e'); } },
        )),
      ]));
  }
}

class JotifyBookmarks extends StatefulWidget {
  const JotifyBookmarks({super.key});
  @override State<JotifyBookmarks> createState() => _JotifyBookmarksState();
}
class _JotifyBookmarksState extends State<JotifyBookmarks> {
  final AudioPlayerHandler _audio = GetIt.I<AudioPlayerHandler>();
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Audio Bookmarks')),
    body: ListView(padding: const EdgeInsets.all(14), children: <Widget>[
      StreamBuilder<MediaItem?>(stream: _audio.mediaItem, builder: (context,snap) =>
        FilledButton.icon(icon: const Icon(Icons.bookmark_add), label: const Text('Bookmark current timestamp'),
          onPressed: snap.data == null ? null : () async {
            try { final pos = await AudioService.position.first.timeout(const Duration(seconds: 2));
              await V5Data.bookmark(snap.data!, pos);
              if (mounted) setState(() {});
            } catch (e) { if (mounted) v5Toast(context, 'Could not save bookmark: $e'); }
          })),
      const SizedBox(height: 12),
      const Text('Bookmarks seek only when the same song is currently playing; no auto-reloading of expired streams.'),
      for (var i = 0; i < V5Data.bookmarks.length; i++)
        ListTile(leading: const Icon(Icons.bookmark),
          title: Text(V5Data.bookmarks[i]['title'].toString()),
          subtitle: Text('${V5Data.bookmarks[i]['artist']} · ${(V5Data.bookmarks[i]['positionMs'] as num? ?? 0).toInt() ~/ 1000}s'),
          onTap: () async { try { await V5Data.playBookmarksTrack(i); }
            catch (e) { if (mounted) v5Toast(context, '$e'); } },
          trailing: IconButton(tooltip: 'Delete bookmark', icon: const Icon(Icons.delete_outline),
            onPressed: () async { await V5Data.removeBookmark(i); if (mounted) setState(() {}); })),
    ]));
}

class JotifyMusicRecognition extends StatelessWidget {
  const JotifyMusicRecognition({super.key});
  static const MethodChannel _channel = MethodChannel('jotify/music_recognition');
  @override Widget build(BuildContext context) {
    final audio = GetIt.I<AudioPlayerHandler>();
    return Scaffold(appBar: AppBar(title: const Text('Music Recognition')),
      body: ListView(padding: const EdgeInsets.all(20), children: <Widget>[
        const Text('Identify the Jotify song playing now, or ask an installed external recognition service to listen to nearby music.'),
        const SizedBox(height: 16),
        StreamBuilder<MediaItem?>(stream: audio.mediaItem, builder: (context,s) =>
          ListTile(leading: const Icon(Icons.music_note), title: Text(s.data?.title ?? 'No active Jotify track'),
            subtitle: Text(s.data?.artist ?? 'Play a song to identify it'))),
        FilledButton.icon(icon: const Icon(Icons.hearing), label: const Text('Open external song recognition'),
          onPressed: () async {
            try {
              final available = await _channel.invokeMethod<bool>('launch') ?? false;
              if (!available && context.mounted) v5Toast(context, 'No compatible external music recognition app available on this device.');
            } catch (_) { if (context.mounted) v5Toast(context, 'Music recognition not supported on this device.'); }
          }),
        const SizedBox(height: 12),
        const Text('This delegates microphone recognition to a separate app if installed. Jotify does not fingerprint audio itself. Android support varies by device.'),
      ]));
  }
}

class JotifyMusicCalendar extends StatefulWidget {
  const JotifyMusicCalendar({super.key});
  @override State<JotifyMusicCalendar> createState() => _JotifyMusicCalendarState();
}
class _JotifyMusicCalendarState extends State<JotifyMusicCalendar> {
  @override Widget build(BuildContext context) {
    final dates = <String,int>{};
    for (final row in V5Data.calendar) {
      final day = (row['date'] ?? '').toString();
      dates.update(day, (count) => count + ((row['plays'] as num?)?.toInt() ?? 1),
        ifAbsent: () => ((row['plays'] as num?)?.toInt() ?? 1));
    }
    final keys = dates.keys.toList()..sort((a,b) => b.compareTo(a));
    return Scaffold(appBar: AppBar(title: const Text('Music Calendar')),
      body: ListView(padding: const EdgeInsets.all(16), children: <Widget>[
        SwitchListTile(title: const Text('Record listening days'),
          subtitle: const Text('No activity is recorded while Private Listening is enabled.'),
          value: V5Data.settings.get('v5CalendarEnabled', defaultValue: true) == true,
          onChanged: (v) async { await V5Data.settings.put('v5CalendarEnabled',v); if(mounted)setState((){}); }),
        const Text('Recorded when an audio track becomes active; this is not verified full-song listening duration.'),
        if (keys.isEmpty) const ListTile(title: Text('No listening history yet')),
        for (final day in keys.take(90)) ExpansionTile(title: Text(day), subtitle: Text('${dates[day]} track starts'),
          children: <Widget>[for (final row in V5Data.calendar.where((m) => m['date'] == day))
            ListTile(title: Text('${row['title']}'), subtitle: Text('${row['artist']} · ${row['plays']} starts'))]),
        const SizedBox(height: 18),
        OutlinedButton.icon(icon: const Icon(Icons.delete_outline), label: const Text('Clear V5 calendar history'),
          onPressed: () async { await V5Data.settings.put('v5Calendar', <dynamic>[]); if(mounted)setState((){}); }),
      ]));
  }
}

/// PIN gate for V5-specific saved tracks only. This is UI privacy, not
/// encryption, and cannot hide playlists exposed by older app screens.
class JotifyVault extends StatefulWidget {
  const JotifyVault({super.key});
  @override State<JotifyVault> createState() => _JotifyVaultState();
}
class _JotifyVaultState extends State<JotifyVault> {
  final TextEditingController _pin = TextEditingController();
  bool _unlocked = false;
  String _note = 'Enter 4–8 digits. No PIN recovery is provided.';
  String _digest(String pin, String salt) => sha256.convert(utf8.encode('$salt:$pin')).toString();
  @override void dispose() { _pin.dispose(); super.dispose(); }
  void _unlock() async {
    final pin = _pin.text;
    if (!RegExp(r'^\d{4,8}$').hasMatch(pin)) { setState(() => _note = 'PIN must be 4–8 digits.'); return; }
    final saved = V5Data.settings.get('v5VaultHash')?.toString();
    final salt = V5Data.settings.get('v5VaultSalt')?.toString();
    if (saved == null || salt == null) {
      final random = Random.secure();
      final newSalt = List<int>.generate(24, (_) => random.nextInt(256)).join('-');
      await V5Data.settings.put('v5VaultSalt', newSalt);
      await V5Data.settings.put('v5VaultHash', _digest(pin,newSalt));
      if (mounted) setState(() { _unlocked = true; _note = 'New PIN set.'; });
    } else if (_digest(pin,salt) == saved) {
      if (mounted) setState(() { _unlocked = true; _note = 'Unlocked.'; });
    } else { setState(() => _note = 'Wrong PIN.'); }
    _pin.clear();
  }
  List<Map<String,dynamic>> get _saved {
    final raw = V5Data.settings.get('v5VaultSongs', defaultValue: <dynamic>[]);
    return raw is List ? raw.whereType<Map>().map((e) => e.map<String,dynamic>((k,v) => MapEntry(k.toString(),v))).toList() : <Map<String,dynamic>>[];
  }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Jotify Vault')),
    body: ListView(padding: const EdgeInsets.all(20), children: <Widget>[
      if (!_unlocked) ...<Widget>[
        const Icon(Icons.lock_outline, size: 48),
        Text(_note, textAlign: TextAlign.center),
        TextField(controller: _pin, obscureText: true, keyboardType: TextInputType.number,
          maxLength: 8, decoration: const InputDecoration(labelText: 'PIN', border: OutlineInputBorder()), onSubmitted: (_) => _unlock()),
        FilledButton(onPressed: _unlock, child: const Text('Unlock / Set PIN')),
      ] else ...<Widget>[
        const Text('V5 Vault stores a separate PIN-gated list of saved tracks. Song records are not encrypted at rest; this is not a secure file vault.'),
        FilledButton.icon(icon: const Icon(Icons.add), label: const Text('Add current song to Vault'), onPressed: () async {
          final item = GetIt.I<AudioPlayerHandler>().mediaItem.value;
          if (item == null) { v5Toast(context, 'Play a song first'); return; }
          final source = V2Library.library.where((m) => m['id'].toString() == item.id);
          if (source.isEmpty) { v5Toast(context, 'This song is not in your saved/recent library.'); return; }
          final all = _saved;
          if (!all.any((m) => m['id'] == item.id)) all.add(source.first);
          await V5Data.settings.put('v5VaultSongs', all.take(100).toList());
          if(mounted)setState((){});
        }),
        for (var i=0;i<_saved.length;i++) ListTile(title: Text('${_saved[i]['title']}'), subtitle: Text('${_saved[i]['artist']}'),
          onTap: () async { try { await PlayerInvoke.init(songsList: <Map<String,dynamic>>[_saved[i]],index:0); }
            catch(e) { if(context.mounted)v5Toast(context,'Playback error: $e'); } },
          trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () async {
            final a = _saved; a.removeAt(i); await V5Data.settings.put('v5VaultSongs',a); if(mounted)setState((){});
          })),
        OutlinedButton(onPressed: () => setState(() => _unlocked = false), child: const Text('Lock Vault')),
      ],
    ]));
}
