# Jotify V5 source release notes

**Project version:** 1.16.0+42 (incremental over the V4 project version).

- Adds **Settings → Jotify V5 · Next Gen Music** entry, 12 V5 feature screens/tools and a non-breaking optional queue extender.
- Improves lyrics lookup fallback, adds **manual artist/title correction** and **offline synced LRC import**.
- Adds phone voice search with the `speech_to_text 6.6.2` Flutter plugin and user-driven microphone permission.
- Preserves previous application ID, Hive database paths, V4 screens, all original open-source copyright notices and separate embedded YouTube player.
- Android music recognition is a best-effort *external provider handoff*, not native fingerprinting.
- `Jotify Together` is local JSON file exchange, **not** a shared live cloud service.
- Floating mini player appears only inside V5 Studio; Vault PIN is **not** encryption.
- `Flutter 3.19.6` build and vivo V50 tests have **NOT** been executed in this working environment.

Read `JOTIFY_V5_DEVELOPMENT_TEST_PLAN.md` before testing or replacing an existing installation.
