# Jotify V5 — Implementation and Testing Plan

**Build target:** Flutter 3.19.6 / Dart 3.3.4; existing Jotify V4 source and Android app ID.  
**Package status:** Source-level V5 implementation, **NOT** a compiled or phone-tested stable APK.  
**Priority:** Preserve V4 Saavn audio, YouTube/YtMusic embedded video, premium themes, settings, histories and backups. Protect against broken lyrics requests, app startup failures and expensive permissions.

## 1. Implemented source and explicit limitations

| V5 feature | Source implementation | Current boundary |
|---|---|---|
| Jotify Flow — Infinite Music | Optional queue top-up while 3 or fewer queued tracks remain; 5 nonduplicate songs selected from the user's known Saavn links; start an on-device shuffle from V5 hub | No cloud similarity algorithm or newly discovered remote tracks; old URLs can expire; embedded YouTube video is excluded |
| Jotify Voice | `speech_to_text 6.6.2`, explicit microphone tap, speech transcription, manual review, Saavn/YT/YTM search navigation | Requires compatible OS speech service and user microphone permission; voice command does not auto-play results |
| Lyrics Studio 3.0 | LRCLIB search/title variants, corrected Saavn API request inherited from V4, editable song title/artist for lookup, offline `.lrc/.txt` import (256KB limit), per-song timing offset, synced highlighting, tap line to seek | Cannot guarantee all lyrics from providers; plain-text lyrics cannot be timed automatically; imports are synced-format only |
| Jotify Together | Export playlist to portable JSON and import from friend into a **new** playlist, 512KB/500-song guardrails | Asynchronous file exchange **not real-time collaborative editing**; remote streaming URLs may expire |
| Jotify Focus | 15/25/45/60-minute foreground timer; optional pause music at completion | Timer works only while this screen/process is active; no scheduled background alarm |
| Music Recognition | Identify Jotify's current song from metadata; Android native handoff to a compatible **installed third-party** sound-search app | No acoustic fingerprinting or guaranteed installed provider; handoff action may be unsupported on vivo V50 |
| Jotify Discover | Finds less-recent saved tracks, plays via existing player; opens Saavn search for new releases | New catalog recommendations require provider results |
| Audio Bookmarks | Save real AudioService position with title and song ID; timestamp seek when same song is active; delete bookmarks | Does not re-open an expired URL or load another song automatically |
| Floating Mini Player | Draggable mini-player inside V5 Studio, with play/pause/next | Not a systemwide overlay, does not request draw-over-other-apps permission |
| Jotify Vault | Salted SHA-256 PIN on a separate V5 saved-track list, add/play/remove | **UI lock only**; Hive records are NOT encrypted; does not hide old V1–V4 playlists from their original menus; no PIN reset recovery UI |
| Smart Network Mode | Opt-in cap at 96 kbps for future Saavn sources on mobile data; remembers preference | Does not guarantee automatic reconnect or retrofit already buffered sources; bandwidth bitrate depends on provider |
| Music Calendar | Logs track starts from V5 onwards into Hive; by-day count; private listening suppresses recording; clear/toggle | Does not track precise listened minutes, and starting a track is not proof of full playback |

## 2. Playback/lyrics reliability work

1. Preserve `lib/Services/player_service.dart`, `lib/Screens/YouTube/official_youtube_player.dart`, Saavn and search code unchanged. 
2. Lyrics lookup uses LRCLIB variants with timeouts and title/artist matching, then existing JioSaavn & fallback. No paid API key or fabricated lyrics.
3. Imported LRC lyrics are available both in V5 and the V4 classic `Lyrics.getLyrics()` path while offline.
4. V5 Flow appends only when enabled and only during an existing audio queue. All conversion/provider exceptions are contained, preventing queue errors from crashing playback.
5. No unsupported YouTube audio URL extraction or music copyright bypass introduced.
6. Keep `v5FlowEnabled`, `v5SmartNetworkEnabled`, `v5CalendarEnabled` opt-in/independent, with Flow/network **off by default**.

## 3. Build steps

From the extracted **full source**, or after merging the **update ZIP** into an existing V4 source tree:

```powershell
flutter --version
flutter clean
flutter pub get
flutter analyze
flutter build apk --debug
```

The original workflow `.github/workflows/import-and-build.yml` also supports import of a ZIP overlay called `krishna-music-source-ready.zip`; GitHub alone never unpacks an uploaded ZIP. Upload/replace that file at the repository root, commit, then manually trigger **Actions → Import ZIP and Build Android APK → Run workflow**. Check the build **logs** and download the APK from the artifacts only after a successful run. Preserve a copy of the working V4 APK and exported backup first.

New runtime dependencies: `speech_to_text: 6.6.2`, `crypto: ^3.0.3`. Android `RECORD_AUDIO` and iOS microphone/speech descriptions were added. Speech plugin availability is OS-dependent. Never grant microphone permission unless you want Voice Search.

## 4. Device test matrix — vivo V50 / OriginOS 6

**Start-up and regression**
- [ ] Install debug APK side-by-side only if signing/package ID permits; otherwise back up your V4 data before updating.
- [ ] App opens without crash; Home, Library, Settings, V2 Studio, V3 Studio, V4 Experience and V5 Studio all open.
- [ ] Saavn: search → play → seek → pause → next → background → lock screen → notification controls.
- [ ] YouTube/YtMusic: in-app embedded video works as before; verify no audio-only regression.
- [ ] Playlist/favourites/history remain; backup and restore tested on a disposable copy.

**Lyrics (high priority)**
- [ ] Test a popular Hindi song with title/artist verified; note LRCLIB/Saavn source.
- [ ] Try a regional/Rajasthani song with spelling variants; tap **Fix title/artist** and Retry.
- [ ] Import a known good `.lrc` file with `[mm:ss.xx]` timestamps and check tap-to-seek, line highlight and ±5000ms offset.
- [ ] Turn off mobile data and Wi-Fi. Confirm imported lyrics display offline, and remote lookups time out gracefully.
- [ ] Restart app: saved LRC, font/offset and corrected metadata should persist as documented (font size is currently per-screen only).
- [ ] Confirm instrumental song has a clear not-found message, not an endless spinner.

**V5 functionality**
- [ ] Flow OFF: normal V4 queue stays untouched. Flow ON: queue extends near the end with *known* Saavn tracks only; no duplicates in appended 5 items.
- [ ] Voice: deny microphone permission first (typed fallback works). Allow permission, test Hindi/English commands and all provider selectors.
- [ ] Together: export actual playlist, send JSON to another device, import into a new playlist; test invalid JSON/oversized file rejected.
- [ ] Focus: start 1 test session at 15min (or adjust with test-only code), pause, resume, finish and optional music pause; navigate away to understand foreground limitation.
- [ ] Recognition: current track metadata displayed; external handoff either opens supported provider or reports unavailable.
- [ ] Discover: select a saved track, play; test new-release search and an empty-library state.
- [ ] Bookmarks: seek mid-song, bookmark, seek elsewhere, tap bookmark; try it when another song is active and confirm clear error.
- [ ] Floating: drag inside V5 Studio, Play/Pause/Next; leave V5 Studio and verify overlay disappears.
- [ ] Vault: create PIN, add saved track, lock, wrong PIN, unlock. Verify vault does **not** represent encrypted storage.
- [ ] Network: V4 quality unchanged with OFF. ON affects *new* mobile Saavn tracks; test Wi-Fi vs mobile data and stream errors.
- [ ] Calendar: play songs on one day, check counts, enable V4 Private Listening, play song and confirm no new calendar entry.

**Quality/security checks**
- [ ] Run `flutter analyze` and resolve actual errors, not only static brace checks.
- [ ] Test on Android release/profile build for real animations and battery/CPU impact.
- [ ] Check airplane mode, rapid song skips, repeated app background/resume, permission denial, empty database and corrupted JSON.
- [ ] Confirm no new paid API key, microphone recording in background, unauthorized downloads, modified original copyright headers or identity migration.

## 5. Release blockers and rollback

**Block release** if `flutter pub get`/`flutter build apk` fails; crash occurs on startup, app data disappears, Saavn cannot play previously working streams, YouTube embedded player regresses, or lyrics continuously hang. Use previous V4 backup; disabling V5 toggles alone does not roll back dependency or native Android changes.

## 6. Next engineering milestones (not in this V5 code)

- Real-time Jotify Together would require an authenticated backend, permissions, conflict resolution and privacy design.
- True ambient music fingerprint recognition needs a supported provider/SDK, API credentials and explicit microphone capture design.
- True Android systemwide floating overlay needs Android overlay permission, lifecycle management and device security checks.
- Encrypted Vault needs device keystore-backed key storage and secure migration of the actual playlist data.
- Live adaptive streaming quality and robust buffering recovery require systematic testing against actual Saavn streaming providers and error policies.
- Real-time cloud music recommendations would require legitimate catalog/provider access and opt-in preference data.

**Result:** V5 source package is useful as a testable update candidate, NOT a verified production APK. Source/static checks are not substitutes for Flutter compilation and phone tests.
