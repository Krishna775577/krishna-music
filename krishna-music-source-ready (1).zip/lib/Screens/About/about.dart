/*
 * Jotify customization by Krishna Bajaj.
 * Original BlackHole source Copyright (c) 2021-2023, Ankit Sangwan.
 * Original copyright and license notices are retained in the source tree.
 */
import 'package:flutter/material.dart';
import 'package:jotify/Screens/Settings/about.dart';

class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  @override
  Widget build(BuildContext context) => const AboutPage();
}
