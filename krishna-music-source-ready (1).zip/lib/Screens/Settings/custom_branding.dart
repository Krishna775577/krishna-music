import 'dart:io';

import 'package:blackhole/CustomWidgets/gradient_containers.dart';
import 'package:blackhole/Helpers/jotify_branding.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:path_provider/path_provider.dart';

/// Personalize the in-app title/logo and optionally create an Android Home
/// screen shortcut carrying that name and the selected photo.
class CustomBrandingPage extends StatefulWidget {
  const CustomBrandingPage({super.key});

  @override
  State<CustomBrandingPage> createState() => _CustomBrandingPageState();
}

class _CustomBrandingPageState extends State<CustomBrandingPage> {
  static const _channel = MethodChannel('jotify/custom_branding');
  final _nameController = TextEditingController();
  String? _draftIconPath;
  bool _saving = false;
  bool _dirty = false;

  @override
  void initState() {
    super.initState();
    _nameController.text = JotifyBranding.name;
    _draftIconPath = JotifyBranding.customIconPath;
    _nameController.addListener(_markDirty);
  }

  void _markDirty() {
    if (mounted && !_dirty) setState(() => _dirty = true);
  }

  @override
  void dispose() {
    _nameController.removeListener(_markDirty);
    _nameController.dispose();
    super.dispose();
  }

  void _message(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  Future<void> _pickImage() async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.image,
        allowMultiple: false,
        withData: false,
      );
      if (!mounted || result == null || result.files.isEmpty) return;
      final path = result.files.single.path;
      if (path == null || path.isEmpty) {
        _message('Could not access this image. Try a JPG or PNG file.');
        return;
      }
      final file = File(path);
      if (!await file.exists()) {
        _message('Selected photo could not be opened.');
        return;
      }
      if (await file.length() > 12 * 1024 * 1024) {
        _message('Choose an image smaller than 12 MB.');
        return;
      }
      setState(() {
        _draftIconPath = path;
        _dirty = true;
      });
    } catch (error) {
      _message('Could not select image: $error');
    }
  }

  Future<void> _save() async {
    final name = _nameController.text.trim();
    if (name.isEmpty) {
      _message('Enter an app name.');
      return;
    }
    if (name.runes.length > 30) {
      _message('Use an app name of 30 characters or fewer.');
      return;
    }
    setState(() => _saving = true);
    try {
      String? savedPath;
      final source = _draftIconPath;
      if (source != null) {
        final file = File(source);
        if (!await file.exists()) {
          throw const FileSystemException('Selected image is no longer available');
        }
        final support = await getApplicationSupportDirectory();
        final folder = Directory('${support.path}/jotify_branding');
        await folder.create(recursive: true);
        final extension = source.toLowerCase().split('.').last;
        final fileExtension = ['jpg', 'jpeg', 'png', 'webp'].contains(extension)
            ? extension
            : 'jpg';
        final destination = File('${folder.path}/custom_logo.$fileExtension');
        if (file.absolute.path != destination.absolute.path) {
          // Copy first and store the path only after it succeeds. The user's
          // gallery/cache file can disappear after the picker closes.
          await file.copy(destination.path);
        }
        savedPath = destination.path;
      }
      await Hive.box('settings').putAll({
        JotifyBranding.nameKey: name == JotifyBranding.defaultName ? '' : name,
        JotifyBranding.iconKey: savedPath ?? '',
      });
      if (!mounted) return;
      setState(() {
        _draftIconPath = savedPath;
        _dirty = false;
      });
      _message('Saved! Your in-app name and logo have changed.');
    } catch (error) {
      _message('Could not save: $error');
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _reset() async {
    setState(() => _saving = true);
    try {
      await Hive.box('settings').putAll({
        JotifyBranding.nameKey: '',
        JotifyBranding.iconKey: '',
      });
      if (!mounted) return;
      _nameController.text = JotifyBranding.defaultName;
      setState(() {
        _draftIconPath = null;
        _dirty = false;
      });
      _message('Restored Jotify name and logo.');
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _pinShortcut() async {
    if (_dirty) {
      _message('Tap Save Changes before creating the shortcut.');
      return;
    }
    try {
      final result = await _channel.invokeMethod<String>(
        'pinShortcut',
        {
          'name': JotifyBranding.name,
          'iconPath': JotifyBranding.customIconPath,
        },
      );
      switch (result) {
        case 'requested':
          _message('Approve the Add to Home screen prompt on your phone.');
          break;
        case 'updated':
          _message('Existing Jotify shortcut updated.');
          break;
        default:
          _message('Your launcher cannot add a custom shortcut.');
      }
    } on PlatformException catch (error) {
      _message(error.message ?? 'Could not create shortcut.');
    } on MissingPluginException {
      _message('Custom shortcuts are available on supported Android phones only.');
    }
  }

  @override
  Widget build(BuildContext context) {
    final path = _draftIconPath;
    final accent = Theme.of(context).colorScheme.secondary;
    return GradientContainer(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          title: const Text('Custom App Name & Icon'),
        ),
        body: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const SizedBox(height: 8),
            Center(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(24),
                child: SizedBox.square(
                  dimension: 112,
                  child: path == null
                      ? Image.asset('assets/ic_launcher.png', fit: BoxFit.cover)
                      : Image.file(
                          File(path),
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => Image.asset(
                            'assets/ic_launcher.png',
                            fit: BoxFit.cover,
                          ),
                        ),
                ),
              ),
            ),
            const SizedBox(height: 12),
            Center(
              child: Text(
                _nameController.text.trim().isEmpty
                    ? JotifyBranding.defaultName
                    : _nameController.text.trim(),
                style: Theme.of(context).textTheme.titleLarge,
                textAlign: TextAlign.center,
              ),
            ),
            const SizedBox(height: 30),
            TextField(
              controller: _nameController,
              maxLength: 30,
              textCapitalization: TextCapitalization.words,
              decoration: const InputDecoration(
                labelText: 'Custom App Name',
                hintText: 'e.g. RJ Krishna',
                prefixIcon: Icon(Icons.drive_file_rename_outline),
                border: OutlineInputBorder(),
              ),
              onChanged: (_) => setState(() => _dirty = true),
            ),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              onPressed: _saving ? null : _pickImage,
              icon: const Icon(Icons.photo_library_outlined),
              label: const Text('Choose Logo from Gallery'),
            ),
            const SizedBox(height: 16),
            FilledButton.icon(
              onPressed: _saving ? null : _save,
              icon: const Icon(Icons.save_outlined),
              label: Text(_saving ? 'Saving...' : 'Save Changes'),
            ),
            TextButton.icon(
              onPressed: _saving ? null : _reset,
              icon: const Icon(Icons.restore),
              label: const Text('Restore Default Jotify'),
            ),
            const SizedBox(height: 20),
            Divider(color: accent.withOpacity(0.3)),
            const SizedBox(height: 8),
            Text('Home screen icon', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            const Text(
              'On Android, the installed app icon is fixed by the APK. '
              'You can add or update a Home screen shortcut using your custom name and photo. '
              'The original Jotify icon in the app drawer stays unchanged.',
            ),
            const SizedBox(height: 14),
            if (Platform.isAndroid)
              OutlinedButton.icon(
                onPressed: _saving ? null : _pinShortcut,
                icon: const Icon(Icons.add_to_home_screen),
                label: const Text('Add Custom Home Screen Shortcut'),
              )
            else
              const Text('Custom Home screen shortcuts are supported on Android only.'),
            const SizedBox(height: 10),
            const Text(
              'Some Android launchers may not support custom shortcuts. '
              'Confirm the system prompt if shown.',
              style: TextStyle(fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }
}
