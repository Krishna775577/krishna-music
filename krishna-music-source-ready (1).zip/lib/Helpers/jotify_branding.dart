import 'dart:io';

import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';

/// Runtime branding used inside Jotify. Android's original installed launcher
/// identity is a build-time resource; a custom pinned shortcut is supported
/// separately by the Android platform implementation.
class JotifyBranding {
  static const defaultName = 'Jotify';
  static const nameKey = 'customAppName';
  static const iconKey = 'customAppIconPath';

  static Box get _settings => Hive.box('settings');

  static String get name {
    final value = _settings.get(nameKey);
    if (value is String && value.trim().isNotEmpty) {
      return value.trim();
    }
    return defaultName;
  }

  static String? get customIconPath {
    final value = _settings.get(iconKey);
    if (value is String && value.isNotEmpty && File(value).existsSync()) {
      return value;
    }
    return null;
  }

  static Widget logo({double size = 64}) {
    final path = customIconPath;
    return ClipRRect(
      borderRadius: BorderRadius.circular(size * 0.23),
      child: SizedBox.square(
        dimension: size,
        child: path == null
            ? Image.asset('assets/ic_launcher.png', fit: BoxFit.cover)
            : Image.file(
                File(path),
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Image.asset(
                  'assets/ic_launcher.png',
                  fit: BoxFit.cover,
                ),
              ),
      ),
    );
  }
}
