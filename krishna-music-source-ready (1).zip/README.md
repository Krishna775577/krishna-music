# Jotify 🎵

Music player customized by **Krishna Bajaj**, based on the open-source **BlackHole** project.

This repository preserves the original authorship and license notices. Original BlackHole code is © 2021–2023 Ankit Sangwan; new Jotify modifications are credited to Krishna Bajaj. Changing branding does not transfer ownership of the original code.

The Android application ID and local Hive database path remain unchanged so existing Jotify/BlackHole installs can upgrade without losing settings or downloaded music. Dart package imports use `package:jotify/`.

---

## Original project documentation

# Jotify 🎵

**Jotify** is a Flutter music player customized from the open-source BlackHole project.

![Jotify icon](assets/ic_launcher.png)

## Features
- Saavn song search with more initial results and a paginated **View All** screen.
- `Khama Ray Khama` searches additionally check `Khama` and `Khamma` spelling variants.
- Saavn audio playback, library, downloads, playlists and YouTube in-app video player (as supported).
- Custom launcher logo and **Jotify** app display branding.

## Build

The `.github/workflows/import-and-build.yml` workflow (when present in the repository) builds a debug APK using Flutter 3.19.6.
An existing repository can apply updates by uploading `krishna-music-source-ready.zip` to its root and running the import workflow.

## About / attribution
This project is based on [BlackHole by Ankit Sangwan](https://github.com/Sangwan5688/BlackHole). Original copyright notices and the included license have been kept. This rebranding does not imply any endorsement from the original authors or music services.

Search completeness depends on Saavn's indexed catalog and unofficial API availability. YouTube embeds may be restricted by video owners.
