# Jotify — Custom App Name & Icon

## User-facing Settings feature

Settings → Custom App Name & Icon

- Rename the app *inside* the Flutter UI. The name is shown in the app title,
  Home drawer header, and About screen.
- Choose a gallery picture as an in-app logo. The image is copied to private
  app support storage and its path stored in Hive settings.
- Save Changes / Restore Default Jotify.
- On Android 8+ with a supported launcher, tap **Add Custom Home Screen
  Shortcut** and approve the system prompt. This creates a Home screen shortcut
  displaying your chosen name/icon and launching the same installed app.
- When a pinned shortcut with the same internal ID already exists, the app
  requests its update; the launcher may refresh it later.

## Android limitations

A running Flutter/Android app cannot arbitrarily replace the installed APK's
package manager label or original app-drawer launcher icon with any photo. The
original app-drawer icon/name remain Jotify. The app's own UI and the optional
Home screen shortcut carry the selected name and logo. Android launchers may
not support shortcut pinning; user approval is required.

## Technical scope

No new pubspec dependencies required: this project already contains `file_picker`,
`path_provider`, and `hive_flutter`. A `JotifyActivity` subclass of
`com.ryanheise.audioservice.AudioServiceActivity` registers a MethodChannel
for shortcut pinning, preserving the audio-service base activity. Playback and
music-service files are unchanged.

## Build/test checklist

- Run `flutter pub get` and `flutter analyze` with Flutter 3.19.6.
- Run `flutter build apk --debug` in GitHub Actions.
- On a device, change name/photo; reopen app; check MaterialApp title,
  Home header, and About screen.
- On Android 8+ pin shortcut, approve system prompt, tap to launch app.
- Test Saavn audio play and YouTube/YtMusic embedded video after the manifest
  activity subclass change.

The package has undergone static file/content checks only; native Flutter +
Android compilation and device runtime testing are still required.
