package com.shadow.blackhole

import android.content.Intent
import android.content.pm.ShortcutInfo
import android.content.pm.ShortcutManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.drawable.Icon
import android.os.Build
import com.ryanheise.audioservice.AudioServiceActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.File

/**
 * Keeps AudioServiceActivity's behavior, adding a user-requested Android 8+
 * pinned shortcut for a custom name and gallery image. The APK's standard
 * launcher label and icon remain Jotify, per Android platform limitations.
 */
class JotifyActivity : AudioServiceActivity() {
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "jotify/custom_branding")
            .setMethodCallHandler { call, result ->
                if (call.method != "pinShortcut") {
                    result.notImplemented()
                    return@setMethodCallHandler
                }
                try {
                    val name = call.argument<String>("name")?.trim().orEmpty()
                    val path = call.argument<String>("iconPath")
                    if (name.isEmpty() || name.length > 30) {
                        result.error("invalid_name", "Name must be 1 to 30 characters.", null)
                    } else {
                        result.success(createOrUpdateShortcut(name, path))
                    }
                } catch (error: Exception) {
                    result.error("shortcut_failed", "Could not make shortcut: ${error.message}", null)
                }
            }
    }

    private fun createOrUpdateShortcut(name: String, imagePath: String?): String {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return "unsupported"
        val manager = getSystemService(ShortcutManager::class.java) ?: return "unsupported"
        if (!manager.isRequestPinShortcutSupported) return "unsupported"

        val icon = if (!imagePath.isNullOrBlank()) {
            val bitmap = scaledSquareBitmap(imagePath)
            if (bitmap != null) Icon.createWithBitmap(bitmap)
            else Icon.createWithResource(this, R.mipmap.ic_launcher)
        } else {
            Icon.createWithResource(this, R.mipmap.ic_launcher)
        }
        val launch = Intent(this, JotifyActivity::class.java)
            .setAction(Intent.ACTION_MAIN)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val shortcut = ShortcutInfo.Builder(this, "jotify_custom_launcher")
            .setShortLabel(name)
            .setLongLabel(name)
            .setIcon(icon)
            .setIntent(launch)
            .build()
        val existing = manager.pinnedShortcuts.any { it.id == shortcut.id }
        return if (existing) {
            manager.updateShortcuts(listOf(shortcut))
            "updated"
        } else if (manager.requestPinShortcut(shortcut, null)) {
            // A successful return means the request was accepted; pinning still
            // requires the user to approve the system/launcher confirmation.
            "requested"
        } else {
            "unsupported"
        }
    }

    private fun scaledSquareBitmap(path: String): Bitmap? {
        val file = File(path)
        if (!file.exists() || file.length() > 12L * 1024L * 1024L) return null
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        val sample = BitmapFactory.Options().apply {
            var size = 1
            while (bounds.outWidth / size > 512 || bounds.outHeight / size > 512) {
                size *= 2
            }
            inSampleSize = size
        }
        val source = BitmapFactory.decodeFile(path, sample) ?: return null
        val side = minOf(source.width, source.height).toFloat()
        val left = (source.width - side) / 2
        val top = (source.height - side) / 2
        val output = Bitmap.createBitmap(192, 192, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        canvas.drawBitmap(
            source,
            Rect(left.toInt(), top.toInt(), (left + side).toInt(), (top + side).toInt()),
            RectF(0f, 0f, 192f, 192f),
            paint
        )
        if (source != output) source.recycle()
        return output
    }
}
