# Jotify — branding and attribution

App name / UI customization: **Jotify**, customized by **Krishna Bajaj**.

Original open-source project: **BlackHole** by **Ankit Sangwan** (2021–2023).
The license and copyright headers in upstream source code are deliberately preserved.

Technical identifiers intentionally unchanged for compatibility:
- Android applicationId and Kotlin namespace: `com.shadow.blackhole`. Changing this would install a different app and disconnect existing local settings and downloads.
- Hive database directory: `BlackHole/Database` and `BlackHole/` legacy DB paths.
- Android widget classes/resource names and old deep links, which may be referenced by installed widgets/links.
- Google/Firebase IDs in iOS configuration refer to an existing remote project and cannot safely be renamed without new credentials.

The app-facing name, package import alias, publisher display name, localized developer credit, website title, and sharing links now use Jotify / Krishna Bajaj. No original creator payment links are advertised as new developer links.

## Validation

Local static checks only. Android APK build and real device playback not independently verified.
