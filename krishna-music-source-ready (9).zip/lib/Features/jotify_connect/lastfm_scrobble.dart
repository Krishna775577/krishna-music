import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:audio_service/audio_service.dart';
import 'package:crypto/crypto.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:hive/hive.dart';
import 'package:url_launcher/url_launcher.dart';

/// Last.fm 2.0 authenticated client. User supplies their own API credentials;
/// API secret is held in the device keychain, never committed in the repo.
class JotifyLastFm {
  static const _storage = FlutterSecureStorage();
  static const _root = 'https://ws.audioscrobbler.com/2.0/';
  static String get apiKey => Hive.box('settings').get('j8LastFmKey', defaultValue: '').toString();
  static String? _pendingToken;
  static StreamSubscription<MediaItem?>? _media;
  static StreamSubscription<PlaybackState>? _state;
  static Timer? _tick;
  static MediaItem? _current;
  static int _playSeconds = 0;
  static int _startedAt = 0;
  static bool _playing = false;
  static bool _sent = false;
  static bool _busy = false;
  static bool _enabled = false;

  static Future<void> configure(String key, String secret) async {
    await Hive.box('settings').put('j8LastFmKey', key.trim());
    if (secret.trim().isNotEmpty) await _storage.write(key: 'j8_lastfm_secret', value: secret.trim());
  }

  static String _sign(Map<String, String> params, String secret) {
    final keys = params.keys.where((s) => s != 'format' && s != 'callback').toList()..sort();
    final raw = keys.map((s) => '$s${params[s]}').join() + secret;
    return md5.convert(utf8.encode(raw)).toString();
  }

  static Future<Map<String, dynamic>> _request(Map<String, String> fields) async {
    final secret = await _storage.read(key: 'j8_lastfm_secret');
    if (apiKey.isEmpty || secret == null || secret.isEmpty) throw StateError('Enter Last.fm API key and shared secret');
    final params = {...fields, 'api_key': apiKey};
    params['api_sig'] = _sign(params, secret);
    params['format'] = 'json';
    final client = HttpClient();
    try {
      final request = await client.postUrl(Uri.parse(_root)).timeout(const Duration(seconds: 20));
      request.headers.contentType = ContentType('application', 'x-www-form-urlencoded', charset: 'utf-8');
      request.write(params.entries.map((e) => '${Uri.encodeQueryComponent(e.key)}=${Uri.encodeQueryComponent(e.value)}').join('&'));
      final response = await request.close().timeout(const Duration(seconds: 20));
      final body = await utf8.decoder.bind(response).join();
      final data = Map<String, dynamic>.from(jsonDecode(body) as Map);
      if (response.statusCode >= 400 || data.containsKey('error')) {
        throw StateError('Last.fm: ${data['message'] ?? response.statusCode}');
      }
      return data;
    } finally { client.close(force: true); }
  }

  static Future<void> beginAuthorization() async {
    final token = await _request({'method': 'auth.getToken'});
    _pendingToken = token['token']?.toString();
    if (_pendingToken == null) throw StateError('Last.fm did not provide a token');
    await _storage.write(key: 'j8_lastfm_pending', value: _pendingToken);
    final url = Uri.https('www.last.fm', '/api/auth/', {'api_key': apiKey, 'token': _pendingToken});
    if (!await launchUrl(url, mode: LaunchMode.externalApplication)) throw StateError('Unable to open Last.fm authorization');
  }

  static Future<void> finishAuthorization() async {
    final token = _pendingToken ?? await _storage.read(key: 'j8_lastfm_pending');
    if (token == null) throw StateError('First tap Authorize in browser');
    final data = await _request({'method': 'auth.getSession', 'token': token});
    final session = data['session'];
    if (session is! Map || session['key'] == null) throw StateError('Last.fm authorization incomplete');
    await _storage.write(key: 'j8_lastfm_session', value: session['key'].toString());
    _enabled = true;
    await Hive.box('settings').put('j8LastFmUser', session['name'].toString());
    await _storage.delete(key: 'j8_lastfm_pending');
    _pendingToken = null;
  }

  static Future<void> disconnect() async {
    _enabled = false;
    await _storage.delete(key: 'j8_lastfm_session');
    await _storage.delete(key: 'j8_lastfm_secret');
    await Hive.box('settings').delete('j8LastFmUser');
  }

  static Future<void> start(AudioHandler handler) async {
    if (_media != null) return;
    _enabled = await _storage.read(key: 'j8_lastfm_session') != null;
    _media = handler.mediaItem.listen((item) {
      if (_current?.id != item?.id) {
        _tryScrobble();
        _current = item;
        _startedAt = DateTime.now().millisecondsSinceEpoch ~/ 1000;
        _playSeconds = 0;
        _sent = false;
        if (item != null) _nowPlaying(item);
      }
    });
    _state = handler.playbackState.listen((state) { _playing = state.playing; });
    _tick = Timer.periodic(const Duration(seconds: 10), (_) {
      if (_playing && _current != null) _playSeconds += 10;
      _tryScrobble();
      _flushPending();
    });
  }

  /// Last.fm: play >= half duration or 240s, duration >= 30s.
  static void _tryScrobble() {
    final item = _current;
    if (item == null || !_enabled || _sent || !_eligible(item)) return;
    final seconds = item.duration?.inSeconds ?? 180;
    if (_playSeconds < min(seconds ~/ 2, 240)) return;
    _sent = true;
    final event = <String, dynamic>{
      'artist': item.artist ?? '', 'track': item.title, 'album': item.album ?? '',
      'timestamp': _startedAt,
    };
    final box = Hive.box('settings');
    final pending = List<Map>.from(box.get('j8LastFmPending', defaultValue: <Map>[]) as List);
    pending.add(event);
    box.put('j8LastFmPending', pending.take(100).toList());
    _flushPending();
  }

  static bool _eligible(MediaItem item) =>
      item.title.trim().isNotEmpty && (item.artist ?? '').trim().isNotEmpty &&
      (item.duration?.inSeconds ?? 180) >= 30 &&
      Hive.box('settings').get('v4PrivateListening', defaultValue: false) != true;

  static Future<void> _nowPlaying(MediaItem item) async {
    if (!_eligible(item)) return;
    final sk = await _storage.read(key: 'j8_lastfm_session');
    if (sk == null) return;
    try { await _request({'method': 'track.updateNowPlaying', 'sk': sk,
      'artist': item.artist ?? '', 'track': item.title, 'album': item.album ?? ''});
    } catch (_) { /* Offline or provider problem: don't interrupt playback. */ }
  }

  static Future<void> _flushPending() async {
    if (_busy) return;
    final sk = await _storage.read(key: 'j8_lastfm_session');
    if (sk == null) return;
    _busy = true;
    try {
      final box = Hive.box('settings');
      final pending = List<Map>.from(box.get('j8LastFmPending', defaultValue: <Map>[]) as List);
      while (pending.isNotEmpty) {
        final event = pending.first;
        await _request({'method': 'track.scrobble', 'sk': sk,
          'artist': event['artist'].toString(), 'track': event['track'].toString(),
          'album': event['album'].toString(), 'timestamp': event['timestamp'].toString()});
        pending.removeAt(0);
        await box.put('j8LastFmPending', pending);
      }
    } catch (_) { /* Keep queue for retry. */ }
    finally { _busy = false; }
  }
}
