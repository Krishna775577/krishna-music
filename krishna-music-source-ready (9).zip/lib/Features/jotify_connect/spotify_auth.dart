import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:app_links/app_links.dart';
import 'package:crypto/crypto.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:hive/hive.dart';
import 'package:url_launcher/url_launcher.dart';

/// Spotify Web API read-only OAuth/PKCE bridge. Never downloads Spotify audio.
/// Tokens are stored in platform secure storage. Client ID belongs to the user.
class JotifySpotify {
  static const redirectUri = 'jotify://spotify-callback';
  static const _secure = FlutterSecureStorage();
  static const _endpoint = 'https://api.spotify.com/v1';
  static final AppLinks _links = AppLinks();
  static StreamSubscription<Uri>? _linkSub;
  static Future<void> Function(String)? onMessage;
  static String get clientId => Hive.box('settings').get('j8SpotifyClientId', defaultValue: '').toString().trim();

  static void attach() {
    if (_linkSub != null) return;
    _linkSub = _links.uriLinkStream.listen((uri) { handleLink(uri).catchError((Object e) { onMessage?.call('$e'); }); });
    _links.getInitialAppLink().then((uri) { if (uri != null) handleLink(uri).catchError((Object e) { onMessage?.call('$e'); }); });
  }

  static Future<void> setClientId(String id) async {
    if (id.isNotEmpty && !RegExp(r'^[a-fA-F0-9]{32}$').hasMatch(id.trim())) {
      throw const FormatException('Spotify Client ID should be 32 hex characters');
    }
    await Hive.box('settings').put('j8SpotifyClientId', id.trim());
  }

  static String _random(int n) {
    const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-._~';
    final rand = Random.secure();
    return List.generate(n, (_) => chars[rand.nextInt(chars.length)]).join();
  }

  static Future<void> login() async {
    if (clientId.isEmpty) throw StateError('Enter your Spotify Client ID first');
    final verifier = _random(64);
    final challenge = base64Url.encode(sha256.convert(ascii.encode(verifier)).bytes).replaceAll('=', '');
    final state = _random(28);
    await _secure.write(key: 'j8_spotify_verifier', value: verifier);
    await _secure.write(key: 'j8_spotify_state', value: state);
    final uri = Uri.https('accounts.spotify.com', '/authorize', {
      'response_type': 'code', 'client_id': clientId, 'redirect_uri': redirectUri,
      'code_challenge_method': 'S256', 'code_challenge': challenge, 'state': state,
      'scope': 'user-read-private user-library-read playlist-read-private playlist-read-collaborative',
    });
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw StateError('Could not open Spotify authorization');
    }
  }

  static Future<void> handleLink(Uri uri) async {
    if (uri.scheme != 'jotify' || uri.host != 'spotify-callback') return;
    final expectedState = await _secure.read(key: 'j8_spotify_state');
    if (uri.queryParameters['state'] == null || uri.queryParameters['state'] != expectedState) {
      throw StateError('Spotify login state mismatch; login again');
    }
    final code = uri.queryParameters['code'];
    if (code == null || code.isEmpty) throw StateError('Spotify login cancelled: ${uri.queryParameters['error'] ?? 'unknown'}');
    final verifier = await _secure.read(key: 'j8_spotify_verifier');
    if (verifier == null) throw StateError('Login expired. Start again');
    final response = await _form(Uri.https('accounts.spotify.com', '/api/token'), {
      'grant_type': 'authorization_code', 'client_id': clientId,
      'redirect_uri': redirectUri, 'code': code, 'code_verifier': verifier,
    });
    await _saveTokens(response);
    await _secure.delete(key: 'j8_spotify_verifier');
    await _secure.delete(key: 'j8_spotify_state');
    await onMessage?.call('Spotify connected. Tap Sync library.');
  }

  static Future<Map<String, dynamic>> _form(Uri uri, Map<String, String> payload) async {
    final http = HttpClient();
    try {
      final request = await http.postUrl(uri).timeout(const Duration(seconds: 25));
      request.headers.contentType = ContentType('application', 'x-www-form-urlencoded', charset: 'utf-8');
      request.write(payload.entries.map((e) => '${Uri.encodeQueryComponent(e.key)}=${Uri.encodeQueryComponent(e.value)}').join('&'));
      final response = await request.close().timeout(const Duration(seconds: 25));
      final decoded = jsonDecode(await utf8.decoder.bind(response).join());
      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw StateError('Spotify auth HTTP ${response.statusCode}: ${decoded.toString()}');
      }
      return Map<String, dynamic>.from(decoded as Map);
    } finally { http.close(force: true); }
  }

  static Future<void> _saveTokens(Map<String, dynamic> data) async {
    final access = data['access_token']?.toString();
    if (access == null || access.isEmpty) throw StateError('Spotify did not return an access token');
    await _secure.write(key: 'j8_spotify_access', value: access);
    if (data['refresh_token'] != null) await _secure.write(key: 'j8_spotify_refresh', value: data['refresh_token'].toString());
    final seconds = (data['expires_in'] as num?)?.toInt() ?? 3600;
    await _secure.write(key: 'j8_spotify_expiry', value: DateTime.now().add(Duration(seconds: seconds - 60)).millisecondsSinceEpoch.toString());
  }

  static Future<String> _token() async {
    final cached = await _secure.read(key: 'j8_spotify_access');
    if (cached == null) throw StateError('Connect Spotify first');
    final expiry = int.tryParse(await _secure.read(key: 'j8_spotify_expiry') ?? '') ?? 0;
    if (DateTime.now().millisecondsSinceEpoch < expiry) return cached;
    final refresh = await _secure.read(key: 'j8_spotify_refresh');
    if (refresh == null) throw StateError('Spotify session expired; login again');
    await _saveTokens(await _form(Uri.https('accounts.spotify.com', '/api/token'), {
      'grant_type': 'refresh_token', 'refresh_token': refresh, 'client_id': clientId,
    }));
    return (await _secure.read(key: 'j8_spotify_access'))!;
  }

  static Future<Map<String, dynamic>> _get(String path) async {
    final token = await _token();
    final http = HttpClient();
    try {
      final request = await http.getUrl(Uri.parse('$_endpoint$path')).timeout(const Duration(seconds: 25));
      request.headers.set('Authorization', 'Bearer $token');
      final response = await request.close().timeout(const Duration(seconds: 25));
      final body = await utf8.decoder.bind(response).join();
      if (response.statusCode == 429) throw StateError('Spotify rate limit. Retry after ${response.headers.value('retry-after') ?? '?'} seconds');
      if (response.statusCode < 200 || response.statusCode >= 300) throw StateError('Spotify HTTP ${response.statusCode}: ${body.substring(0, min(body.length, 250))}');
      return Map<String, dynamic>.from(jsonDecode(body) as Map);
    } finally { http.close(force: true); }
  }

  static Future<List<Map<String, dynamic>>> _page(String path, {int pageLimit = 20}) async {
    final result = <Map<String, dynamic>>[];
    var next = path;
    for (var page = 0; page < pageLimit && next.isNotEmpty; page++) {
      final data = await _get(next);
      for (final raw in (data['items'] as List? ?? [])) {
        if (raw is Map) result.add(Map<String, dynamic>.from(raw));
      }
      final url = data['next']?.toString();
      final uri = url == null ? null : Uri.tryParse(url);
      next = (uri != null && uri.host == 'api.spotify.com' && uri.scheme == 'https')
          ? uri.toString().replaceFirst(_endpoint, '') : '';
    }
    return result;
  }

  /// Fetches own profile, liked tracks, playlists (incl. private) and playlist
  /// item metadata. Every entry keeps original Spotify link for attribution.
  static Future<Map<String, dynamic>> syncLibrary() async {
    final profile = await _get('/me');
    final saved = await _page('/me/tracks?limit=50');
    final playlists = await _page('/me/playlists?limit=50');
    final collections = <Map<String, dynamic>>[];
    for (final p in playlists) {
      final id = p['id']?.toString();
      if (id == null || !RegExp(r'^[A-Za-z0-9]+$').hasMatch(id)) continue;
      try {
        final items = await _page('/playlists/$id/items?limit=50', pageLimit: 20);
        collections.add({'name': p['name'], 'id': id, 'url': (p['external_urls'] as Map?)?['spotify'],
          'tracks': items.map(_normalizeTrack).whereType<Map<String, dynamic>>().toList()});
      } catch (e) {
        collections.add({'name': p['name'], 'id': id, 'error': '$e', 'tracks': <Map<String, dynamic>>[]});
      }
    }
    final snapshot = <String, dynamic>{
      'name': profile['display_name'] ?? profile['id'], 'id': profile['id'],
      'syncedAt': DateTime.now().toIso8601String(),
      'liked': saved.map(_normalizeTrack).whereType<Map<String, dynamic>>().toList(),
      'playlists': collections,
    };
    await Hive.box('settings').put('j8SpotifySnapshot', snapshot);
    return snapshot;
  }

  static Map<String, dynamic>? _normalizeTrack(Map<String, dynamic> wrapper) {
    final raw = wrapper['item'] ?? wrapper['track'] ?? wrapper;
    if (raw is! Map || raw['type'] != 'track') return null;
    final artists = raw['artists'] as List? ?? [];
    return {
      'name': raw['name']?.toString() ?? '',
      'artist': artists.whereType<Map>().map((a) => a['name']?.toString() ?? '').join(', '),
      'spotifyId': raw['id']?.toString(),
      'durationMs': raw['duration_ms'],
      'url': (raw['external_urls'] as Map?)?['spotify']?.toString(),
    };
  }

  static Future<void> logout() async {
    for (final key in ['j8_spotify_access', 'j8_spotify_refresh', 'j8_spotify_expiry', 'j8_spotify_verifier', 'j8_spotify_state']) {
      await _secure.delete(key: key);
    }
    await Hive.box('settings').delete('j8SpotifySnapshot');
  }
}
