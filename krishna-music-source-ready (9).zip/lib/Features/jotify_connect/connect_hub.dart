import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get_it/get_it.dart';
import 'package:hive/hive.dart';
import 'package:jotify/Features/jotify_connect/spotify_auth.dart';
import 'package:jotify/Features/jotify_connect/lastfm_scrobble.dart';
import 'package:jotify/Features/jotify_connect/jam_lan.dart';
import 'package:jotify/Features/jotify_connect/plugin_registry.dart';
import 'package:jotify/Features/jotify_connect/youtube_embed.dart';
import 'package:jotify/Features/jotify_connect/lan_discovery.dart';
import 'package:jotify/Features/jotify_connect/provider_contracts.dart';
import 'package:jotify/Features/jotify_connect/spotify_import.dart';
import 'package:jotify/Features/jotify_connect/metadata_search_page.dart';
import 'package:jotify/Screens/Search/search.dart';
import 'package:jotify/Services/audio_service.dart';
import 'package:url_launcher/url_launcher.dart';

class JotifyConnectHub extends StatelessWidget {
  const JotifyConnectHub({super.key});
  @override
  Widget build(BuildContext context) {
    Widget row(String title, String caption, IconData icon, Widget page) =>
        ListTile(leading: Icon(icon), title: Text(title), subtitle: Text(caption),
          trailing: const Icon(Icons.chevron_right), onTap: () => Navigator.of(context).push(
            MaterialPageRoute<void>(builder: (_) => page)));
    return Scaffold(appBar: AppBar(title: const Text('Jotify V9 · Spotube Parity Lab')),
      body: ListView(padding: const EdgeInsets.all(12), children: [
        const Padding(padding: EdgeInsets.all(8), child: Text('Saavn/local player remains available. Connect optional services below. No hidden stream extraction.')),
        row('Spotify account & library', 'PKCE login, liked tracks and playlists (metadata only)', Icons.library_music, const _SpotifyPanel()),
        row('YouTube in-app videos', 'Official embeds, video search; YouTube Music link', Icons.smart_display, const JotifyYouTubePage()),
        row('Metadata Search Studio', 'MusicBrainz/Saavn discovery and matching', Icons.travel_explore, const JotifyMetadataSearchPage()),
        row('Plugins & provider capabilities', 'Typed provider list + permissioned discovery links', Icons.extension, const _PluginsPanel()),
        row('LAN Jams & device remote', 'Auto-detect nearby rooms, pair code, Saavn sync and controls', Icons.devices, const _JamPanel()),
        row('Last.fm scrobbling', 'Account authentication, play tracking, offline retry', Icons.history, const _LastFmPanel()),
        const SizedBox(height: 18),
        const Text('Required: Spotify developer Client ID, optional YouTube Data API key and Last.fm developer keys. Local Jam works without a cloud server.', textAlign: TextAlign.center),
      ]),
    );
  }
}

class _SpotifyPanel extends StatefulWidget {
  const _SpotifyPanel();
  @override
  State<_SpotifyPanel> createState() => _SpotifyPanelState();
}
class _SpotifyPanelState extends State<_SpotifyPanel> {
  final _id = TextEditingController();
  bool _busy = false;
  String _status = 'Connect Spotify to sync your library metadata.';
  @override
  void initState() { super.initState(); _id.text = JotifySpotify.clientId;
    JotifySpotify.onMessage = (m) async { if (mounted) setState(() => _status = m); };
  }
  @override
  void dispose() { JotifySpotify.onMessage = null; _id.dispose(); super.dispose(); }
  Future<void> _run(Future<void> Function() operation) async {
    setState(() => _busy = true);
    try { await operation(); if (mounted) setState(() => _status = 'Completed'); }
    catch (e) { if (mounted) setState(() => _status = '$e'); }
    finally { if (mounted) setState(() => _busy = false); }
  }
  @override
  Widget build(BuildContext context) {
    final box = Hive.box('settings');
    final cache = box.get('j8SpotifySnapshot');
    final snapshot = cache is Map ? cache : <String, dynamic>{};
    final liked = snapshot['liked'] is List ? snapshot['liked'] as List : <dynamic>[];
    final playlists = snapshot['playlists'] is List ? snapshot['playlists'] as List : <dynamic>[];
    return Scaffold(appBar: AppBar(title: const Text('Spotify Library')), body: ListView(padding: const EdgeInsets.all(16), children: [
      const Text('Spotify content attribution and links remain on Spotify. Jotify does not download or decode Spotify audio.'),
      TextField(controller: _id, decoration: const InputDecoration(labelText: 'Spotify App Client ID', helperText: 'Register jotify://spotify-callback in Spotify developer dashboard')),
      const SizedBox(height: 10),
      FilledButton(onPressed: _busy ? null : () => _run(() async { await JotifySpotify.setClientId(_id.text); await JotifySpotify.login(); }), child: const Text('Connect Spotify (PKCE)')),
      FilledButton.tonal(onPressed: _busy ? null : () => _run(() async { final data = await JotifySpotify.syncLibrary(); if (mounted) setState(() => _status = 'Synced ${ (data['liked'] as List).length} liked tracks and ${(data['playlists'] as List).length} playlists'); }), child: const Text('Sync liked tracks + playlists')),
      TextButton(onPressed: _busy ? null : () => _run(() async { await JotifySpotify.logout(); setState(() {}); }), child: const Text('Disconnect and clear cached Spotify metadata')),
      Padding(padding: const EdgeInsets.symmetric(vertical: 10), child: Text(_status)),
      if (snapshot.isNotEmpty) ...[
        Text('Account: ${snapshot['name']} · Last sync: ${snapshot['syncedAt']}', style: Theme.of(context).textTheme.bodySmall),
        ListTile(title: Text('Liked tracks (${liked.length})'), trailing: const Icon(Icons.chevron_right),
          onTap: () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => _SpotifyTrackList('Liked tracks', liked)))),
        for (final raw in playlists) if (raw is Map) ListTile(
          title: Text(raw['name']?.toString() ?? 'Playlist'),
          subtitle: Text('${(raw['tracks'] as List?)?.length ?? 0} tracks${raw['error'] != null ? ' · sync error' : ''}'),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => _SpotifyTrackList(
            raw['name']?.toString() ?? 'Playlist', raw['tracks'] as List? ?? [])))),
      ],
    ]));
  }
}
class _SpotifyTrackList extends StatelessWidget {
  final String title;
  final List tracks;
  const _SpotifyTrackList(this.title, this.tracks);
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(title)), body: Column(children: [
      Padding(padding: const EdgeInsets.all(12), child: FilledButton.icon(
        icon: const Icon(Icons.playlist_add), label: const Text('Match & import into Jotify (Saavn)'),
        onPressed: tracks.isEmpty ? null : () => Navigator.push(context, MaterialPageRoute<void>(
          builder: (_) => JotifySpotifyImportPage(name: title, tracks: tracks),
        )),
      )),
      Expanded(child: ListView.builder(itemCount: tracks.length, itemBuilder: (context, index) {
      final raw = tracks[index];
      if (raw is! Map) return const SizedBox();
      final name = raw['name']?.toString() ?? '';
      final artist = raw['artist']?.toString() ?? '';
      return ListTile(title: Text(name), subtitle: Text(artist),
        trailing: IconButton(tooltip: 'View on Spotify', icon: const Icon(Icons.open_in_new), onPressed: () {
          final uri = Uri.tryParse(raw['url']?.toString() ?? '');
          if (uri != null && uri.scheme == 'https' && uri.host == 'open.spotify.com') launchUrl(uri, mode: LaunchMode.externalApplication);
        }),
        onTap: () => Navigator.push(context, MaterialPageRoute<void>(builder: (_) => SearchPage(query: '$name $artist'))),
      );
    })),
    ]),
  );
}

class _LastFmPanel extends StatefulWidget { const _LastFmPanel(); @override State<_LastFmPanel> createState() => _LastFmPanelState(); }
class _LastFmPanelState extends State<_LastFmPanel> {
  final _key = TextEditingController(); final _secret = TextEditingController();
  bool _busy = false; String _status = '';
  @override void initState() { super.initState(); _key.text = JotifyLastFm.apiKey; }
  @override void dispose() { _key.dispose(); _secret.dispose(); super.dispose(); }
  Future<void> _run(Future<void> Function() f) async { setState(() => _busy = true);
    try { await f(); if (mounted) setState(() => _status = 'Success'); }
    catch (e) { if (mounted) setState(() => _status = '$e'); }
    finally { if (mounted) setState(() => _busy = false); }
  }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Last.fm Scrobbling')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      const Text('Get a free API key and shared secret from last.fm/api/account/create. The secret is stored on this device, not in the source code.'),
      TextField(controller: _key, decoration: const InputDecoration(labelText: 'Last.fm API key')),
      TextField(controller: _secret, obscureText: true, decoration: const InputDecoration(labelText: 'Shared secret (never publish it)')),
      FilledButton(onPressed: _busy ? null : () => _run(() async { await JotifyLastFm.configure(_key.text, _secret.text); await JotifyLastFm.beginAuthorization(); }), child: const Text('1. Authorize in Last.fm browser')),
      FilledButton.tonal(onPressed: _busy ? null : () => _run(() async { await JotifyLastFm.finishAuthorization(); await JotifyLastFm.start(GetIt.I<AudioPlayerHandler>()); }), child: const Text('2. I authorized; finish connection')),
      ListTile(title: Text('Account: ${Hive.box('settings').get('j8LastFmUser', defaultValue: 'Not connected')}'),
        subtitle: Text('Queued offline scrobbles: ${(Hive.box('settings').get('j8LastFmPending', defaultValue: <dynamic>[]) as List).length}')),
      TextButton(onPressed: _busy ? null : () => _run(JotifyLastFm.disconnect), child: const Text('Disconnect Last.fm')),
      Text(_status),
    ]));
}

class _JamPanel extends StatefulWidget { const _JamPanel(); @override State<_JamPanel> createState() => _JamPanelState(); }
class _JamPanelState extends State<_JamPanel> {
  final _ip = TextEditingController(); final _code = TextEditingController();
  String _error = '';
  StreamSubscription<String>? _listen;
  StreamSubscription<void>? _nearbySub;
  final nearby = JotifyLanDiscovery.instance;
  final jam = JotifyLanJam.instance;
  @override void initState() {
    super.initState();
    _listen = jam.events.listen((_) { if (mounted) setState(() {}); });
    _nearbySub = nearby.changes.listen((_) { if (mounted) setState(() {}); });
    nearby.start();
  }
  @override void dispose() {
    _listen?.cancel(); _nearbySub?.cancel();
    _ip.dispose(); _code.dispose(); super.dispose();
  }
  Future<void> _run(Future<void> Function() run) async { try { await run(); if (mounted) setState(() => _error = ''); }
    catch (e) { if (mounted) setState(() => _error = '$e'); } }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('LAN Jams + Remote Control')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      const Text('Same Wi-Fi required. Saavn: each device streams from Saavn. Local files: host can opt in to LAN-only audio streaming.'),
      const SizedBox(height: 8),
      FilledButton(onPressed: () => _run(() => jam.startHost(GetIt.I<AudioPlayerHandler>())), child: const Text('Host a Jam on this phone')),
      if (jam.hosting) ...[
        SelectableText('Connect to: ${jam.address}'), SelectableText('Room code: ${jam.roomCode}'),
        SwitchListTile(title: const Text('Allow paired devices to control this phone'), value: jam.allowRemoteControl,
          onChanged: (v) => setState(() => jam.allowRemoteControl = v)),
        SwitchListTile(title: const Text('Share currently playing local audio on LAN'),
          subtitle: const Text('Anyone paired with this room code can hear the file until you turn this off.'),
          value: jam.allowLocalAudioSharing,
          onChanged: (v) => setState(() => jam.allowLocalAudioSharing = v)),
      ],
      const Divider(height: 28),
      const Text('Nearby Jam rooms (auto discovery)', style: TextStyle(fontWeight: FontWeight.bold)),
      const Text('Choose a room, then enter its six-digit code from the host. No code is broadcast.'),
      OutlinedButton.icon(onPressed: () => _run(nearby.start),
        icon: const Icon(Icons.radar), label: const Text('Discover nearby rooms')),
      for (final room in nearby.rooms) if (room.address != jam.address) ListTile(
        leading: const Icon(Icons.devices), title: Text(room.label),
        subtitle: Text(room.address), trailing: const Icon(Icons.chevron_right),
        onTap: () => setState(() { _ip.text = room.address; }),
      ),
      if (nearby.rooms.isEmpty) const Padding(padding: EdgeInsets.all(8),
        child: Text('No room detected. Same Wi-Fi and router broadcast permission required. Manual IP still works.')),
      if (nearby.lastError.isNotEmpty) Text(nearby.lastError),
      const Divider(height: 16),
      TextField(controller: _ip, decoration: const InputDecoration(labelText: 'Host Wi-Fi IP:port (example: 192.168.1.5:40123)')),
      TextField(controller: _code, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: '6-digit room code')),
      FilledButton.tonal(onPressed: () => _run(() => jam.join(GetIt.I<AudioPlayerHandler>(), _ip.text, _code.text)), child: const Text('Join Jam')),
      if (jam.joined) Wrap(spacing: 8, children: [
        IconButton(onPressed: () => jam.sendCommand('previous'), icon: const Icon(Icons.skip_previous)),
        IconButton(onPressed: () => jam.sendCommand('play'), icon: const Icon(Icons.play_arrow)),
        IconButton(onPressed: () => jam.sendCommand('pause'), icon: const Icon(Icons.pause)),
        IconButton(onPressed: () => jam.sendCommand('next'), icon: const Icon(Icons.skip_next)),
      ]),
      OutlinedButton(onPressed: () => _run(jam.disconnect), child: const Text('Leave / Stop hosting')),
      Text(jam.status), if (_error.isNotEmpty) Text(_error, style: const TextStyle(color: Colors.redAccent)),
      const SizedBox(height: 14), const Text('This release supports paired-device LAN playback sync, remote control, and opt-in local-file audio transfer. No Internet-wide cloud Jams, DRM bypass, or retransmission of commercial streams.'),
    ]));
}

class _PluginsPanel extends StatefulWidget { const _PluginsPanel(); @override State<_PluginsPanel> createState() => _PluginsPanelState(); }
class _PluginsPanelState extends State<_PluginsPanel> {
  final _manifest = TextEditingController(); final _query = TextEditingController();
  String _error = '';
  @override void dispose() { _manifest.dispose(); _query.dispose(); super.dispose(); }
  Future<void> _install() async {
    final accepted = await showDialog<bool>(context: context, builder: (context) => AlertDialog(
      title: const Text('Allow external website links?'),
      content: const Text('The discovery plugin can open its configured HTTPS site in your browser. It cannot read your music, credentials or local files. Install only manifests you trust.'),
      actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
        FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Allow & install'))],
    ));
    if (accepted != true) return;
    try { await JotifyDiscoveryPlugins.install(_manifest.text, allowExternalLinks: true);
      if (mounted) setState(() => _error = 'Plugin installed (external links permission granted)');
    } catch (e) { if (mounted) setState(() => _error = '$e'); }
  }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Jotify Plugin Studio')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      const Text('Built-in typed providers below show actual supported capabilities. Optional discovery plugins require approval for opening external HTTPS links; no arbitrary code executes.'),
      const SizedBox(height: 8),
      const Text('Built-in providers', style: TextStyle(fontWeight: FontWeight.bold)),
      for (final provider in JotifyProviderRegistry.builtIn) ListTile(
        leading: const Icon(Icons.extension), title: Text(provider.name),
        subtitle: Text('${provider.notes}\nCapabilities: ${provider.capabilities.map((c) => c.name).join(', ')}'),
        isThreeLine: true,
      ),
      const Divider(height: 28),
      TextField(controller: _query, decoration: const InputDecoration(labelText: 'Song / artist to search')),
      for (final plugin in JotifyDiscoveryPlugins.installed) ListTile(title: Text(plugin['name'] ?? ''),
        subtitle: Text(plugin['url'] ?? '', maxLines: 1),
        onTap: () async { try { await JotifyDiscoveryPlugins.search(plugin['id']!, _query.text); }
          catch (e) { if (mounted) setState(() => _error = '$e'); } },
        trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: () async {
          await JotifyDiscoveryPlugins.uninstall(plugin['id']!); if (mounted) setState(() {});
        })),
      const Divider(height: 30),
      for (final plugin in JotifyDiscoveryPlugins.examples) OutlinedButton(
        onPressed: () { _manifest.text = jsonEncode(plugin); },
        child: Text('Use ${plugin['name']} example')),
      TextField(controller: _manifest, minLines: 3, maxLines: 5, decoration: const InputDecoration(
        labelText: 'JSON manifest', hintText: '{"id":"demo-search","name":"Demo","url":"https://example.org/search?q={query}"}')),
      FilledButton(onPressed: _install, child: const Text('Install discovery plugin')),
      Text(_error),
    ]));
}
