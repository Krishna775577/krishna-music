import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:jotify/Features/jotify_v3/query_tools.dart';
import 'package:jotify/Screens/Search/search.dart';

/// Smart Search is a gateway to existing provider-backed search pages.
/// It does not falsely claim to merge unavailable provider catalogues.
class JotifyV3Search extends StatefulWidget {
  const JotifyV3Search({super.key});

  @override
  State<JotifyV3Search> createState() => _JotifyV3SearchState();
}

class _JotifyV3SearchState extends State<JotifyV3Search> {
  final TextEditingController _query = TextEditingController();
  static const String historyKey = 'v3RecentQueries';

  List<String> get _history {
    final saved = Hive.box('settings').get(historyKey, defaultValue: <String>[]);
    if (saved is! List) return <String>[];
    return saved.map((e) => e.toString()).where((e) => e.isNotEmpty).take(12).toList();
  }

  @override
  void dispose() {
    _query.dispose();
    super.dispose();
  }

  Future<void> _openSearch(String text) async {
    final query = V3QueryTools.normalize(text);
    if (query.isEmpty) return;
    final updated = <String>[query,
      ..._history.where((item) => item.toLowerCase() != query.toLowerCase())
    ].take(12).toList();
    await Hive.box('settings').put(historyKey, updated);
    if (!mounted) return;
    FocusScope.of(context).unfocus();
    setState(() {});
    await Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => SearchPage(query: query, searchType: 'saavn'),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final alternatives = V3QueryTools.suggestions(_query.text);
    return Scaffold(
      appBar: AppBar(title: const Text('Jotify Smart Search 2.0')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 12, 18, 28),
        children: <Widget>[
          TextField(
            controller: _query,
            autofocus: false,
            textInputAction: TextInputAction.search,
            onChanged: (_) => setState(() {}),
            onSubmitted: _openSearch,
            decoration: InputDecoration(
              hintText: 'Find tracks, artists, playlists…',
              prefixIcon: const Icon(Icons.search_rounded),
              suffixIcon: IconButton(
                tooltip: 'Search',
                icon: const Icon(Icons.arrow_forward_rounded),
                onPressed: () => _openSearch(_query.text),
              ),
              filled: true,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(18)),
            ),
          ),
          const SizedBox(height: 16),
          Text('SEARCH SOURCE', style: Theme.of(context).textTheme.labelLarge),
          const SizedBox(height: 8),
          const Chip(label: Text('Saavn')),
          const SizedBox(height: 10),
          Text('Audio streams: Saavn. Spotify library and YouTube embeds are in Settings → Jotify V8 Connect Studio.', style: Theme.of(context).textTheme.bodySmall),
          if (alternatives.length > 1) ...<Widget>[
            const SizedBox(height: 24),
            Text('TRY OTHER SPELLINGS', style: Theme.of(context).textTheme.labelLarge),
            const SizedBox(height: 8),
            Wrap(spacing: 8, runSpacing: 7, children: alternatives.skip(1).map((s) =>
              ActionChip(label: Text(s), onPressed: () => _openSearch(s))).toList()),
          ],
          const SizedBox(height: 24),
          Row(children: <Widget>[
            Expanded(child: Text('RECENT SEARCHES', style: Theme.of(context).textTheme.labelLarge)),
            if (_history.isNotEmpty) TextButton(
              onPressed: () async {
                await Hive.box('settings').put(historyKey, <String>[]);
                if (mounted) setState(() {});
              },
              child: const Text('Clear'),
            ),
          ]),
          if (_history.isEmpty)
            const Padding(padding: EdgeInsets.symmetric(vertical: 20), child: Text('Your recent searches will appear here.'))
          else
            ..._history.map((s) => ListTile(
              dense: true,
              leading: Icon(Icons.history, color: scheme.secondary),
              title: Text(s, maxLines: 1, overflow: TextOverflow.ellipsis),
              onTap: () { _query.text = s; _openSearch(s); },
            )),
        ],
      ),
    );
  }
}
