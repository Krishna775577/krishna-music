# Jotify V4 — Implementation, Lyrics Repair, and Test Plan

**Target:** Existing Jotify V3 Flutter app (`Flutter 3.19.6`, `Dart 3.3.4`, current Android Gradle toolchain).  
**Goal:** Preserve the current playback/YouTube video integration, reuse existing library and persistence, add V4 UI/tools with minimal engine changes.  
**Status:** Source code prepared; **APK compilation and phone QA have not been performed in this environment**. Do not call this a tested production build.

## What actually changed

| Requested feature | V4 implementation | Limitation / verification needed |
|---|---|---|
| Dynamic Ambient Player | Full-screen player with album-art palette gradients and the existing AudioService play/pause/seek/skip | Requires accessible artwork; no replacement of YouTube in-app video player |
| Gapless Playback + Crossfade | Reuses `just_audio` concatenated gapless queue; adds an **off-by-default manual next-song fade** (0/300/600 ms) | **True overlapping crossfade is not implemented**: requires two synchronized decoders, independent URL/preload management and extensive provider testing |
| Home Screen Widgets | Android widget now draws track title/artist, opens Jotify, forwards transport button media events to existing `MediaButtonReceiver`; Flutter-to-Android bridge updates metadata | Hardware/launcher behavior not verified; controls may not work when service is stopped; static artwork remains Jotify icon |
| Music Story Maker | Share a current-track gradient PNG via `RepaintBoundary` and `share_plus` | Text/artwork card, no licensed lyric overlays or song audio embedded |
| Offline Music Manager | Links existing local music browser | No DRM bypass or unauthorized downloading; storage permission/device QA required |
| Smart Resume | Toggles existing `loadStart` saved queue/position handling | YouTube video sessions excluded; app restart testing required |
| Private Listening Mode | Suppresses *new* recent songs, play counts, and saving last queue/position while enabled | Existing history is not deleted; search queries, downloads, notifications and external providers are unaffected |
| Playlist QR Sharing | PNG QR containing up to 650 UTF-8 bytes of readable song information, plus text share | **No cloud sharing or one-tap playlist import**; QR may truncate long lists |
| Driving Mode | Large play/pause/next/previous transport controls | Set before driving; no voice command integration |
| Bluetooth Controls | Existing `audio_service` Android media session and headset key handling retained; widget sends standard media keys | Must test device/headset-specific behavior |
| Backup & Restore | Links existing Jotify backups screen | Restore on a copy/test device first; older backup format untouched |
| Jotify Daily Mix | Generates deterministic daily shuffle of user's saved/recent tracks, plays or saves to an actual Hive playlist | On-device recommendation, **not** online AI recommendations; requires local listening history |
| Lyrics Fix | First try LRCLIB structured search (timed + text), fallback corrected Saavn API query and bounded Musixmatch; cache successes in Hive, manual retry clears cache; browser search button | Catalog coverage not guaranteed. Music licensing, provider availability, network and mismatched song metadata can still cause missing lyrics |

## Lyrics diagnosis

The original `getSaavnLyrics` passed `?__call=...` inside the path parameter of `Uri.https()`, which can encode `?` instead of treating it as a query. The player also relied on an old Spotify lyrics proxy and fragile Musixmatch/Google page scraping. The new `Lyrics.getLyrics()` requests a structured LRCLIB endpoint first with `track_name` and `artist_name`, validates the matching title/artist, and returns the provider source and type. It then makes a properly constructed JioSaavn request if the song indicates lyrics support, followed by a bounded best-effort fallback. Only non-empty responses are cached.

### Lyrics device test (essential)

1. Install the new build, start a **Saavn** song with well-known lyrics and tap the album cover to flip to lyrics. Check that a non-empty result appears and the provider name is shown.
2. Open **Settings → Jotify V2 Studio → Lyrics Studio** or **Settings → Jotify V4 Experience → Lyrics Studio**. Tap refresh to force a fresh provider request.
3. Play a second song with known **timestamped** lyrics; confirm the classic player's synchronized highlighting changes as playback moves.
4. Try one instrumental / rare Hindi or regional track. Verify a clear “not available” state instead of indefinite loading, and test **Search lyrics in browser**.
5. Disable Wi-Fi and mobile data. Verify UI stops waiting within the timeout and does not crash. Reenable network and retry.
6. Check a downloaded local file with embedded lyric tags; confirm local lyrics are shown, and online lookup only occurs when enabled.
7. Note exact song title, artist, source, and the log if a supported song still fails. Availability cannot be guaranteed for every track.

## Compilation and smoke test

Run from the **extracted full Flutter project root**, not from the ZIP itself:

```bash
flutter --version
flutter clean
flutter pub get
flutter analyze
flutter build apk --debug
```

If you use the repo's pre-existing GitHub Action, replace `krishna-music-source-ready.zip`, commit, and manually run `.github/workflows/import-and-build.yml`. That workflow imports an optional ZIP overlay and builds the debug APK; GitHub does not automatically unpack a ZIP by itself.

* Install the debug APK on a test phone. Keep a backup of current working APK and playlists.
* Launch Jotify and ensure existing branding, premium themes, V2 Studio and V3 Studio remain visible; check **Settings → Jotify V4 Experience**.
* Confirm Saavn search → Play → Pause → Seek → Next; leave playing in background, lock phone, reconnect Bluetooth headset, and open notification player.
* Confirm YouTube/YtMusic still open the app's **embedded video**, not the normal audio-only pipeline. Note that unofficial music streams may remain unavailable due to upstream restrictions.
* Enable Smart Resume, play a Saavn song, pause, close/reopen Jotify, verify queue/position restored.
* Enable Private Listening. Play another song, verify **recent songs, stats and saved last queue do not update**, then disable and verify normal history resumes.
* Play a saved Daily Mix, save a Daily Mix playlist, restart, open Library → Playlists and verify items persist.
* Open Ambient Player with artwork / without artwork, rotate phone, seek, inspect adaptive background and reduced-motion mode.
* Enable manual skip fade at 300 ms. Press Next several times while playing. Confirm normal volume is restored after each skip. Revert to **Off** for an exact V3 experience.
* Add Android home widget from launcher, play/pause/next/previous while service is active; restart launcher and compare displayed title. Test Android 11–15 if possible.
* Share Story PNG to Files or messaging app; inspect exported PNG. Generate Playlist QR, scan using a standard QR scanner, confirm readable text. It is not an import URL.
* Open Offline Music Manager, verify song permissions; test backup/restore on a duplicate set of app data, **not** your only backup.
* Test battery usage, scrolling, and playback in **release/profile APK** rather than judging performance from debug FPS alone.

## Regression / release blockers

A release is **blocked** if `flutter pub get` fails, APK cannot build, the app crashes at startup, Saavn stops playing a track that previously worked, or the new widget causes a launch crash. Do not rename the Android application ID or legacy Hive database locations during this release. Do not remove original open-source copyright/license attribution. Remove the manual skip fade by setting it to Off if a device has volume race conditions.

## Follow-up engineering milestones

1. **Crossfade Pro:** second managed `just_audio` decoder, source URL refresh, lifecycle and interruption handling, per-source opt-in, 100-track stress testing. Only then expose true 0–12 s overlap crossfade.
2. **Playlist import:** define a stable portable playlist interchange schema, add QR scan or deep link with payload validation, and make server-based shared playlists opt-in rather than inventing a public URL.
3. **Widget v2:** show actual cover art, loading status, and test Android 13+ background broadcast restrictions.
4. **Lyrics v2:** improve Hindi/regional metadata matching, expose cached lyric corrections with explicit user confirmation, and test time synchronization against real track durations.

## External technical references

- LRCLIB API docs: https://lrclib.net/docs (public, availability and terms subject to change)
- just_audio gapless playlist API: https://pub.dev/documentation/just_audio/latest/just_audio/ConcatenatingAudioSource-class.html
- qr_flutter (Dart SDK >= 2.19): https://pub.dev/packages/qr_flutter/versions
