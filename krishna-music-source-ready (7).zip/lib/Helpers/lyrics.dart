/*
 *  This file is part of BlackHole (https://github.com/Sangwan5688/BlackHole).
 * 
 * BlackHole is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * BlackHole is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with BlackHole.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * Copyright (c) 2021-2023, Ankit Sangwan
 */

import 'dart:convert';
import 'dart:async';

import 'package:audiotagger/audiotagger.dart';
import 'package:audiotagger/models/tag.dart';
import 'package:jotify/APIs/spotify_api.dart';
import 'package:jotify/Helpers/matcher.dart';
import 'package:jotify/Helpers/spotify_helper.dart';
import 'package:http/http.dart';
import 'package:logging/logging.dart';
import 'package:hive/hive.dart';

// ignore: avoid_classes_with_only_static_members
class Lyrics {
  /// LRCLIB is tried first: the historical Spotify lyrics proxy is unreliable,
  /// and the old Saavn URL constructed its query incorrectly.
  /// Only cache successful lyrics, never an unavailable/error response.
  static Future<Map<String, String>> getLyrics({
    required String id,
    required String title,
    required String artist,
    required bool saavnHas,
  }) async {
    final result = <String, String>{
      'id': id, 'lyrics': '', 'type': 'text', 'source': 'Not available',
    };
    final key = 'v4lyrics:${title.trim().toLowerCase()}:${artist.trim().toLowerCase()}';
    try {
      if (Hive.isBoxOpen('cache')) {
        final cached = Hive.box('cache').get(key);
        if (cached is Map && cached['lyrics'] is String &&
            (cached['lyrics'] as String).trim().isNotEmpty) {
          return <String, String>{
            'id': id,
            'lyrics': cached['lyrics'] as String,
            'type': (cached['type'] ?? 'text').toString(),
            'source': (cached['source'] ?? 'Cached lyrics').toString(),
          };
        }
      }
    } catch (error) {
      Logger.root.warning('Lyrics cache read failed: $error');
    }

    try {
      final lrclib = await getLRCLIBLyrics(title: title, artist: artist)
          .timeout(const Duration(seconds: 8));
      if ((lrclib['lyrics'] ?? '').trim().isNotEmpty) {
        result.addAll(lrclib);
      }
    } catch (error) {
      Logger.root.warning('LRCLIB lyrics lookup failed: $error');
    }

    if (result['lyrics']!.trim().isEmpty && saavnHas && id.isNotEmpty) {
      try {
        final text = await getSaavnLyrics(id).timeout(const Duration(seconds: 6));
        if (text.trim().isNotEmpty) {
          result.addAll({'lyrics': text, 'type': 'text', 'source': 'JioSaavn'});
        }
      } catch (error) {
        Logger.root.warning('JioSaavn lyrics lookup failed: $error');
      }
    }

    // Best-effort compatibility fallback, bounded so the UI never spins forever.
    if (result['lyrics']!.trim().isEmpty) {
      try {
        final text = await getMusixMatchLyrics(title: title, artist: artist)
            .timeout(const Duration(seconds: 5));
        if (text.trim().isNotEmpty) {
          result.addAll({'lyrics': text, 'type': 'text', 'source': 'Musixmatch'});
        }
      } catch (error) {
        Logger.root.warning('Musixmatch fallback failed: $error');
      }
    }

    if (result['lyrics']!.trim().isNotEmpty) {
      try {
        if (Hive.isBoxOpen('cache')) {
          await Hive.box('cache').put(key, <String, String>{
            'lyrics': result['lyrics']!,
            'type': result['type']!,
            'source': result['source']!,
          });
        }
      } catch (error) {
        Logger.root.warning('Lyrics cache write failed: $error');
      }
    }
    return result;
  }

  /// A manual Lyrics Studio retry must really retry, rather than returning
  /// a previously cached successful provider response.
  static Future<void> clearCache(String title, String artist) async {
    if (!Hive.isBoxOpen('cache')) return;
    final key = 'v4lyrics:${title.trim().toLowerCase()}:${artist.trim().toLowerCase()}';
    await Hive.box('cache').delete(key);
  }

  static String _normalize(String text) => text.toLowerCase()
      .replaceAll(RegExp(r'\([^)]*\)|\[[^]]*\]'), ' ')
      .replaceAll(RegExp(r'[^a-z0-9\u0900-\u097f]+'), ' ')
      .trim();

  /// LRCLIB public search returns a list containing plainLyrics / syncedLyrics.
  /// No credentials, unofficial Spotify token, or scraping is required.
  static Future<Map<String, String>> getLRCLIBLyrics({
    required String title,
    required String artist,
  }) async {
    const empty = <String, String>{'lyrics': '', 'type': 'text', 'source': 'LRCLIB'};
    if (title.trim().isEmpty) return Map<String, String>.from(empty);
    final cleanArtist = artist.trim() == 'null' ? '' : artist.trim();
    final query = <String, String>{'track_name': title.trim()};
    if (cleanArtist.isNotEmpty) query['artist_name'] = cleanArtist;
    final uri = Uri.https('lrclib.net', '/api/search', query);
    final response = await get(uri, headers: <String, String>{
      'Accept': 'application/json',
      'User-Agent': 'Jotify/4.0 (Flutter music player; lyrics lookup)',
    }).timeout(const Duration(seconds: 7));
    if (response.statusCode != 200 || response.body.length > 250000) {
      return Map<String, String>.from(empty);
    }
    final decoded = jsonDecode(response.body);
    if (decoded is! List) return Map<String, String>.from(empty);
    final name = _normalize(title);
    final artistName = _normalize(cleanArtist);
    for (final entry in decoded.take(12)) {
      if (entry is! Map) continue;
      if (entry['instrumental'] == true) continue;
      final foundTitle = _normalize((entry['trackName'] ?? '').toString());
      final foundArtist = _normalize((entry['artistName'] ?? '').toString());
      if (foundTitle.isEmpty || !(foundTitle == name ||
          foundTitle.contains(name) || name.contains(foundTitle))) continue;
      if (artistName.isNotEmpty && foundArtist.isNotEmpty &&
          !(foundArtist.contains(artistName) || artistName.contains(foundArtist) ||
            foundArtist.split(' ').any((part) => part.length > 3 && artistName.contains(part)))) {
        continue;
      }
      final synced = (entry['syncedLyrics'] ?? '').toString().trim();
      final plain = (entry['plainLyrics'] ?? '').toString().trim();
      if (synced.isNotEmpty && synced.toLowerCase() != 'null') {
        return {'lyrics': synced, 'type': 'lrc', 'source': 'LRCLIB (synced)'};
      }
      if (plain.isNotEmpty && plain.toLowerCase() != 'null') {
        return {'lyrics': plain, 'type': 'text', 'source': 'LRCLIB'};
      }
    }
    return Map<String, String>.from(empty);
  }

  static Future<String> getSaavnLyrics(String id) async {
    try {
      final Uri lyricsUrl = Uri.https('www.jiosaavn.com', '/api.php', {
        '__call': 'lyrics.getLyrics',
        'lyrics_id': id,
        'ctx': 'web6dot0',
        'api_version': '4',
        '_format': 'json',
      });
      final Response res =
          await get(lyricsUrl, headers: {'Accept': 'application/json'})
              .timeout(const Duration(seconds: 5));

      final List<String> rawLyrics = res.body.split('-->');
      Map fetchedLyrics = {};
      if (rawLyrics.length > 1) {
        fetchedLyrics = json.decode(rawLyrics[1]) as Map;
      } else {
        fetchedLyrics = json.decode(rawLyrics[0]) as Map;
      }
      final String lyrics =
          (fetchedLyrics['lyrics'] ?? '').toString()
              .replaceAll(RegExp(r'<br\s*/?>', caseSensitive: false), '\n');
      return lyrics;
    } catch (e) {
      Logger.root.severe('Error in getSaavnLyrics', e);
      return '';
    }
  }

  static Future<Map<String, String>> getSpotifyLyrics(
    String title,
    String artist,
  ) async {
    final Map<String, String> result = {
      'lyrics': '',
      'type': 'text',
      'source': 'Spotify',
    };
    await callSpotifyFunction(
      function: (String accessToken) async {
        final value = await SpotifyApi().searchTrack(
          accessToken: accessToken,
          query: '$title - $artist',
          limit: 1,
        );
        try {
          // Logger.root.info(jsonEncode(value['tracks']['items'][0]));
          if (value['tracks']['items'].length == 0) {
            Logger.root.info('No song found');
            return result;
          }
          String title2 = '';
          String artist2 = '';
          try {
            title2 = value['tracks']['items'][0]['name'].toString();
            artist2 =
                value['tracks']['items'][0]['artists'][0]['name'].toString();
          } catch (e) {
            Logger.root.severe(
              'Error in extracting artist/title in getSpotifyLyrics for $title - $artist',
              e,
            );
          }
          final trackId = value['tracks']['items'][0]['id'].toString();
          if (matchSongs(
            title: title,
            artist: artist,
            title2: title2,
            artist2: artist2,
          ).matched) {
            final Map<String, String> res =
                await getSpotifyLyricsFromId(trackId);
            result['lyrics'] = res['lyrics']!;
            result['type'] = res['type']!;
            result['source'] = res['source']!;
          } else {
            Logger.root.info('Song not matched');
          }
        } catch (e) {
          Logger.root.severe('Error in getSpotifyLyrics', e);
        }
      },
      forceSign: false,
    );
    return result;
  }

  static Future<Map<String, String>> getSpotifyLyricsFromId(
    String trackId,
  ) async {
    final Map<String, String> result = {
      'lyrics': '',
      'type': 'text',
      'source': 'Spotify',
    };
    try {
      final Uri lyricsUrl =
          Uri.https('spotify-lyric-api-984e7b4face0.herokuapp.com', '/', {
        'trackid': trackId,
        'format': 'lrc',
      });
      final Response res =
          await get(lyricsUrl, headers: {'Accept': 'application/json'});

      if (res.statusCode == 200) {
        final Map lyricsData = await json.decode(res.body) as Map;
        if (lyricsData['error'] == false) {
          final List lines = await lyricsData['lines'] as List;
          if (lyricsData['syncType'] == 'LINE_SYNCED') {
            result['lyrics'] = lines
                .map((e) => '[${e["timeTag"]}]${e["words"]}')
                .toList()
                .join('\n');
            result['type'] = 'lrc';
          } else {
            result['lyrics'] = lines.map((e) => e['words']).toList().join('\n');
            result['type'] = 'text';
          }
        }
      } else {
        Logger.root.severe(
          'getSpotifyLyricsFromId returned ${res.statusCode}',
          res.body,
        );
      }
      return result;
    } catch (e) {
      Logger.root.severe('Error in getSpotifyLyrics', e);
      return result;
    }
  }

  static Future<String> getGoogleLyrics({
    required String title,
    required String artist,
  }) async {
    const String url =
        'https://www.google.com/search?client=safari&rls=en&ie=UTF-8&oe=UTF-8&q=';
    const String delimiter1 =
        '</div></div></div></div><div class="hwc"><div class="BNeawe tAd8D AP7Wnd"><div><div class="BNeawe tAd8D AP7Wnd">';
    const String delimiter2 =
        '</div></div></div></div></div><div><span class="hwc"><div class="BNeawe uEec3 AP7Wnd">';
    String lyrics = '';
    try {
      lyrics = (await get(
        Uri.parse(Uri.encodeFull('$url$title by $artist lyrics')),
      ))
          .body;
      lyrics = lyrics.split(delimiter1).last;
      lyrics = lyrics.split(delimiter2).first;
      if (lyrics.contains('<meta charset="UTF-8">')) throw Error();
    } catch (_) {
      try {
        lyrics = (await get(
          Uri.parse(
            Uri.encodeFull('$url$title by $artist song lyrics'),
          ),
        ))
            .body;
        lyrics = lyrics.split(delimiter1).last;
        lyrics = lyrics.split(delimiter2).first;
        if (lyrics.contains('<meta charset="UTF-8">')) throw Error();
      } catch (_) {
        try {
          lyrics = (await get(
            Uri.parse(
              Uri.encodeFull(
                '$url${title.split("-").first} by $artist lyrics',
              ),
            ),
          ))
              .body;
          lyrics = lyrics.split(delimiter1).last;
          lyrics = lyrics.split(delimiter2).first;
          if (lyrics.contains('<meta charset="UTF-8">')) throw Error();
        } catch (_) {
          lyrics = '';
        }
      }
    }
    return lyrics.trim();
  }

  static Future<String> getOffLyrics(String path) async {
    try {
      final Audiotagger tagger = Audiotagger();
      final Tag? tags = await tagger.readTags(path: path);
      return tags?.lyrics ?? '';
    } catch (e) {
      return '';
    }
  }

  static Future<String> getLyricsLink(String song, String artist) async {
    const String authority = 'www.musixmatch.com';
    final String unencodedPath = '/search/$song $artist';
    final Response res = await get(Uri.https(authority, unencodedPath));
    if (res.statusCode != 200) return '';
    final RegExpMatch? result =
        RegExp(r'href=\"(\/lyrics\/.*?)\"').firstMatch(res.body);
    return result == null ? '' : result[1]!;
  }

  static Future<String> scrapLink(String unencodedPath) async {
    Logger.root.info('Trying to scrap lyrics from $unencodedPath');
    const String authority = 'www.musixmatch.com';
    final Response res = await get(Uri.https(authority, unencodedPath));
    if (res.statusCode != 200) return '';
    final List<String?> lyrics = RegExp(
      r'<span class=\"lyrics__content__ok\">(.*?)<\/span>',
      dotAll: true,
    ).allMatches(res.body).map((m) => m[1]).toList();

    return lyrics.isEmpty ? '' : lyrics.join('\n');
  }

  static Future<String> getMusixMatchLyrics({
    required String title,
    required String artist,
  }) async {
    try {
      final String link = await getLyricsLink(title, artist);
      Logger.root.info('Found Musixmatch Lyrics Link: $link');
      final String lyrics = await scrapLink(link);
      return lyrics;
    } catch (e) {
      Logger.root.severe('Error in getMusixMatchLyrics', e);
      return '';
    }
  }
}
