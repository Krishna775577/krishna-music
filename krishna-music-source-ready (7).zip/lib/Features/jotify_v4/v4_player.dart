import 'package:audio_service/audio_service.dart';
import 'package:flutter/material.dart';
import 'package:get_it/get_it.dart';
import 'package:hive/hive.dart';
import 'package:jotify/Features/jotify_v3/v3_performance.dart';
import 'package:jotify/Screens/Player/audioplayer.dart';
import 'package:palette_generator/palette_generator.dart';

/// Album-art-based ambience for the existing AudioService player.
/// Does NOT replace the underlying audio source or in-app YouTube video player.
class JotifyAmbientPlayer extends StatefulWidget {
  const JotifyAmbientPlayer({super.key});
  @override
  State<JotifyAmbientPlayer> createState() => _JotifyAmbientPlayerState();
}

class _JotifyAmbientPlayerState extends State<JotifyAmbientPlayer> {
  final AudioPlayerHandler _audio = GetIt.I<AudioPlayerHandler>();
  String? _lastArt;
  Future<PaletteGenerator?>? _palette;

  Future<PaletteGenerator?> _loadPalette(String? url) async {
    if (url == null || !url.startsWith('https://')) return null;
    try {
      return await PaletteGenerator.fromImageProvider(
        NetworkImage(url),
        size: const Size(96, 96),
        maximumColorCount: 8,
      ).timeout(const Duration(seconds: 6));
    } catch (_) {
      return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<MediaItem?>(
      stream: _audio.mediaItem,
      builder: (context, snap) {
        final item = snap.data;
        if (item == null) {
          return Scaffold(appBar: AppBar(title: const Text('Ambient Player')),
            body: const Center(child: Text('Start an audio track to see its ambience.')));
        }
        final url = item.artUri?.toString();
        if (url != _lastArt) {
          _lastArt = url;
          _palette = _loadPalette(url);
        }
        return FutureBuilder<PaletteGenerator?>(
          future: _palette,
          builder: (context, colors) {
            final base = colors.data?.dominantColor?.color ??
                Theme.of(context).colorScheme.primary;
            final motion = V3Performance.animation(const Duration(milliseconds: 650));
            return Scaffold(
              appBar: AppBar(title: const Text('Jotify Ambient Player'),
                  backgroundColor: Colors.transparent),
              extendBodyBehindAppBar: true,
              body: AnimatedContainer(
                duration: motion,
                decoration: BoxDecoration(gradient: LinearGradient(
                  begin: Alignment.topLeft, end: Alignment.bottomRight,
                  colors: [base.withOpacity(.96), Color.lerp(base, Colors.black, .8)!, Colors.black],
                )),
                child: SafeArea(child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 25, vertical: 22),
                  child: Column(children: <Widget>[
                    const Spacer(),
                    Hero(tag: 'v4-ambient-art', child: ClipRRect(
                      borderRadius: BorderRadius.circular(26),
                      child: AspectRatio(aspectRatio: 1,
                        child: url != null && url.startsWith('http')
                            ? Image.network(url, fit: BoxFit.cover,
                                errorBuilder: (_, __, ___) => const Icon(Icons.album, size: 120, color: Colors.white))
                            : const Icon(Icons.album, size: 120, color: Colors.white),
                      ),
                    )),
                    const SizedBox(height: 26),
                    Text(item.title, maxLines: 2, overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: Colors.white, fontSize: 25, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 6),
                    Text(item.artist ?? '', maxLines: 1,
                      style: const TextStyle(color: Colors.white70, fontSize: 15)),
                    const SizedBox(height: 18),
                    StreamBuilder<Duration>(stream: AudioService.position, builder: (context, progress) {
                      final position = progress.data ?? Duration.zero;
                      final duration = item.duration ?? Duration.zero;
                      final total = duration.inMilliseconds > 0 ? duration.inMilliseconds.toDouble() : 1.0;
                      final current = position.inMilliseconds.toDouble().clamp(0.0, total);
                      return Column(children: <Widget>[
                        Slider(value: current, max: total, activeColor: Colors.white,
                          inactiveColor: Colors.white30,
                          onChanged: duration > Duration.zero
                              ? (value) => _audio.seek(Duration(milliseconds: value.toInt()))
                              : null),
                        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: <Widget>[
                          Text(_time(position), style: const TextStyle(color: Colors.white70)),
                          Text(_time(duration), style: const TextStyle(color: Colors.white70)),
                        ]),
                      ]);
                    }),
                    StreamBuilder<PlaybackState>(stream: _audio.playbackState, builder: (context, state) {
                      final playing = state.data?.playing ?? false;
                      return Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: <Widget>[
                        IconButton(onPressed: _audio.skipToPrevious,
                          icon: const Icon(Icons.skip_previous_rounded, size: 38, color: Colors.white)),
                        IconButton(onPressed: playing ? _audio.pause : _audio.play,
                          icon: Icon(playing ? Icons.pause_circle_filled : Icons.play_circle_fill,
                            size: 70, color: Colors.white)),
                        IconButton(onPressed: _audio.skipToNext,
                          icon: const Icon(Icons.skip_next_rounded, size: 38, color: Colors.white)),
                      ]);
                    }),
                    const Spacer(),
                    if (Hive.box('settings').get('v4PrivateListening', defaultValue: false) == true)
                      const Text('Private listening enabled',
                        style: TextStyle(color: Colors.white70)),
                  ]),
                )),
              ),
            );
          },
        );
      },
    );
  }

  String _time(Duration d) => '${d.inMinutes.remainder(60).toString().padLeft(2, '0')}:${d.inSeconds.remainder(60).toString().padLeft(2, '0')}';
}
