# Jotify V4 — Source Release Notes

Version: **V4 source preview**, not a verified stable APK.

**Existing V3 preserved:** Same app ID, legacy DB paths, Saavn/YouTube music integrations, V2/V3 menus, original legal attribution and custom branding. Only targeted user-requested integrations were changed.

**Navigation:** `Settings → Jotify V4 Experience` provides all new controls. The existing lyrics player also uses the repaired lyrics helper; V2 Lyrics Studio gains explicit retry and browser search.

**New external dependency:** `qr_flutter: ^4.1.0` for QR rendering; run `flutter pub get` before build.

**Safety defaults:** private mode Off, manual next-track fade Off, Smart Resume preserves the previous app's default, no automatic data migrations, no paid API keys. The code does **not** implement true overlapping crossfade, cloud playlist imports, synced lyrics for every track, or universal widget reliability.

See `JOTIFY_V4_DEVELOPMENT_TESTING_PLAN.md` for exact coverage, test matrix, limitations, and rollback instructions.
