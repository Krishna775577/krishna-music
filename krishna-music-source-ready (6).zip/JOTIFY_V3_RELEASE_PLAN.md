# Jotify V3 — Focused update and verification

Base: Jotify V2 local full-source snapshot. This is a **source package**, not a compiled APK.

## What changed

- **Ultra Smooth Motion Player:** reuses V2 motion player and currently registered AudioPlayerHandler; obeys new reduce-motion and performance preferences. Image decode width constrained in this view.
- **Smart Search 2.0:** simple history (last 12 searches), spelling variants, Saavn / YouTube Music / YouTube source selector, powered by existing search screen. This does not combine provider catalogues or create unavailable results.
- **Smart Queue:** shows audio queue, manual retry, skip to next distinct song and jump-to-index. Does not rewrite or delete queue entries automatically (safer for current playback). YouTube video queue is handled by its in-app video player.
- **Performance Mode:** shorter bottom-navigation transitions, reduce-motion option, lower-data artwork preference and compact mini-player. Settings persist in existing Hive settings box.
- V2 Studio, customized branding, themes, Saavn playback and YouTube embedded player preserved. No additional Flutter dependencies.

## Compatibility and migration

- Flutter 3.19.6 / Dart 3.3.4, existing dependency versions preserved.
- Android package/application ID and legacy Hive boxes unchanged; saved user data should remain addressable.
- Retain original license/attribution notices. No external APK needed for this patch.

## Practical QA checklist

1. Make a new backup branch or tag in GitHub.
2. Upload `krishna-music-source-ready.zip` at repository root and commit (replace old ZIP).
3. Start a **new** GitHub Actions run (`Import ZIP and Build Android APK`); don't rerun old failed logs.
4. Check `Get Dart packages`, `flutter test test/v3_query_tools_test.dart`, and `Build debug APK`. The existing workflow currently runs dependency fetch and build only: run the test manually or in a local Flutter shell, since workflow file imports are blocked.
5. Install over the existing app with the same signing key where possible; back up settings first.
6. In Settings > Jotify V3 Studio, open all four screens. Confirm exit/back and no render overflow.
7. Saavn: play, pause, seek, next, skip to queue item; confirm current audio keeps playing while changing performance preferences.
8. Search: `Khama Ray Khama`, try alternate spellings and providers; verify results come from their real source.
9. Performance: toggle each preference, open motion player, inspect lower animation cost. Run profile APK FPS tests on physical hardware.
10. YouTube/YtMusic: check in-app player/video controls remain functional (source-specific embedding restrictions may apply).

## Limitations

No Flutter SDK or Android runtime was available during this source packaging. Build success, FPS and playback have **not** been verified. Suggestions only broaden queries; they cannot guarantee all Saavn songs. Motion animation is decorative (not FFT). A hot reload/reopen may be needed for some persisted animation preferences to fully apply.
