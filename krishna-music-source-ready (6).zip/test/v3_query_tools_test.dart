import 'package:flutter_test/flutter_test.dart';
import 'package:jotify/Features/jotify_v3/query_tools.dart';

void main() {
  test('normalizes whitespace', () {
    expect(V3QueryTools.normalize('  Khama   Ray  Khama '), 'Khama Ray Khama');
  });

  test('suggestions are unique and include Rajasthani spellings', () {
    final result = V3QueryTools.suggestions('Khama Ray Khama');
    expect(result.first, 'Khama Ray Khama');
    expect(result.any((term) => term.toLowerCase().contains('khamma')), isTrue);
    expect(result.any((term) => term.toLowerCase().contains(' re ')), isTrue);
    expect(result.toSet().length, result.length);
  });

  test('blank search does not start', () {
    expect(V3QueryTools.suggestions('   '), isEmpty);
  });
}
