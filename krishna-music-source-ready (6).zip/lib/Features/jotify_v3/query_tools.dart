/// Offline-only query preparation. Actual result availability is determined
/// by the selected provider (Saavn, YouTube Music or YouTube).
class V3QueryTools {
  const V3QueryTools._();

  static String normalize(String input) =>
      input.trim().replaceAll(RegExp(r'\s+'), ' ');

  static List<String> suggestions(String input) {
    final query = normalize(input);
    if (query.isEmpty) return <String>[];
    final unique = <String>{};
    void add(String q) {
      final value = normalize(q);
      if (value.isNotEmpty) unique.add(value);
    }

    add(query);
    final low = query.toLowerCase();
    if (low.contains('khama')) {
      add(query.replaceAll(RegExp('khama', caseSensitive: false), 'khamma'));
    }
    if (low.contains('khamma')) {
      add(query.replaceAll(RegExp('khamma', caseSensitive: false), 'khama'));
    }
    if (RegExp(r'\bray\b', caseSensitive: false).hasMatch(query)) {
      add(query.replaceAll(RegExp(r'\bray\b', caseSensitive: false), 're'));
    }
    if (RegExp(r'\bre\b', caseSensitive: false).hasMatch(query)) {
      add(query.replaceAll(RegExp(r'\bre\b', caseSensitive: false), 'ray'));
    }
    if (low.contains('lofi')) {
      add(query.replaceAll(RegExp('lofi', caseSensitive: false), 'lo-fi'));
    }
    if (low.contains('lo-fi')) {
      add(query.replaceAll(RegExp('lo-fi', caseSensitive: false), 'lofi'));
    }
    final parts = query.split(' ');
    if (parts.length > 2) {
      add(parts.take(parts.length - 1).join(' '));
    }
    // Suggestions are alternative searches, never fabricated result entries.
    return unique.take(7).toList(growable: false);
  }
}
