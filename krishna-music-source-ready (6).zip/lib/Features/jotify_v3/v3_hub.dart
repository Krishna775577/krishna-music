import 'package:flutter/material.dart';
import 'package:jotify/Features/jotify_v2/v2_hub.dart';
import 'package:jotify/Features/jotify_v3/v3_performance.dart';
import 'package:jotify/Features/jotify_v3/v3_queue.dart';
import 'package:jotify/Features/jotify_v3/v3_search.dart';

/// V3 features reuse V2's established UI and the existing playback handler.
class JotifyV3Hub extends StatelessWidget {
  const JotifyV3Hub({super.key});

  @override
  Widget build(BuildContext context) {
    final accent = Theme.of(context).colorScheme.secondary;
    void open(Widget screen) => Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => screen),
    );

    Widget tile(String title, String subtitle, IconData icon, Widget screen) {
      return Card(
        margin: const EdgeInsets.symmetric(vertical: 7),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        child: ListTile(
          contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 9),
          leading: Icon(icon, color: accent, size: 29),
          title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
          subtitle: Text(subtitle),
          trailing: const Icon(Icons.chevron_right_rounded),
          onTap: () => open(screen),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Jotify V3 Studio')),
      body: ListView(padding: const EdgeInsets.fromLTRB(14, 14, 14, 32), children: <Widget>[
        Container(
          padding: const EdgeInsets.all(23),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            gradient: LinearGradient(colors: <Color>[accent.withOpacity(.35), Theme.of(context).cardColor]),
          ),
          child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
            Text('Play smarter. Move smoother.', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
            SizedBox(height: 9),
            Text('Four focused upgrades built around your existing Jotify music library.'),
          ]),
        ),
        const SizedBox(height: 12),
        tile('Ultra Smooth Motion Player',
            'Reduced-motion-aware visualizer and existing controls',
            Icons.graphic_eq_rounded, const JotifyMotionPlayer()),
        tile('Smart Search 2.0',
            'Spelling variations, search history, provider switch',
            Icons.manage_search_rounded, const JotifyV3Search()),
        tile('Smart Queue',
            'See duplicates, retry playback, jump to next different song',
            Icons.queue_music_rounded, const JotifyV3Queue()),
        tile('Performance Mode',
            'Battery-friendly transitions and artwork options',
            Icons.speed_rounded, const JotifyV3Performance()),
        const SizedBox(height: 18),
        Text('Your original Saavn audio and YouTube in-app video players are unchanged. For YouTube playlists, use the Up Next controls in the video player.',
          style: Theme.of(context).textTheme.bodySmall),
      ]),
    );
  }
}
