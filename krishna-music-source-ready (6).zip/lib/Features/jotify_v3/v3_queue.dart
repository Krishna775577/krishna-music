import 'package:audio_service/audio_service.dart';
import 'package:flutter/material.dart';
import 'package:get_it/get_it.dart';
import 'package:jotify/Screens/Player/audioplayer.dart';

/// Queue operations use the already registered AudioHandler.
/// No audio sources are rebuilt, so playback URLs and Saavn remain unchanged.
class JotifyV3Queue extends StatefulWidget {
  const JotifyV3Queue({super.key});

  @override
  State<JotifyV3Queue> createState() => _JotifyV3QueueState();
}

class _JotifyV3QueueState extends State<JotifyV3Queue> {
  final AudioPlayerHandler _audio = GetIt.I<AudioPlayerHandler>();
  bool _busy = false;

  Future<void> _perform(Future<void> Function() operation) async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      await operation();
    } catch (error) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Queue action failed: $error')),
        );
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Jotify Smart Queue')),
      body: StreamBuilder<QueueState>(
        stream: _audio.queueState,
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return const Center(child: Text('Queue unavailable. Try opening the main player.'));
          }
          final state = snapshot.data ?? QueueState.empty;
          final tracks = state.queue;
          final selected = state.queueIndex ?? 0;
          if (tracks.isEmpty) {
            return const Center(child: Padding(
              padding: EdgeInsets.all(25),
              child: Text('Play a Saavn or local track to create a queue. YouTube video queues remain in their own in-app player.',
                  textAlign: TextAlign.center),
            ));
          }
          final currentIndex = selected >= 0 && selected < tracks.length ? selected : 0;
          final played = <String>{};
          for (var i = 0; i <= currentIndex; i++) {
            played.add(tracks[i].id);
          }
          int? nextUnique;
          for (var i = currentIndex + 1; i < tracks.length; i++) {
            if (played.add(tracks[i].id)) {
              nextUnique = i;
              break;
            }
          }
          final upcoming = tracks.skip(currentIndex + 1).toList();
          final duplicates = upcoming.length - upcoming.map((item) => item.id).toSet().length;
          return Column(children: <Widget>[
            Card(
              margin: const EdgeInsets.fromLTRB(12, 8, 12, 8),
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
                  Text('Now playing: ${tracks[currentIndex].title}', maxLines: 1,
                      overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)),
                  const SizedBox(height: 8),
                  Text('$duplicates duplicate upcoming entries detected. Queue stays intact until you change it.',
                      style: Theme.of(context).textTheme.bodySmall),
                  const SizedBox(height: 8),
                  Wrap(spacing: 8, runSpacing: 5, children: <Widget>[
                    OutlinedButton.icon(
                      onPressed: _busy || nextUnique == null ? null
                          : () => _perform(() => _audio.skipToQueueItem(nextUnique!)),
                      icon: const Icon(Icons.skip_next_rounded),
                      label: const Text('Next different song'),
                    ),
                    OutlinedButton.icon(
                      onPressed: _busy ? null : () => _perform(_audio.play),
                      icon: const Icon(Icons.replay_rounded),
                      label: const Text('Retry play'),
                    ),
                  ]),
                ]),
              ),
            ),
            Expanded(child: ListView.builder(
              itemCount: tracks.length,
              itemBuilder: (context, index) {
                final track = tracks[index];
                final isCurrent = index == currentIndex;
                final duplicateEarlier = tracks.take(index).any((entry) => entry.id == track.id);
                return ListTile(
                  selected: isCurrent,
                  leading: CircleAvatar(child: Text('${index + 1}')),
                  title: Text(track.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                  subtitle: Text(duplicateEarlier ? '${track.artist ?? 'Unknown'} · Duplicate' : (track.artist ?? 'Unknown'),
                    maxLines: 1, overflow: TextOverflow.ellipsis),
                  trailing: isCurrent ? const Icon(Icons.equalizer_rounded)
                      : Row(mainAxisSize: MainAxisSize.min, children: <Widget>[
                          IconButton(
                            tooltip: 'Play this track',
                            icon: const Icon(Icons.play_arrow_rounded),
                            onPressed: _busy ? null
                                : () => _perform(() => _audio.skipToQueueItem(index)),
                          ),
                          if (index > currentIndex + 1)
                            IconButton(
                              tooltip: 'Move next in queue',
                              icon: const Icon(Icons.vertical_align_top_rounded),
                              onPressed: _busy ? null
                                  : () => _perform(() => _audio.moveQueueItem(index, currentIndex + 1)),
                            ),
                        ]),
                  onTap: isCurrent || _busy ? null : () => _perform(() => _audio.skipToQueueItem(index)),
                );
              },
            )),
          ]);
        },
      ),
    );
  }
}
