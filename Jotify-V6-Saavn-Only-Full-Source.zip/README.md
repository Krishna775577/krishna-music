# Jotify V6 — Saavn Only 🎵

Jotify is a Flutter music app customized by Krishna Bajaj, based on the open-source BlackHole project. The **online music catalogue, search, stream and recommendations are Saavn only**. Local music, downloaded files and playlists are retained. No YouTube, YouTube Music, video or Spotify charts integration is included.

## What changed in V6
- Removed YouTube and YouTube Music user interface, navigation, player, downloader, providers and Flutter dependencies.
- Saavn-only Search with song, album, artist and playlist results, retry states and direct **View all** search.
- New Saavn Discover replaces Spotify charts. Discover displays searches, not fabricated chart ranks.
- Old settings automatically migrate to Saavn-only; saves playlists, downloads and user settings. Old video queues are filtered so stale links are not played.
- Jotify branding (app label, launcher icon, home badge, player widget and About), with visible `V6 · Saavn Only` marker.
- Retains previous V2/V3/V4/V5 hubs: player improvements, queue, lyrics import, voice search, downloads, liked songs, playlists, and personalization. Feature availability depends on device and service.

## Install/upgrade using GitHub Actions
1. Put `krishna-music-source-ready.zip` in the **repository root**, replacing the old ZIP.
2. Replace `.github/workflows/import-and-build.yml` with the supplied V6 YAML (the original ZIP importer deliberately skipped workflow files).
3. In GitHub Actions, run **Import ZIP and Build Jotify V6 Saavn Only**.
4. Confirm logs show `version: 6.0.0+46` and `Jotify V6 verified`. Download artifact `jotify-v6-saavn-only-debug-apk`. Install its APK and check the `V6 · Saavn Only` label on home.

If this app was previously signed using a different signing key, Android will reject an in-place APK update. **Backup your data** before uninstalling anything. Replacing ZIP on GitHub does not update the APK on the phone.

## Build without ZIP importer
Extract all files into a full Flutter repository and use Flutter 3.19.6 / Dart 3.3, JDK 11, then run `flutter pub get` and `flutter build apk --debug`.

## Technical notes
- Android application ID stays `com.shadow.blackhole` solely for app-upgrade compatibility; changing it would create a different installed app. Some internal Hive filesystem paths and original copyright/license attribution retain historic strings. Those do not show as video services.
- The LGPL-3.0 license and author attribution for BlackHole are retained. Jotify branding does not remove original authors' rights.
- Saavn uses unofficial public endpoints whose availability can change; this release does not claim guaranteed streaming.
- This workspace supports source inspection and static checks only. Full Flutter compile and physical Android tests are still required before saying the APK is working.
