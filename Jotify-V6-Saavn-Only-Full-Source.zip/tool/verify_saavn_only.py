#!/usr/bin/env python3
"""Jotify V6 source assertions for GitHub Actions; no Flutter SDK needed."""
from pathlib import Path
import re, sys
from xml.etree import ElementTree
ROOT=Path(__file__).resolve().parents[1]
errors=[]
def assert_true(check, message):
    if not check: errors.append(message)
ps=(ROOT/'pubspec.yaml').read_text(encoding='utf8')
assert_true(bool(re.search(r'(?m)^name:\s+jotify\s*$',ps)), 'Expected Flutter package jotify')
assert_true(bool(re.search(r'(?m)^version:\s+6\.0\.0\+46\s*$',ps)), 'Expected version 6.0.0+46')
for dep in ['youtube_explode_dart','youtube_player_iframe','webview_flutter','webview_flutter_android']:
    assert_true(not re.search(r'(?m)^\s*'+re.escape(dep)+r':',ps), f'Obsolete pubspec dependency: {dep}')
for rel in ['lib/Screens/YouTube/youtube.dart', 'lib/Services/youtube_services.dart', 'lib/Services/youtube_embed_navigation.dart', 'lib/Services/yt_music.dart', 'lib/Services/ytmusic', 'lib/Screens/YouTube', 'lib/APIs/spotify_api.dart', 'lib/Helpers/spotify_helper.dart', 'test/youtube_embed_navigation_test.dart']:
    path=ROOT/rel
    assert_true(not path.exists() or (path.is_dir() and not any(path.iterdir())), f'Obsolete provider file/dir still present: {rel}')
for rel in ['lib/Screens/Search/search.dart','lib/Screens/Top Charts/top.dart','lib/main.dart','android/app/src/main/kotlin/com/shadow/blackhole/JotifyMusicWidget.kt']:
    assert_true((ROOT/rel).is_file(),f'Missing V6 file {rel}')
for rel in ['lib/Screens/Search/search.dart','lib/Screens/Top Charts/top.dart']:
    assert_true('SaavnAPI()' in (ROOT/rel).read_text(encoding='utf8'),f'Non-Saavn search page: {rel}')
for p in (ROOT/'lib').rglob('*.dart'):
    t=p.read_text(encoding='utf8')
    for imp in re.findall(r"(?m)^\s*import\s+['\"]package:jotify/([^'\"]+)['\"]", t):
        assert_true((ROOT/'lib'/imp).is_file(),f'Missing Dart import {imp} in {p.relative_to(ROOT)}')
    for forbidden in ['package:youtube_explode_dart','package:youtube_player_iframe','package:webview_flutter','package:jotify/Screens/YouTube/','package:jotify/Services/ytmusic/','package:jotify/APIs/spotify_api.dart']:
        assert_true(forbidden not in t,f'Forbidden active dependency {forbidden} in {p.relative_to(ROOT)}')
manifest=ROOT/'android/app/src/main/AndroidManifest.xml'
try:
    root=ElementTree.parse(manifest).getroot()
    label=root.find('application').attrib.get('{http://schemas.android.com/apk/res/android}label')
    assert_true(label=='Jotify',f'Android label should be Jotify, got {label}')
except Exception as exc:errors.append(f'Bad Android manifest: {exc}')
assert_true('V6 · Saavn Only' in (ROOT/'lib/Screens/Home/home_screen.dart').read_text(), 'Home does not show V6 marker')
if errors:
    for e in errors: print('FAILED:',e)
    sys.exit(1)
print('Jotify V6 verified: 6.0.0+46, Saavn only, no legacy provider imports or dependencies, branding present.')
