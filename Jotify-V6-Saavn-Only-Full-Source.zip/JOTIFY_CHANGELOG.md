# Jotify Changelog

## V6.0.0+46 — Saavn Only
- YouTube, YouTube Music, video player and downloader removed.
- Saavn is the only online music catalogue; playback and search flows now route through Saavn.
- Spotify Charts replaced by Saavn Discover.
- Old YouTube settings and queues sanitized without deleting playlists or local files.
- Jotify branding and V6 version marker shown in app.
- Earlier V2 through V5 feature hubs and lyrics/playlists retained.
- Saavn-only importer workflow with stale-file cleanup and version assertions.
- Offline Flutter compile unavailable: static validation only.
