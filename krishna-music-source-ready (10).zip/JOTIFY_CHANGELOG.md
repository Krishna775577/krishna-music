## Jotify V9 · Spotube Parity Integration

- Added nearby LAN Jam auto-discovery (UDP, private IPv4 only, room code remains private).
- Added Spotify metadata to reviewable Saavn track matching and local playlist import.
- Added typed provider capability contracts, MusicBrainz recording discovery, and explicit permissions for external discovery-link plugins.
- Added 3 new Flutter regression test files, V9 source verifier and clean ZIP import workflow.
- Retained Saavn music playback and prior V2–V8 features.
- See JOTIFY_V9_RELEASE_NOTES.md for unimplemented Spotube parity features and test limitations.

# Jotify Changelog

## 8.0.0+50 — Connect Studio source integration
- Spotify OAuth PKCE and read-only liked tracks/playlist metadata sync.
- Official YouTube WebView embedded video player and optional Data API v3 search.
- Safe HTTPS discovery plugin manifests (no executable JS plugins).
- Same-Wi-Fi Jam sync, paired device controls, opt-in local audio HTTP Range transfer.
- Last.fm authorization, scrobbling and offline retry; private mode respected.
- Jotify V8 visible Home, Login, Settings and About markers.
- All V7/V6.1 Saavn audio playback and libraries preserved.
- Source-only verification in this environment; APK and external integrations need tests.


## 7.0.0+48 — Spotube-inspired improvements
- Source compared with user-provided Spotube Kotlin Multiplatform project.
- Persistent hidden songs/artists; filtering at search/player/queue boundaries.
- Alternative track version Saavn lookup from song menu.
- Optional Spotify and YouTube **external search** links, no in-app playback claim.
- Kept pre-existing Saavn/local playback and data compatible.
- Added integration test and feature gap audit.
- Full Flutter build and device tests remain pending.

## 6.1.0+47
- Saavn only streaming, removed YouTube/YouTube Music source and quality menus.
