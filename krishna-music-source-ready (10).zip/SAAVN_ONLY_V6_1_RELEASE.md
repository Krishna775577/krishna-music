# Jotify V6.1 — strictly Saavn-only online audio

## Actual source changes
- Removed obsolete download and playback quality controls from Download and Music Playback settings.
- Removed chart-country selection from the first-run onboarding form and its settings search entries.
- Removed unused translated provider labels from all ARB localizations.
- JioSaavn is the only online audio catalogue/search provider; its playback URLs are validated before queueing and playback.
- Archived items from old providers are not played. Stored playlists and offline downloads are preserved to avoid destructive upgrades.
- Removed obsolete player code and packages in V6, and kept those deletions in V6.1.
- Added `test/saavn_source_guard_test.dart` and included it in the GitHub Actions test step.
- Updated in-app marker to `V6.1 · Saavn Only`, package version `6.1.0+47`.

## Building

1. Place the complete ZIP into the GitHub repository as `krishna-music-source-ready.zip`.
2. Replace `.github/workflows/import-and-build.yml` with the workflow supplied separately.
3. Run the workflow in GitHub Actions; download the `jotify-v6.1-saavn-only-debug-apk` artifact.
4. Check the `V6.1 · Saavn Only` marker inside the installed app.

**Verification note:** Source-level checks can pass without confirming Android compilation or physical-device audio behavior. The APK is not supplied until a real Flutter/Android build succeeds.

**Compatibility:** Android package ID remains unchanged for existing install data and preserved legal attribution. Original LGPL license text remains intact.
