# Jotify V7 — check on device

Before uninstalling older APKs, back up the existing Jotify data. Android package ID is intentionally unchanged for upgrades, but differently signed APKs cannot update over each other.

1. Build via `.github/workflows/import-and-build.yml` and verify 7.0.0+48; don't assume source ZIP alone changes the installed app.
2. Open Home; verify **V7.0 · Jotify+** badge.
3. Search a Saavn track; menu (•••) → **Hide this song**; search again, hidden song must not show. Use **Settings → Hidden songs & artists** to unhide.
4. Hide an artist; search artist and tracks; start album/radio/recommended queue and verify blocked artist does not play.
5. Find another version on Saavn via song menu; confirm title/artist search opens and can start a valid Saavn track.
6. Use Find on Spotify / Find on YouTube from search; they should launch external provider search. **Not** internal audio playback.
7. Test Saavn Wi-Fi/mobile playback, seeking, shuffle, next/previous, notification controls and background playback.
8. Test offline music, downloaded media, old favourites, playlists and recent history; no entries should be deleted by blacklist.
9. Test sleep timer, equalizer, synced lyrics, theme, backup/restore.

### Not yet verified

Flutter compile, source tests, APK signing, device install, API uptime, and real playback have **not** been executed in this workspace. If CI fails, collect the complete failing log before claiming success.
