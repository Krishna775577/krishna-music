# Spotube versus Jotify V8: source-code feature audit

Basis: user-provided `spotube-master.zip` (Spotube Kotlin Multiplatform source) and Jotify V8 Flutter source. This is a **source-code** comparison, not validated behavior on hardware. "Added" means code and UI routes exist; **not** a claim that APK compilation or integration tests have succeeded.

| Spotube capability | Jotify V8 source | Limitations / what is left |
|---|---|---|
| Search/discovery | Existing Saavn; Spotify/YouTube discovery UI | Separate provider catalogs, not unified play-everything engine |
| Play Saavn songs | Existing | Preserved from V7, device test pending |
| YouTube in-app video | Added official embedded WebView player | Embed can be disabled/blocked per video; real-device test pending |
| YouTube Music audio playback | Partial: official music-site link, music-video search | No public native third-party YouTube Music playback API integration |
| Spotify account login | Added OAuth 2.0 PKCE | Requires user's Spotify Developer client ID, approved user/account |
| Spotify saved tracks + playlist sync | Added API retrieval and local snapshot | Read-only metadata; not Spotify streaming/complete playback sync |
| Track/artist blacklist | Existing V7 | V7 logic preserved |
| Find alternate version | Existing V7 | Searches Saavn by track/title |
| Local files | Existing | Local Jotify audio query |
| Downloads | Existing Saavn/local | No Spotify/YouTube downloads |
| Synced lyrics / import `.lrc` | Existing V5 | Provider/track-dependent matching |
| EQ / speed / sleep timer | Existing | Subject to Android device |
| Queue/shuffle/repeat | Existing | Saavn/local playback handler |
| Themes, AMOLED, gestures | Existing V2–V5 | Includes legacy features, not necessarily Spotube behavior parity |
| Plugin architecture | Added discovery-manifest registry | **Not** Spotube JS / Zipline sandbox, plugin marketplace, streaming adapters |
| Live listening Jams | Added local Wi-Fi WebSocket sync | No global cloud/Internet Jam backend; device latency testing pending |
| Device-to-device music streaming | Added opt-in local-file HTTP Range transfer | Only currently playing personal local files on same Wi-Fi; no Spotify/YouTube retransmission, no Chromecast/DLNA |
| Remote device playback control | Added local paired play/pause/next/previous | Room code required, host opt-in; no cloud control |
| Last.fm scrobbling | Added API auth, now-playing, duration threshold, retry queue | Requires user's Last.fm API credentials and account; not real-device verified |
| Spotify playlists auto-import into Saavn | Partial | Spotify track tap opens Saavn search; not fully automated playlist mapping |
| Discord Rich Presence | Not implemented | Desktop-specific plugin/action needed |
| Windows/macOS/Linux full QA | Existing Flutter targets, incomplete | No cross-platform build verification in this release |
| Plugin marketplace & signed packages | Not implemented | Additional security and update system required |
| Cloud cross-network audio sync | Not implemented | Requires secure server, identity and latency protocols |

## Practical outcome

Jotify V8 contains numerous existing Saavn/local-music features **plus** new source implementations for OAuth library metadata, official video embeds, Last.fm scrobbling, LAN Jams, paired remote control and opt-in local-file LAN audio transfer. It is **not technically accurate** to claim every Spotube feature has been ported, or that Jotify now has more **verified, working** features than Spotube.

## Required acceptance tests on phones

1. GitHub Actions runs `flutter pub get`, `flutter analyze`, all Flutter tests and `flutter build apk --debug` without errors.
2. App clearly shows **V8.0 · Connect Studio** and opens all Connect Studio screens from Home/Settings.
3. Saavn search/play/pause/next/downloading and saved playlists work after upgrading without data loss.
4. Spotify OAuth with real Client ID and registered `jotify://spotify-callback` returns to the app; liked tracks and playlists paginate and display.
5. Official YouTube embed successfully plays an embeddable video and reports unavailable embeds correctly; YouTube Music remains official external link.
6. Last.fm authorize, playing a track >30 seconds, scrobble threshold, offline retry and Private Listening handling pass.
7. Two phones same Wi-Fi: Jam host/join, six-digit code, synchronization and remote controls. Host must explicitly enable sharing of current local audio, guest must hear it; switching off must stop access.
8. Install/uninstall discovery manifest and launch external search; invalid/non-HTTPS manifests rejected.

No provider login tokens, API secrets, or Spotify/YouTube media content are bundled.
