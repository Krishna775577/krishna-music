# Jotify V8 Connect Studio — implementation status

Based on comparison against user-provided `spotube-master.zip` and previous Jotify V7 source.

## New source modules

1. **Spotify library sync (metadata only)**: OAuth 2.0 PKCE (no embedded client secret), secure access/refresh token storage, user profile, liked tracks, private playlists, current 2026 `/playlists/{id}/items` endpoint, cached in Hive, clickable Saavn search or Spotify attribution link. Requires Spotify developer Client ID, an allowed account and redirect URI `jotify://spotify-callback`. Spotify audio is NOT playable in Jotify.
2. **YouTube in-app visible video**: official YouTube WebView embeds, correct app-ID HTTP Referer, optional YouTube Data API v3 music/video search. Not background-only audio; some owners disallow embedding. YouTube Music opens its official app/site; there is no supported general-purpose YT Music audio player API.
3. **Discovery plugin registry**: manifest JSON validation and install/uninstall, HTTPS URL templates and external discovery searches. No arbitrary JavaScript execution or third-party audio-provider binary plugins. This is a safe subset of Spotube's JS plugin system, not equivalent to it.
4. **LAN Jams**: host/join same Wi-Fi with 6-digit room code, queue/seek/pause sync over WebSockets, opt-in remote control. Saavn tracks fetched independently by each client.
5. **Device-to-device local audio streaming**: explicit opt-in, HTTP Range-supported streaming of **currently playing local files** over room-code-gated LAN connection; no commercial stream redistribution. Device playback and multi-device sync need physical tests.
6. **Last.fm**: login via auth.getToken/auth.getSession, session and shared secret in platform secure storage, now playing/scrobble based on listened duration, pending queue for offline retry, private listening respected. Requires user-supplied Last.fm API key/secret.

## Preserved V2–V7 features
Saavn music playback; search; albums; playlists; favourites; local music; downloads; lyrics/LRC; EQ, speed, sleep timer; V2–V5 feature hubs; V7 track/artist blocklists and alternative search. Application ID stays `com.shadow.blackhole` for update compatibility; license notices retained.

## Limitations and honest testing status
- This sandbox does not have Flutter/Dart SDK or an Android device. Static import, source marker, ZIP integrity and XML checks are possible, **not APK build or playback verification**.
- Spotify Developer API authorization and library scopes are subject to developer app eligibility, quotas and account permissions.
- Official YouTube embed can still return playback errors for restricted videos; it is not an unofficial stream ripper.
- YouTube Music **in-app native playback is NOT implemented**; only link to official service.
- Full Spotube Zipline/JS plugin runtime **is NOT implemented**; only safe discovery manifests.
- Cloud/internet Jams and arbitrary speaker casting are **not implemented**; LAN-only local sharing and remote is provided.
- Last.fm and Spotify flows require credentials supplied on the device; accounts are not included in source.
- Requires `flutter pub get`, `flutter analyze`, `flutter test`, an actual APK build and two-device acceptance tests for final confidence.

## Setup
1. Replace both `krishna-music-source-ready.zip` **and** `.github/workflows/import-and-build.yml` in your GitHub repository.
2. Run `Import ZIP and Build Jotify V8 Connect Studio` in GitHub Actions.
3. Download debug APK artifact, test **Settings → Jotify V8 · Connect Studio**. Check version **V8.0 · Connect Studio** on Home.
4. Spotify: create app at developer.spotify.com, add redirect URI `jotify://spotify-callback`, enter Client ID, authorize and sync.
5. Last.fm: create API account, enter credentials on device, authorize in browser, return and finish.
6. YouTube: paste video URL/ID; optional search requires Google Cloud YouTube Data API key.
7. Jams: on same Wi-Fi host a room on one phone and connect by displayed local IP:port and room code from another phone.

Sources: official Spotify Web API, Last.fm and YouTube embedded player documentation. No Spotify/Spotube code copied verbatim.
