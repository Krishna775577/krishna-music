import 'package:flutter_test/flutter_test.dart';
import 'package:jotify/Helpers/saavn_source_guard.dart';

void main() {
  group('Jotify online music source', () {
    test('allows JioSaavn CDN and official music URLs', () {
      expect(
        SaavnSourceGuard.isSaavnUrl('https://aac.saavncdn.com/001/song_96.mp4'),
        isTrue,
      );
      expect(SaavnSourceGuard.isSaavnUrl('https://www.jiosaavn.com/song/id'), isTrue);
    });

    test('rejects unrelated hosts even when they imitate the domain', () {
      expect(SaavnSourceGuard.isSaavnUrl('https://example.com/song.mp3'), isFalse);
      expect(SaavnSourceGuard.isSaavnUrl('https://saavncdn.com.example.org/song.mp3'), isFalse);
      expect(SaavnSourceGuard.isSaavnUrl('javascript:alert(1)'), isFalse);
      expect(SaavnSourceGuard.isSaavnUrl(null), isFalse);
    });

    test('allows saved local audio but not other remote audio', () {
      expect(SaavnSourceGuard.isPlayableUrl('/storage/emulated/0/Music/song.m4a'), isTrue);
      expect(SaavnSourceGuard.isPlayableUrl('file:///storage/emulated/0/Music/song.mp3'), isTrue);
      expect(SaavnSourceGuard.isPlayableUrl('https://other-cdn.example/song.m4a'), isFalse);
    });
  });
}
