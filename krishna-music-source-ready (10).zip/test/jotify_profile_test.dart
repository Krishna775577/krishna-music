import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:hive/hive.dart';
import 'package:jotify/Helpers/jotify_profile.dart';

void main() {
  late Directory folder;
  late Box box;

  setUpAll(() async {
    folder = await Directory.systemTemp.createTemp('jotify_profile_test_');
    Hive.init(folder.path);
    box = await Hive.openBox('settings');
  });

  setUp(() async {
    await box.clear();
  });

  tearDownAll(() async {
    await Hive.close();
    await folder.delete(recursive: true);
  });

  test('real first launch displays the name screen', () {
    expect(JotifyProfile.hasProfile(box), isFalse);
  });

  test('saved legacy name never returns to the name screen', () async {
    await box.put('name', 'Krishna');
    expect(JotifyProfile.hasProfile(box), isTrue);
    await JotifyProfile.restoreOnStartup();
    expect(box.get('name'), 'Krishna');
    expect((box.get('userId') as String).isNotEmpty, isTrue);
    expect(box.get('jotifyProfileCreated'), isTrue);
  });

  test('saved legacy user ID restores the profile without prompting', () async {
    await box.put('userId', 'existing-id');
    expect(JotifyProfile.hasProfile(box), isTrue);
    await JotifyProfile.restoreOnStartup();
    expect(box.get('userId'), 'existing-id');
    expect(box.get('name'), 'Guest');
  });

  test('name is persisted, then restart restores the same ID', () async {
    await JotifyProfile.save('  Krishna  ');
    final firstId = box.get('userId');
    expect(JotifyProfile.hasProfile(box), isTrue);
    expect(box.get('name'), 'Krishna');
    await box.close();
    box = await Hive.openBox('settings');
    await JotifyProfile.restoreOnStartup();
    expect(box.get('name'), 'Krishna');
    expect(box.get('userId'), firstId);
    expect(box.get('jotifyProfileCreated'), isTrue);
  });

  test('skip saves Guest permanently', () async {
    await JotifyProfile.save('  ');
    expect(box.get('name'), 'Guest');
    expect(JotifyProfile.hasProfile(box), isTrue);
    await JotifyProfile.restoreOnStartup();
    expect(box.get('name'), 'Guest');
  });
}
