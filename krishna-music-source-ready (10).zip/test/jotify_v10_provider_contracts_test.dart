import 'package:flutter_test/flutter_test.dart';
import 'package:jotify/Features/jotify_connect/provider_contracts.dart';
import 'package:jotify/Helpers/saavn_source_guard.dart';

void main() {
  test('Jotify provider descriptors must not pretend metadata sources play audio', () {
    expect(JotifyProviderRegistry.find('saavn')!.supports(JotifyProviderCapability.audioPlayback), isTrue);
    expect(JotifyProviderRegistry.find('spotify')!.supports(JotifyProviderCapability.audioPlayback), isFalse);
    expect(JotifyProviderRegistry.find('youtube')!.supports(JotifyProviderCapability.videoEmbed), isTrue);
    expect(JotifyProviderRegistry.mayServeOnlineAudio('youtube'), isFalse);
  });

  test('Saavn audio and local media remain playable; Spotify URLs do not', () {
    expect(SaavnSourceGuard.isPlayableUrl('https://aac.saavncdn.com/45/track_96.mp4'), isTrue);
    expect(SaavnSourceGuard.isPlayableUrl('file:///storage/emulated/0/Music/song.mp3'), isTrue);
    expect(SaavnSourceGuard.isPlayableUrl('https://open.spotify.com/track/example'), isFalse);
  });
}
