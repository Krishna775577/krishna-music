import 'package:flutter_test/flutter_test.dart';
import 'package:jotify/Features/jotify_connect/youtube_embed.dart';
void main() {
  test('accepts only official supported YouTube URL hosts/IDs', () {
    expect(JotifyYouTubePageIdParse.parse('https://www.youtube.com/watch?v=dQw4w9WgXcQ'), 'dQw4w9WgXcQ');
    expect(JotifyYouTubePageIdParse.parse('https://youtu.be/dQw4w9WgXcQ'), 'dQw4w9WgXcQ');
    expect(JotifyYouTubePageIdParse.parse('https://music.youtube.com/watch?v=dQw4w9WgXcQ'), 'dQw4w9WgXcQ');
    expect(JotifyYouTubePageIdParse.parse('https://evil.example/watch?v=dQw4w9WgXcQ'), isNull);
    expect(JotifyYouTubePageIdParse.parse('bad-video-id'), isNull);
  });
}
