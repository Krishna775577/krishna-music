import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:hive/hive.dart';
import 'package:audio_service/audio_service.dart';
import 'package:jotify/Features/spotube_parity/blocklist.dart';

void main() {
  late Directory temp;
  setUp(() async {
    temp = await Directory.systemTemp.createTemp('jotify-blocklist-');
    Hive.init(temp.path);
    await Hive.openBox('settings');
  });
  tearDown(() async {
    await Hive.close();
    await temp.delete(recursive: true);
  });

  test('blocks and unblocks track ID across search and audio queue', () async {
    const track = <String, String>{'id': 'saavn-123', 'title': 'Example song', 'artist': 'Singer'};
    expect(JotifyBlocklist.isBlockedMap(track), false);
    await JotifyBlocklist.blockTrack(track);
    expect(JotifyBlocklist.isBlockedMap(track), true);
    expect(JotifyBlocklist.blockedTracks.single['title'], 'Example song');
    final item = MediaItem(id: 'saavn-123', title: 'Example song', artist: 'Singer');
    expect(JotifyBlocklist.isBlockedMediaItem(item), true);
    await JotifyBlocklist.unblockTrack('saavn-123');
    expect(JotifyBlocklist.isBlockedMediaItem(item), false);
  });
  test('artist hiding is case-insensitive and matches duet participants', () async {
    await JotifyBlocklist.blockArtist('Example Artist');
    expect(JotifyBlocklist.isBlockedArtist('EXAMPLE artist, Another Artist'), true);
    expect(JotifyBlocklist.isBlockedArtist('Different Artist'), false);
    await JotifyBlocklist.unblockArtist('example artist');
    expect(JotifyBlocklist.blockedArtists, isEmpty);
  });
}
