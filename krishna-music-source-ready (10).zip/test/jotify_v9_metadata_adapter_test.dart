import 'package:flutter_test/flutter_test.dart';
import 'package:jotify/Features/jotify_connect/provider_adapters.dart';

void main() {
  test('MusicBrainz JSON recording metadata is never represented as audio', () {
    final records = JotifyMusicBrainzAdapter.parseRecordings({
      'recordings': [
        {
          'title': 'Example Song', 'id': 'some-mbid', 'length': 198000,
          'artist-credit': [
            {'name': 'Example Artist', 'artist': {'name': 'Example Artist'}}
          ],
        }
      ],
    });
    expect(records.length, 1);
    expect(records.first['name'], 'Example Song');
    expect(records.first['artist'], 'Example Artist');
    expect(records.first['durationMs'], 198000);
    expect(records.first.containsKey('url'), isFalse);
  });
  test('MusicBrainz parser tolerates missing recordings', () {
    expect(JotifyMusicBrainzAdapter.parseRecordings({'error': 'offline'}), isEmpty);
  });
}
