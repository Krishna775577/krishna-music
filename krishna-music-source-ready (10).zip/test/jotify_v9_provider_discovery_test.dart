import 'package:flutter_test/flutter_test.dart';
import 'package:jotify/Features/jotify_connect/provider_contracts.dart';
import 'package:jotify/Features/jotify_connect/lan_discovery.dart';

void main() {
  test('only Saavn has online audio capability', () {
    expect(JotifyProviderRegistry.mayServeOnlineAudio('saavn'), isTrue);
    expect(JotifyProviderRegistry.mayServeOnlineAudio('spotify'), isFalse);
    expect(JotifyProviderRegistry.mayServeOnlineAudio('youtube'), isFalse);
    expect(JotifyProviderRegistry.find('lastfm')!.supports(
      JotifyProviderCapability.scrobbling), isTrue);
  });
  test('LAN discovery rejects public and loopback IPs', () {
    expect(JotifyLanDiscovery.isPrivateAddress('192.168.1.4'), isTrue);
    expect(JotifyLanDiscovery.isPrivateAddress('172.16.0.2'), isTrue);
    expect(JotifyLanDiscovery.isPrivateAddress('10.0.0.1'), isTrue);
    expect(JotifyLanDiscovery.isPrivateAddress('8.8.8.8'), isFalse);
    expect(JotifyLanDiscovery.isPrivateAddress('127.0.0.1'), isFalse);
    expect(JotifyLanDiscovery.isPrivateAddress('evil.com'), isFalse);
  });
}
