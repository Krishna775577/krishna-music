import 'package:flutter_test/flutter_test.dart';
import 'package:jotify/Features/jotify_connect/track_matcher.dart';

void main() {
  test('normalizes text while keeping Hindi letters', () {
    expect(JotifyTrackMatcher.normalize('Tum & Main!'), 'tum and main');
    expect(JotifyTrackMatcher.normalize('दिल से'), 'दिल से');
  });
  test('same title and artist are a high-confidence match', () {
    final rating = JotifyTrackMatcher.score(
      title: 'Tum Hi Ho', artist: 'Arijit Singh',
      candidateTitle: 'Tum Hi Ho', candidateArtist: 'Arijit Singh',
      durationMs: 262000, candidateDurationSeconds: 265,
    );
    expect(rating, greaterThanOrEqualTo(0.88));
  });
  test('unrelated tracks are never automatically matched', () {
    final rating = JotifyTrackMatcher.score(
      title: 'Tum Hi Ho', artist: 'Arijit Singh',
      candidateTitle: 'Blinding Lights', candidateArtist: 'The Weeknd',
    );
    expect(rating, lessThan(0.5));
  });
  test('duration mismatch reduces confidence', () {
    final close = JotifyTrackMatcher.score(
      title: 'Music', artist: 'Singer', candidateTitle: 'Music',
      candidateArtist: 'Singer', durationMs: 200000, candidateDurationSeconds: 202);
    final far = JotifyTrackMatcher.score(
      title: 'Music', artist: 'Singer', candidateTitle: 'Music',
      candidateArtist: 'Singer', durationMs: 200000, candidateDurationSeconds: 315);
    expect(close, greaterThan(far));
  });
}
