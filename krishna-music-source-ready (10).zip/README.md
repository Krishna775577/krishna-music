# Jotify V9.0 — Spotube Parity Integration

**Source release** with reviewed Spotify→Saavn playlist matching, same-Wi-Fi Jam discovery, typed provider capabilities, MusicBrainz metadata search and opt-in discovery-plugin permissions. See [JOTIFY_V9_RELEASE_NOTES.md](JOTIFY_V9_RELEASE_NOTES.md) and [SPOTUBE_VS_JOTIFY_V9_FEATURE_MATRIX.md](SPOTUBE_VS_JOTIFY_V9_FEATURE_MATRIX.md). This is **not a prebuilt or device-tested APK**. The included GitHub Actions workflow runs analyzer/tests and builds the debug APK.

---

# Jotify V8 — Connect Studio

Personal music app in Flutter, upgraded from Jotify V7 using user-provided Spotube source as a feature reference. Jotify is **not** a full Spotube port; the original BlackHole LGPL attribution remains in the source.

## What's in V8

- Existing **Saavn** song playback/search, offline music, playlists, lyrics/LRC, EQ/speed/sleep timer, saved songs, V2–V7 tools, track/artist blocklists.
- **Spotify account/library sync (metadata)** using OAuth PKCE with user-entered Spotify Client ID. Shows liked tracks + playlists with explicit Spotify links; tap a track to search for a Saavn version. No Spotify audio playback/stream ripping.
- **YouTube official in-app video embed** with correct Android app-identification Referer; optional YouTube Data API v3 music-video search. YouTube Music links to its official site; YouTube Music third-party native audio playback not implemented.
- **JSON discovery plugins**: install/uninstall and search on HTTPS URL templates without executing untrusted JavaScript. Not a full Spotube Zipline plugin runtime.
- **Local Wi-Fi Jams**: six-digit pairing, real-time play/pause/seek sync and optional control from connected phone. Opt-in HTTP Range streaming of local files only. No cloud jams or commercial stream redistribution.
- **Last.fm scrobbling**: auth and secure credentials, now-playing, listening thresholds and offline retry.

See [JOTIFY_V8_RELEASE_NOTES.md](JOTIFY_V8_RELEASE_NOTES.md) for exact status, limitations, setup, and testing details.

## Build

Update both `krishna-music-source-ready.zip` and `.github/workflows/import-and-build.yml` in your GitHub repository. Run workflow **Import ZIP and Build Jotify V8 Connect Studio**. Check home for **V8.0 · Connect Studio**, and use Settings → **Jotify V8 · Connect Studio**.

The source was statically checked, but no Flutter SDK or Android device was available in this environment. Successful compilation and external-service/device behavior still need GitHub Actions and on-device verification.
