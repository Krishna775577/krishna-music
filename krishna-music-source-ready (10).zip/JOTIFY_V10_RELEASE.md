# Jotify V10 Unified Edition — source release

Based on the latest consolidated Jotify V9 ZIP. Version 10.0.0+70.

## Fixed and added
- Corrected inconsistent V8 login / V9 home and about markers to V10.
- New unified All Features screen reachable from Home hub button and Settings top entry.
- Reads the ACTUAL installed APK version/build from package_info_plus.
- Shows Spotify and Last.fm saved-session status without exposing secrets.
- Shows current same-Wi-Fi Jam state, imported Spotify metadata availability and provider limitations.
- Exposes V2–V7 screens directly instead of hiding features in multiple Settings levels.
- Retains Saavn playback, downloads, lyrics, local files, blocklist, Spotify metadata sync/import, official YouTube embed, LAN controls and Last.fm modules.
- Gradle wrapper, Android icon/manifest, tests, licensing and attribution remain bundled.

## Not claimed complete or tested
- Spotify login and Web API permissions need real user OAuth/phone testing.
- YouTube embed can be blocked by individual videos; native YouTube Music playback is not implemented.
- Full Spotube executable plugin engine, internet-wide Jams, Discord desktop presence and unrestricted third-party audio extraction are not implemented.
- Physical Android build and feature runtime testing were not available in this environment.

## One-ZIP import
Upload this exact file as `krishna-music-source-ready.zip` to repo root and run existing generic `Import ZIP and Build Android APK` workflow.
NOTE: A ZIP cannot replace the GitHub workflow already executing. The ZIP DOES NOT modify `.github/workflows`; old versions of Actions may still warn until repo YAML is separately changed.
Your existing importer may commit and delete the source ZIP itself; this behavior is controlled by the existing YAML.
