import 'package:flutter/material.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:logging/logging.dart';
import 'package:jotify/CustomWidgets/gradient_containers.dart';
import 'package:jotify/CustomWidgets/snackbar.dart';
import 'package:jotify/CustomWidgets/textinput_dialog.dart';
import 'package:jotify/Helpers/import_export_playlist.dart';
import 'package:jotify/Helpers/playlist.dart';
import 'package:jotify/Helpers/search_add_playlist.dart';

class ImportPlaylist extends StatelessWidget {
  ImportPlaylist({super.key});
  final Box settingsBox = Hive.box('settings');
  final List playlistNames =
      Hive.box('settings').get('playlistNames')?.toList() as List? ?? ['Favorite Songs'];

  @override
  Widget build(BuildContext context) => GradientContainer(
    child: Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(title: const Text('Import • Jotify Saavn'),
          backgroundColor: Colors.transparent),
      body: ListView(children: [
        ListTile(leading: const Icon(Icons.file_upload_outlined),
          title: Text(AppLocalizations.of(context)!.importFile),
          onTap: () => importFilePlaylist(context, playlistNames)),
        ListTile(leading: const Icon(Icons.library_music),
          title: const Text('Import Saavn Playlist Link'),
          subtitle: const Text('Only Saavn playlists are supported online'),
          onTap: () => importJioSaavn(context, playlistNames, settingsBox)),
      ]),
    ),
  );
}

Future<void> importJioSaavn(BuildContext context, List playlistNames, Box settingsBox) async {
  showTextInputDialog(
    context: context,
    title: AppLocalizations.of(context)!.enterPlaylistLink,
    initialText: '',
    keyboardType: TextInputType.url,
    onSubmitted: (String value, BuildContext dialogContext) async {
      final link = value.trim();
      Navigator.pop(dialogContext);
      try {
        if (!link.contains('saavn.com')) throw FormatException('Saavn URL required');
        final data = await SearchAddPlaylist.addJioSaavnPlaylist(link);
        if (data.isEmpty || data['tracks'] is! List) throw StateError('No playable songs');
        final title = data['title'].toString();
        await addPlaylist(title, data['tracks'] as List);
        if (!playlistNames.contains(title)) playlistNames.add(title);
      } catch (error, stack) {
        Logger.root.warning('Saavn playlist import failed', error, stack);
        if (context.mounted) ShowSnackBar().showSnackBar(context,
            AppLocalizations.of(context)!.failedImport);
      }
    },
  );
}
