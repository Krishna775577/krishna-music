import 'package:jotify/Features/spotube_parity/blocklist.dart';
import 'package:url_launcher/url_launcher.dart';
import 'dart:async';

import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:logging/logging.dart';
import 'package:jotify/APIs/api.dart';
import 'package:jotify/CustomWidgets/download_button.dart';
import 'package:jotify/CustomWidgets/image_card.dart';
import 'package:jotify/CustomWidgets/like_button.dart';
import 'package:jotify/CustomWidgets/song_tile_trailing_menu.dart';
import 'package:jotify/Screens/Common/song_list.dart';
import 'package:jotify/Screens/Search/albums.dart';
import 'package:jotify/Screens/Search/artists.dart';
import 'package:jotify/Services/player_service.dart';

/// Jotify V6: Saavn is the sole online search and playback catalogue.
/// Retains the SearchPage constructor used by existing screens and deep links.
class SearchPage extends StatefulWidget {
  final String query;
  final bool fromHome;
  final bool fromDirectSearch;
  final String? searchType; // retained solely for old callers; ignored
  final bool autofocus;
  const SearchPage({
    super.key,
    required this.query,
    this.fromHome = false,
    this.fromDirectSearch = false,
    this.searchType,
    this.autofocus = false,
  });

  @override
  State<SearchPage> createState() => _SaavnSearchPageState();
}

class _SaavnSearchPageState extends State<SearchPage> {
  final TextEditingController _search = TextEditingController();
  List<Map<dynamic, dynamic>> _sections = [];
  List<String> _trending = [];
  bool _loading = false;
  String? _error;
  int _requestId = 0;

  @override
  void initState() {
    super.initState();
    _search.text = widget.query;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      if (widget.query.trim().isNotEmpty) {
        _runSearch(widget.query);
      } else {
        _loadTrending();
      }
    });
  }

  @override
  void dispose() {
    _requestId++;
    _search.dispose();
    super.dispose();
  }

  Future<void> _loadTrending() async {
    try {
      final items = await SaavnAPI().getTopSearches().timeout(
        const Duration(seconds: 12),
      );
      if (mounted) setState(() => _trending = items.take(12).toList());
    } catch (error) {
      Logger.root.warning('Saavn trending search unavailable: $error');
    }
  }

  void _saveHistory(String query) {
    final box = Hive.box('settings');
    final saved = box.get('search', defaultValue: <dynamic>[]);
    final previous = saved is List ? saved.map((e) => e.toString()).toList() : <String>[];
    final history = <String>[
      query,
      ...previous.where((e) => e.toLowerCase() != query.toLowerCase()),
    ].take(10).toList();
    box.put('search', history);
    box.put('searchType', 'saavn');
  }

  Future<void> _runSearch(String raw) async {
    final query = raw.trim();
    if (query.isEmpty) {
      if (mounted) setState(() { _loading = false; _error = null; _sections = []; });
      return;
    }
    _search.text = query;
    _search.selection = TextSelection.collapsed(offset: query.length);
    FocusScope.of(context).unfocus();
    _saveHistory(query);
    final requestId = ++_requestId;
    setState(() { _loading = true; _error = null; _sections = []; });
    try {
      final result = await SaavnAPI().fetchSearchResults(query)
          .timeout(const Duration(seconds: 18));
      if (!mounted || requestId != _requestId) return;
      setState(() {
        _sections = result.map((section) {
          final copy = Map<dynamic, dynamic>.from(section);
          final entries = copy['items'];
          if (entries is List) {
            copy['items'] = entries.where((entry) {
              if (entry is! Map) return true;
              final artistResult = section['title'] == 'Artists' ||
                  entry['type']?.toString().toLowerCase() == 'artist';
              return artistResult
                  ? !JotifyBlocklist.isBlockedArtist(entry['title'])
                  : !JotifyBlocklist.isBlockedMap(entry);
            }).toList();
          }
          return copy;
        }).toList();
        _loading = false;
        if (!_sections.any((section) => (section['items'] as List?)?.isNotEmpty == true)) {
          _error = 'No visible Saavn results. Try another search or review hidden songs.';
        }
      });
    } on TimeoutException {
      if (!mounted || requestId != _requestId) return;
      setState(() { _loading = false; _error = 'Saavn search timed out. Retry karein.'; });
    } catch (error, stack) {
      Logger.root.warning('Saavn search failed', error, stack);
      if (!mounted || requestId != _requestId) return;
      setState(() { _loading = false; _error = 'Search load nahi hua. Internet check karke Retry karein.'; });
    }
  }

  void _openItem(Map item, String group) {
    final type = (item['type'] ?? '').toString().toLowerCase();
    if (group == 'Songs' || type == 'song') {
      PlayerInvoke.init(songsList: [item], index: 0, isOffline: false);
      return;
    }
    Navigator.of(context).push(MaterialPageRoute<void>(
      builder: (_) => group == 'Artists' || type == 'artist'
          ? ArtistSearchPage(data: item)
          : SongsListPage(listItem: item),
    ));
  }

  void _viewAll(String group) {
    final query = _search.text.trim();
    if (query.isEmpty) return;
    if (group == 'Songs') {
      Navigator.of(context).push(MaterialPageRoute<void>(
        builder: (_) => SongsListPage(listItem: <String, String>{
          'id': query, 'title': group, 'type': 'songs',
        }),
      ));
    } else if (group == 'Albums' || group == 'Playlists' || group == 'Artists') {
      Navigator.of(context).push(MaterialPageRoute<void>(
        builder: (_) => AlbumSearchPage(query: query, type: group),
      ));
    }
  }

  Future<void> _externalDiscovery(String site) async {
    final query = _search.text.trim();
    if (query.isEmpty) return;
    final uri = site == 'Spotify'
        ? Uri.parse('https://open.spotify.com/search/${Uri.encodeComponent(query)}')
        : Uri.https('www.youtube.com', '/results', <String, String>{'search_query': query});
    try {
      if (!await launchUrl(uri, mode: LaunchMode.externalApplication) && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not open $site.')));
      }
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('$site is unavailable on this device.')));
    }
  }

  Widget _resultSection(Map section) {
    final group = (section['title'] ?? '').toString();
    final items = section['items'];
    if (items is! List || items.isEmpty) return const SizedBox.shrink();
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 22, 12, 8),
        child: Row(children: [
          Expanded(child: Text(group, style: Theme.of(context).textTheme.titleLarge)),
          if (group != 'Top Result')
            TextButton(onPressed: () => _viewAll(group), child: const Text('View all')),
        ]),
      ),
      ...items.whereType<Map>().map((raw) {
        final item = Map<dynamic, dynamic>.from(raw);
        final type = (item['type'] ?? '').toString().toLowerCase();
        final isSong = group == 'Songs' || type == 'song';
        final isArtist = group == 'Artists' || type == 'artist';
        return ListTile(
          leading: imageCard(
            borderRadius: isArtist ? 50 : 9,
            placeholderImage: AssetImage(isArtist ? 'assets/artist.png' :
                isSong ? 'assets/cover.jpg' : 'assets/album.png'),
            imageUrl: (item['image'] ?? '').toString(),
          ),
          title: Text((item['title'] ?? 'Unknown').toString(), maxLines: 1,
              overflow: TextOverflow.ellipsis),
          subtitle: Text((item['subtitle'] ?? item['artist'] ?? 'Saavn').toString(),
              maxLines: 2, overflow: TextOverflow.ellipsis),
          trailing: isSong ? Row(mainAxisSize: MainAxisSize.min, children: [
            DownloadButton(data: item, icon: 'download'),
            LikeButton(mediaItem: null, data: item),
            SongTileTrailingMenu(data: item),
          ]) : null,
          onTap: () => _openItem(item, group),
        );
      }),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    final hasQuery = _search.text.trim().isNotEmpty;
    return Scaffold(
      appBar: AppBar(title: const Text('Jotify • Saavn Search'), centerTitle: true),
      body: SafeArea(child: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(14, 12, 14, 4),
          child: TextField(
            controller: _search,
            autofocus: widget.autofocus,
            textInputAction: TextInputAction.search,
            onSubmitted: _runSearch,
            onChanged: (_) => setState(() {}),
            decoration: InputDecoration(
              hintText: 'Search songs, artists, albums on Saavn',
              prefixIcon: const Icon(Icons.search_rounded),
              suffixIcon: IconButton(
                icon: const Icon(Icons.arrow_forward_rounded),
                tooltip: 'Search Saavn',
                onPressed: () => _runSearch(_search.text),
              ),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(18)),
            ),
          ),
        ),
        const Padding(
          padding: EdgeInsets.symmetric(horizontal: 20, vertical: 6),
          child: Row(children: [
            Icon(Icons.library_music_rounded, size: 16),
            SizedBox(width: 8),
            Text('In-app playback: Saavn'),
          ]),
        ),
        if (_search.text.trim().isNotEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 4),
            child: Wrap(spacing: 8, runSpacing: 2, children: [
              ActionChip(label: const Text('Find on Spotify ↗'),
                onPressed: () => _externalDiscovery('Spotify')),
              ActionChip(label: const Text('Find on YouTube ↗'),
                onPressed: () => _externalDiscovery('YouTube')),
            ]),
          ),
        Expanded(child: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
            ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
              Text(_error!, textAlign: TextAlign.center),
              const SizedBox(height: 12),
              FilledButton.icon(onPressed: () => _runSearch(_search.text),
                icon: const Icon(Icons.refresh), label: const Text('Retry')),
            ]))
          : _sections.isNotEmpty
            ? ListView(children: _sections.map(_resultSection).toList())
            : ListView(padding: const EdgeInsets.all(16), children: [
              Text(hasQuery ? 'Search dabakar Saavn results dekho' : 'Trending searches',
                style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 12),
              Wrap(spacing: 7, runSpacing: 6, children: _trending.map((q) =>
                ActionChip(label: Text(q), onPressed: () => _runSearch(q))).toList()),
            ]),
        ),
      ])),
    );
  }
}
