/*
 * Jotify customization by Krishna Bajaj.
 * Original BlackHole source Copyright (c) 2021-2023, Ankit Sangwan.
 * Original copyright and license notices are retained in the source tree.
 */
import 'package:jotify/CustomWidgets/gradient_containers.dart';
import 'package:jotify/Helpers/jotify_branding.dart';
import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';

class AboutPage extends StatefulWidget {
  const AboutPage({super.key});

  @override
  State<AboutPage> createState() => _AboutPageState();
}

class _AboutPageState extends State<AboutPage> {
  String version = '';

  @override
  void initState() {
    super.initState();
    PackageInfo.fromPlatform().then((info) {
      if (mounted) setState(() => version = info.version);
    });
  }

  Future<void> _openRepo() async {
    final url = Uri.parse('https://github.com/Krishna775577/krishna-music');
    await launchUrl(url, mode: LaunchMode.externalApplication);
  }

  @override
  Widget build(BuildContext context) {
    return GradientContainer(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        appBar: AppBar(
          title: const Text('About Jotify'),
          centerTitle: true,
          backgroundColor: Colors.transparent,
          elevation: 0,
        ),
        body: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            ValueListenableBuilder<Box>(
              valueListenable: Hive.box('settings').listenable(
                keys: [JotifyBranding.nameKey, JotifyBranding.iconKey],
              ),
              builder: (context, box, child) => Column(
                children: [
                  JotifyBranding.logo(size: 90),
                  const SizedBox(height: 14),
                  Text(JotifyBranding.name,
                    style: Theme.of(context).textTheme.headlineMedium),
                  const SizedBox(height: 6),
                  const Text('Jotify V10 • Unified Edition • Krishna Bajaj'),
                ],
              ),
            ),
            const SizedBox(height: 20),
            ListTile(
              leading: const Icon(Icons.info_outline),
              title: const Text('Version'),
              subtitle: Text(version.isEmpty ? 'Loading…' : version),
            ),
            ListTile(
              leading: const Icon(Icons.code),
              title: const Text('Jotify source code'),
              subtitle: const Text('GitHub • Krishna Bajaj'),
              onTap: _openRepo,
            ),
            ListTile(
              leading: const Icon(Icons.share),
              title: const Text('Share Jotify'),
              onTap: () => Share.share(
                'Jotify - https://github.com/Krishna775577/krishna-music',
              ),
            ),
            const Divider(),
            const ListTile(
              leading: Icon(Icons.favorite_border),
              title: Text('Original open-source attribution'),
              subtitle: Text(
                'Original open-source credits and GPL license are preserved in the source. '
                'The original copyright and license notices remain included '
                'in the source code.'
              ),
            ),
          ],
        ),
      ),
    );
  }
}
