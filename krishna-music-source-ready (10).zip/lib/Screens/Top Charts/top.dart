import 'dart:async';

import 'package:flutter/material.dart';
import 'package:logging/logging.dart';
import 'package:jotify/APIs/api.dart';
import 'package:jotify/Screens/Search/search.dart';

/// Saavn Discover uses the JioSaavn catalogue.
/// Search suggestions are not presented as ranked tracks or fabricated charts.
class TopCharts extends StatefulWidget {
  final PageController pageController;
  const TopCharts({super.key, required this.pageController});

  @override
  State<TopCharts> createState() => _TopChartsState();
}

class _TopChartsState extends State<TopCharts> {
  bool _loading = true;
  String? _error;
  List<String> _trending = <String>[];

  @override
  void initState() {
    super.initState();
    _fetch();
  }

  Future<void> _fetch() async {
    setState(() { _loading = true; _error = null; });
    try {
      final result = await SaavnAPI().getTopSearches()
          .timeout(const Duration(seconds: 14));
      if (!mounted) return;
      setState(() {
        _trending = result.where((e) => e.trim().isNotEmpty).toSet().take(30).toList();
        _loading = false;
      });
    } on TimeoutException {
      if (mounted) setState(() { _loading = false; _error = 'Saavn request timed out'; });
    } catch (error, stack) {
      Logger.root.warning('Saavn discover unavailable', error, stack);
      if (mounted) setState(() { _loading = false; _error = 'Could not load Saavn searches'; });
    }
  }

  void _search(String title) => Navigator.of(context).push(
    MaterialPageRoute<void>(builder: (_) => SearchPage(query: title, searchType: 'saavn')),
  );

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Saavn Discover'), centerTitle: true),
    body: _loading ? const Center(child: CircularProgressIndicator())
      : _error != null ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
          Text(_error!),
          TextButton.icon(onPressed: _fetch, icon: const Icon(Icons.refresh),
              label: const Text('Retry')),
        ]))
      : RefreshIndicator(
          onRefresh: _fetch,
          child: ListView(padding: const EdgeInsets.all(14), children: [
            const ListTile(
              leading: Icon(Icons.music_note_rounded),
              title: Text('Explore on Saavn'),
              subtitle: Text('Popular searches from Saavn — not official chart rankings'),
            ),
            if (_trending.isEmpty)
              const ListTile(title: Text('No trending searches available')),
            ..._trending.map((q) => ListTile(
              leading: const Icon(Icons.trending_up_rounded),
              title: Text(q, maxLines: 1, overflow: TextOverflow.ellipsis),
              trailing: const Icon(Icons.chevron_right_rounded),
              onTap: () => _search(q),
            )),
          ]),
        ),
  );
}
