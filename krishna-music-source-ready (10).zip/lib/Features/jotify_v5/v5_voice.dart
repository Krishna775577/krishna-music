import 'package:flutter/material.dart';
import 'package:jotify/Screens/Search/search.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

/// Voice commands are deliberately *search-first*. No silent playback starts
/// or paid cloud AI account is required. Android/iOS recognizer availability
/// and language support depend on the installed OS service.
class JotifyVoiceSearch extends StatefulWidget {
  const JotifyVoiceSearch({super.key});
  @override
  State<JotifyVoiceSearch> createState() => _JotifyVoiceSearchState();
}

class _JotifyVoiceSearchState extends State<JotifyVoiceSearch> {
  final stt.SpeechToText _speech = stt.SpeechToText();
  final TextEditingController _text = TextEditingController();
  bool _active = false;
  bool _ready = false;
  String _message = 'Tap the microphone, then say a song or artist.';

  @override
  void dispose() {
    _speech.stop();
    _text.dispose();
    super.dispose();
  }

  Future<void> _listen() async {
    if (_active) {
      await _speech.stop();
      if (mounted) setState(() => _active = false);
      return;
    }
    try {
      if (!_ready) {
        _ready = await _speech.initialize(
          onError: (e) { if (mounted) setState(() => _message = 'Speech service: $e'); },
          onStatus: (status) { if (mounted && status == 'notListening') setState(() => _active = false); },
        );
      }
      if (!_ready) { if (mounted) setState(() => _message = 'Speech recognizer unavailable or microphone permission denied. You can type instead.'); return; }
      await _speech.listen(onResult: (result) {
        if (!mounted) return;
        setState(() { _text.text = result.recognizedWords; _message = result.finalResult ? 'Ready to search.' : 'Listening…'; });
      }, listenFor: const Duration(seconds: 18), pauseFor: const Duration(seconds: 3), partialResults: true);
      if (mounted) setState(() => _active = true);
    } catch (error) { if (mounted) setState(() => _message = 'Voice input unavailable: $error'); }
  }

  void _search() {
    var query = _text.text.trim();
    if (query.isEmpty) return;
    query = query.replaceFirst(RegExp(r'^(hey jotify[, ]*|play |search |find |bajao |lagao |chalao )', caseSensitive: false), '').trim();
    query = query.replaceFirst(RegExp(r'\s+(play karo|bajao|chalao)$', caseSensitive: false), '').trim();
    if (query.isEmpty) return;
    _speech.stop();
    Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => SearchPage(query: query, searchType: 'saavn')));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Jotify Voice Search')),
    body: ListView(padding: const EdgeInsets.all(20), children: <Widget>[
      const Text('Speak Hindi, English or your supported device language. This uses your phone’s speech recognition service.', textAlign: TextAlign.center),
      const SizedBox(height: 24),
      Center(child: IconButton(iconSize: 74, icon: Icon(_active ? Icons.mic : Icons.mic_none_rounded),
        color: Theme.of(context).colorScheme.secondary, onPressed: _listen,
        tooltip: _active ? 'Stop listening' : 'Start listening')),
      Text(_message, textAlign: TextAlign.center),
      const SizedBox(height: 20),
      TextField(controller: _text, decoration: const InputDecoration(labelText: 'Recognized music request', border: OutlineInputBorder()),
        textInputAction: TextInputAction.search, onSubmitted: (_) => _search()),
      const SizedBox(height: 12),
      const Chip(label: Text('Saavn only')),
      const SizedBox(height: 12),
      FilledButton.icon(onPressed: _search, icon: const Icon(Icons.search), label: const Text('Search music')),
      const SizedBox(height: 10),
      const Text('Voice recognition only converts speech into a search query; starting a track still requires selecting a result.', textAlign: TextAlign.center),
    ]),
  );
}
