import 'dart:async';
import 'dart:math';

import 'package:audio_service/audio_service.dart';
import 'package:hive/hive.dart';
import 'package:jotify/Features/jotify_v5/v5_data.dart';
import 'package:jotify/Helpers/mediaitem_converter.dart';
import 'package:jotify/Helpers/saavn_source_guard.dart';
import 'package:jotify/Screens/Player/audioplayer.dart';

/// Optional queue-top-up for existing Saavn/local audio only. It never touches
/// removed video providers. Failures are contained and logged.
class V5Flow {
  static StreamSubscription<QueueState>? _sub;
  static StreamSubscription<MediaItem?>? _history;
  static AudioPlayerHandler? _handler;
  static bool _busy = false;
  static final Set<String> _seen = <String>{};

  static void start(AudioPlayerHandler audio) {
    if (_handler != null) return;
    _handler = audio;
    _history = audio.mediaItem.listen((item) {
      if (item != null && V5Data.settings.get('v5CalendarEnabled', defaultValue: true) == true) {
        V5Data.logPlay(item).catchError((Object _) {});
      }
    });
    _sub = audio.queueState.listen((state) { _extend(state); });
  }

  static Future<void> _extend(QueueState state) async {
    if (_busy || _handler == null || !Hive.isBoxOpen('settings')) return;
    if (V5Data.settings.get('v5FlowEnabled', defaultValue: false) != true) return;
    final items = state.queue;
    if (items.isEmpty || state.queueIndex == null) return;
    final current = state.queueIndex!;
    if (current < 0 || items.length - current > 3) return;
    final playing = items[current.clamp(0, items.length - 1).toInt()];
    if (!SaavnSourceGuard.isSaavnUrl(playing.extras?['url'])) return;
    _busy = true;
    try {
      final candidate = V5Data.flowCandidates(artist: playing.artist);
      final ids = items.map((i) => i.id).toSet();
      final fresh = candidate.where((s) => !ids.contains(s['id'].toString()) &&
          !_seen.contains(s['id'].toString())).toList();
      if (fresh.isEmpty) return;
      fresh.shuffle(Random(DateTime.now().millisecondsSinceEpoch));
      final next = fresh.take(5).toList();
      final media = next.map((m) => MediaItemConverter.mapToMediaItem(m)).toList();
      await _handler!.addQueueItems(media);
      _seen.addAll(next.map((m) => m['id'].toString()));
      if (_seen.length > 100) _seen.clear();
    } catch (_) {
      // Provider and queue errors cannot be allowed to break active playback.
    } finally {
      _busy = false;
    }
  }

  static Future<void> dispose() async {
    await _sub?.cancel();
    await _history?.cancel();
    _sub = null;
    _history = null;
    _handler = null;
  }
}
