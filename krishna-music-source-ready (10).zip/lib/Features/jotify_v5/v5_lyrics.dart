import 'dart:convert';
import 'dart:io';
import 'package:audio_service/audio_service.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:get_it/get_it.dart';
import 'package:hive/hive.dart';
import 'package:jotify/Helpers/lyrics.dart';
import 'package:jotify/Screens/Player/audioplayer.dart';

class JotifyLyricsPro extends StatefulWidget {
  const JotifyLyricsPro({super.key});
  @override
  State<JotifyLyricsPro> createState() => _JotifyLyricsProState();
}

class _LrcRow {
  final Duration time;
  final String text;
  const _LrcRow(this.time, this.text);
}

class _JotifyLyricsProState extends State<JotifyLyricsPro> {
  final AudioPlayerHandler _audio = GetIt.I<AudioPlayerHandler>();
  String? _id;
  Future<Map<String, String>>? _future;
  double _size = 18;
  bool _loadingImport = false;
  int _offset = 0;

  String _aliasKey(MediaItem item) => 'v5lyricsAlias:${item.id}';

  String _key(MediaItem item) => 'v5lrc:${item.title.trim().toLowerCase()}:${(item.artist ?? '').trim().toLowerCase()}';
  String _offsetKey(MediaItem item) => 'v5lrcOffset:${item.title.trim().toLowerCase()}:${(item.artist ?? '').trim().toLowerCase()}';

  Future<Map<String, String>> _load(MediaItem item) async {
    final saved = Hive.box('settings').get(_key(item));
    if (saved is String && saved.trim().isNotEmpty) {
      return {'id': item.id, 'lyrics': saved, 'source': 'Imported LRC · offline', 'type': 'lrc'};
    }
    final alias = Hive.box('settings').get(_aliasKey(item));
    final override = alias is Map ? alias : <String, String>{};
    return Lyrics.getLyrics(id: item.id,
      title: (override['title'] ?? item.title).toString(),
      artist: (override['artist'] ?? item.artist ?? '').toString(),
      saavnHas: true).timeout(
      const Duration(seconds: 25), onTimeout: () => {'id': item.id, 'lyrics': '', 'type': 'text', 'source': 'Timed out'});
  }

  List<_LrcRow> _parse(String lrc) {
    final rows = <_LrcRow>[];
    final exp = RegExp(r'\[(\d{1,2}):(\d{2})(?:[.:](\d{1,3}))?\]');
    for (final line in const LineSplitter().convert(lrc)) {
      final stamps = exp.allMatches(line).toList();
      final text = line.replaceAll(exp, '').trim();
      if (text.isEmpty) continue;
      for (final match in stamps) {
        final min = int.tryParse(match.group(1) ?? '') ?? 0;
        final sec = int.tryParse(match.group(2) ?? '') ?? 0;
        final raw = match.group(3) ?? '0';
        final milli = int.tryParse(raw.padRight(3, '0').substring(0, 3)) ?? 0;
        rows.add(_LrcRow(Duration(minutes: min, seconds: sec, milliseconds: milli), text));
      }
    }
    rows.sort((a, b) => a.time.compareTo(b.time));
    return rows;
  }

  Future<void> _editLookup(MediaItem item) async {
    final existing = Hive.box('settings').get(_aliasKey(item));
    final alias = existing is Map ? existing : <String, String>{};
    final title = TextEditingController(text: (alias['title'] ?? item.title).toString());
    final artist = TextEditingController(text: (alias['artist'] ?? item.artist ?? '').toString());
    final save = await showDialog<bool>(context: context, builder: (context) => AlertDialog(
      title: const Text('Lyrics search metadata'),
      content: Column(mainAxisSize: MainAxisSize.min, children: <Widget>[
        TextField(controller: title, decoration: const InputDecoration(labelText: 'Song title')),
        TextField(controller: artist, decoration: const InputDecoration(labelText: 'Artist')),
      ]),
      actions: <Widget>[
        TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
        FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Search again')),
      ],
    ));
    if (save == true && title.text.trim().isNotEmpty) {
      await Hive.box('settings').put(_aliasKey(item), <String, String>{
        'title': title.text.trim(), 'artist': artist.text.trim(),
      });
      await Lyrics.clearCache(title.text.trim(), artist.text.trim());
      if (mounted) setState(() => _future = _load(item));
    }
    title.dispose(); artist.dispose();
  }

  Future<void> _import(MediaItem item) async {
    setState(() => _loadingImport = true);
    try {
      final chosen = await FilePicker.platform.pickFiles(type: FileType.custom,
          allowedExtensions: <String>['lrc', 'txt'], withData: true);
      if (chosen == null || chosen.files.isEmpty) return;
      final file = chosen.files.single;
      if (file.size > 256 * 1024) throw const FormatException('Lyrics file too large (max 256 KB)');
      final bytes = file.bytes ?? (file.path != null ? await File(file.path!).readAsBytes() : null);
      if (bytes == null) throw const FormatException('Could not read lyrics file');
      final text = utf8.decode(bytes);
      if (_parse(text).isEmpty) throw const FormatException('File has no valid [mm:ss.xx] timed lyrics');
      await Hive.box('settings').put(_key(item), text);
      if (mounted) setState(() => _future = _load(item));
    } catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Import failed: $error')));
    } finally { if (mounted) setState(() => _loadingImport = false); }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Lyrics Studio 3.0')),
    body: StreamBuilder<MediaItem?>(stream: _audio.mediaItem, builder: (context, snapshot) {
      final item = snapshot.data;
      if (item == null) return const Center(child: Text('Play a Saavn/local track to show lyrics.'));
      if (_id != item.id) {
        _id = item.id;
        _offset = (Hive.box('settings').get(_offsetKey(item), defaultValue: 0) as num).toInt();
        _future = _load(item);
      }
      return Column(children: <Widget>[
        ListTile(title: Text(item.title), subtitle: Text(item.artist ?? 'Unknown'),
          trailing: IconButton(tooltip: 'Retry online lyrics', icon: const Icon(Icons.refresh), onPressed: () async {
            await Lyrics.clearCache(item.title, item.artist ?? '');
            if (mounted) setState(() => _future = _load(item));
          })),
        SingleChildScrollView(scrollDirection: Axis.horizontal, child: Row(children: <Widget>[
          TextButton.icon(onPressed: _loadingImport ? null : () => _import(item), icon: const Icon(Icons.file_open), label: const Text('Import .lrc')),
          TextButton.icon(onPressed: () => _editLookup(item), icon: const Icon(Icons.edit), label: const Text('Fix title/artist')),
          TextButton(onPressed: () async { await Hive.box('settings').delete(_key(item)); if (mounted) setState(() => _future = _load(item)); }, child: const Text('Remove import')),
          IconButton(tooltip: 'Smaller text', icon: const Icon(Icons.text_decrease), onPressed: () => setState(() => _size = (_size - 2).clamp(14, 30).toDouble())),
          IconButton(tooltip: 'Larger text', icon: const Icon(Icons.text_increase), onPressed: () => setState(() => _size = (_size + 2).clamp(14, 30).toDouble())),
        ])),
        Row(children: <Widget>[
          const SizedBox(width: 10), const Text('Sync offset'),
          Expanded(child: Slider(value: _offset.clamp(-5000, 5000).toDouble(), min: -5000, max: 5000,
            divisions: 20, onChanged: (v) => setState(() => _offset = v.round()),
            onChangeEnd: (v) => Hive.box('settings').put(_offsetKey(item), v.round()))),
          SizedBox(width: 63, child: Text('${_offset}ms')),
        ]),
        Expanded(child: FutureBuilder<Map<String, String>>(future: _future, builder: (context, result) {
          if (!result.hasData) return const Center(child: CircularProgressIndicator());
          final map = result.data!;
          final text = map['lyrics'] ?? '';
          if (text.trim().isEmpty) return const Center(child: Padding(padding: EdgeInsets.all(22), child:
            Text('Lyrics not found. Try a different spelling in the song metadata or import a timestamped .lrc file.', textAlign: TextAlign.center)));
          final lines = _parse(text);
          if (lines.isEmpty) return ListView(children: <Widget>[
            Padding(padding: const EdgeInsets.all(12), child: Text('Source: ${map['source'] ?? 'Unknown'}')),
            Padding(padding: const EdgeInsets.all(18), child: Text(text, textAlign: TextAlign.center, style: TextStyle(fontSize: _size, height: 1.65))),
          ]);
          return StreamBuilder<Duration>(stream: AudioService.position, builder: (context, position) {
            final time = (position.data ?? Duration.zero).inMilliseconds + _offset;
            int active = -1;
            for (var i = 0; i < lines.length; i++) { if (lines[i].time.inMilliseconds <= time) active = i; else break; }
            return ListView.builder(itemCount: lines.length + 1, padding: const EdgeInsets.all(16),
              itemBuilder: (context, index) {
                if (index == 0) return Padding(padding: const EdgeInsets.only(bottom: 12),
                  child: Text('Source: ${map['source'] ?? 'Unknown'} · ${lines.length} timed lines', textAlign: TextAlign.center));
                final i = index - 1;
                return InkWell(onTap: () => _audio.seek(lines[i].time), child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 9), child: Text(lines[i].text,
                    textAlign: TextAlign.center, style: TextStyle(fontSize: _size, height: 1.4,
                    fontWeight: i == active ? FontWeight.bold : FontWeight.normal,
                    color: i == active ? Theme.of(context).colorScheme.secondary : Theme.of(context).textTheme.bodyLarge?.color)),
                ));
              });
          });
        })),
      ]);
    }),
  );
}
