import 'dart:math';
import 'package:audio_service/audio_service.dart';
import 'package:flutter/material.dart';
import 'package:get_it/get_it.dart';
import 'package:hive/hive.dart';
import 'package:jotify/Features/jotify_v5/v5_data.dart';
import 'package:jotify/Features/jotify_v5/v5_lyrics.dart';
import 'package:jotify/Features/jotify_v5/v5_tools.dart';
import 'package:jotify/Features/jotify_v5/v5_voice.dart';
import 'package:jotify/Screens/Player/audioplayer.dart';
import 'package:jotify/Services/player_service.dart';

/// A V5 hub layered over V4, without replacing home, Saavn player.
class JotifyV5Hub extends StatefulWidget {
  const JotifyV5Hub({super.key});
  @override State<JotifyV5Hub> createState() => _JotifyV5HubState();
}

class _JotifyV5HubState extends State<JotifyV5Hub> {
  final AudioPlayerHandler _audio = GetIt.I<AudioPlayerHandler>();
  bool _working = false;
  bool _float = false;
  double _left = 14, _bottom = 15;
  Box get _settings => Hive.box('settings');

  void _open(Widget page) => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => page));
  Future<void> _toggle(String key, bool value) async {
    await _settings.put(key, value);
    if (mounted) setState(() {});
  }
  Future<void> _startFlow() async {
    if (_working) return;
    final library = V5Data.flowCandidates();
    if (library.isEmpty) { v5Toast(context, 'Save some Saavn songs first to create a Flow.'); return; }
    setState(() => _working = true);
    try {
      library.shuffle(Random());
      await PlayerInvoke.init(songsList: library.take(24).toList(), index: 0);
      if (mounted) v5Toast(context, 'Playing Flow from your saved Saavn tracks');
    } catch (e) { if (mounted) v5Toast(context, 'Could not start Flow: $e'); }
    finally { if (mounted) setState(() => _working = false); }
  }

  Widget _section(String title, IconData icon, String summary, List<Widget> children) => Card(
    margin: const EdgeInsets.symmetric(vertical: 6),
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(19)),
    child: Padding(padding: const EdgeInsets.all(15), child: Column(
      crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
        Row(children: <Widget>[
          Icon(icon, color: Theme.of(context).colorScheme.secondary), const SizedBox(width: 8),
          Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 17))),
        ]),
        const SizedBox(height: 5),
        Text(summary, style: Theme.of(context).textTheme.bodySmall),
        const SizedBox(height: 8), ...children,
      ])),
  );
  Widget _openButton(String text, Widget page, IconData icon) =>
    OutlinedButton.icon(onPressed: () => _open(page), icon: Icon(icon, size: 19), label: Text(text));

  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Jotify V5 Features')),
    body: LayoutBuilder(builder: (context, bounds) => Stack(children: <Widget>[
      ListView(padding: const EdgeInsets.fromLTRB(14, 12, 14, 120), children: <Widget>[
        Container(padding: const EdgeInsets.all(22), decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22), gradient: LinearGradient(colors: <Color>[
            Theme.of(context).colorScheme.secondary.withOpacity(.34), Theme.of(context).cardColor,
          ])), child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
            Text('JOTIFY V5', style: TextStyle(fontSize: 29, fontWeight: FontWeight.w900)),
            SizedBox(height: 5), Text('Discover more, listen privately, personalize everything.'),
          ])),
        _section('1. Jotify Flow · Infinite Music', Icons.all_inclusive,
          'Adds compatible saved/recent Saavn songs when the audio queue runs low. Saavn audio playback stays active.', <Widget>[
          SwitchListTile.adaptive(contentPadding: EdgeInsets.zero,
            title: const Text('Auto-extend my music queue'),
            subtitle: const Text('Off by default; on-device suggestions, no external AI catalog.'),
            value: _settings.get('v5FlowEnabled', defaultValue: false) == true,
            onChanged: (v) => _toggle('v5FlowEnabled', v)),
          FilledButton.icon(onPressed: _working ? null : _startFlow,
            icon: const Icon(Icons.play_arrow), label: const Text('Start Jotify Flow')),
        ]),
        _section('2. Jotify Voice', Icons.mic_none_rounded,
          'Speak a song/artist, confirm the transcription, then search your selected provider.', <Widget>[
          _openButton('Open voice search', const JotifyVoiceSearch(), Icons.mic_rounded),
        ]),
        _section('3. Lyrics Studio 3.0', Icons.lyrics_outlined,
          'Better source lookup, offline LRC file import, line sync and ±5-second manual timing offset.', <Widget>[
          _openButton('Open lyrics 3.0', const JotifyLyricsPro(), Icons.music_note),
        ]),
        _section('4. Jotify Together', Icons.people_outline,
          'Export/import portable playlist JSON to collaborate asynchronously. No real-time cloud account or synchronization.', <Widget>[
          _openButton('Share / import playlists', const JotifyTogether(), Icons.share),
        ]),
        _section('5. Jotify Focus', Icons.timer_outlined,
          '15–60-minute Pomodoro timer, with an optional music pause at completion.', <Widget>[
          _openButton('Open focus timer', const JotifyFocus(), Icons.play_circle_outline),
        ]),
        _section('6. Music Recognition', Icons.hearing_rounded,
          'Identify Jotify’s current track, or hand off nearby music recognition to an installed Android service.', <Widget>[
          _openButton('Recognition tools', const JotifyMusicRecognition(), Icons.graphic_eq),
        ]),
        _section('7. Jotify Discover', Icons.travel_explore_rounded,
          'Rediscover saved tracks and open the real Saavn search for new releases.', <Widget>[
          _openButton('Open Discover', const JotifyDiscover(), Icons.explore),
        ]),
        _section('8. Audio Bookmarks', Icons.bookmarks_outlined,
          'Save real playback timestamps; seek back when the bookmarked song is active.', <Widget>[
          _openButton('View bookmarks', const JotifyBookmarks(), Icons.bookmark),
        ]),
        _section('9. Floating Mini Player', Icons.picture_in_picture_alt,
          'Movable controller within V5 Studio. System-wide Android overlay is not requested and needs separate OS permission.', <Widget>[
          SwitchListTile.adaptive(contentPadding: EdgeInsets.zero,
            title: const Text('Show movable mini player here'), value: _float,
            onChanged: (value) => setState(() => _float = value)),
        ]),
        _section('10. Jotify Vault', Icons.lock_outline,
          'PIN-gated V5 saved-track list. This is NOT disk encryption or a global lock on older playlists.', <Widget>[
          _openButton('Open Vault', const JotifyVault(), Icons.lock_open),
        ]),
        _section('11. Smart Network Mode', Icons.network_check_rounded,
          'Prefer 96 kbps for future Saavn track sources on mobile data; existing playback is not interrupted.', <Widget>[
          SwitchListTile.adaptive(contentPadding: EdgeInsets.zero,
            title: const Text('Data saver on mobile networks'),
            subtitle: const Text('Quality selection applies to new streams, not an already-buffered track.'),
            value: _settings.get('v5SmartNetworkEnabled', defaultValue: false) == true,
            onChanged: (v) => _toggle('v5SmartNetworkEnabled', v)),
        ]),
        _section('12. Music Calendar', Icons.calendar_month,
          'Shows actual track starts recorded from V5 onward. Private mode suppresses future records.', <Widget>[
          _openButton('Open calendar', const JotifyMusicCalendar(), Icons.event_note),
        ]),
        const Padding(padding: EdgeInsets.all(12), child: Text(
          'V5 adds opt-in tools without changing current Saavn, removed video providers, themes, V2–V4 screens or original app storage paths. Build and device QA are still required.',
          textAlign: TextAlign.center)),
      ]),
      if (_float) Positioned(left: _left, bottom: _bottom,
        child: GestureDetector(onPanUpdate: (details) => setState(() {
          _left = (_left + details.delta.dx).clamp(6.0, max(6.0, bounds.maxWidth - 236)).toDouble();
          _bottom = (_bottom - details.delta.dy).clamp(6.0, max(6.0, bounds.maxHeight - 85)).toDouble();
        }), child: Material(elevation: 10, borderRadius: BorderRadius.circular(18),
          color: Theme.of(context).colorScheme.surface,
          child: SizedBox(width: 228, child: StreamBuilder<PlaybackState>(stream: _audio.playbackState,
            builder: (context, state) => StreamBuilder<MediaItem?>(stream: _audio.mediaItem,
              builder: (context, song) => Padding(padding: const EdgeInsets.all(7),
                child: Row(children: <Widget>[
                  const Icon(Icons.drag_indicator),
                  Expanded(child: Text(song.data?.title ?? 'No song', maxLines: 1, overflow: TextOverflow.ellipsis)),
                  IconButton(tooltip: state.data?.playing == true ? 'Pause' : 'Play',
                    icon: Icon(state.data?.playing == true ? Icons.pause : Icons.play_arrow),
                    onPressed: state.data?.playing == true ? _audio.pause : _audio.play),
                  IconButton(tooltip: 'Next', icon: const Icon(Icons.skip_next), onPressed: _audio.skipToNext),
                ]))))))),
      ),
    ])),
  );
}
