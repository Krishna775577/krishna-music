import 'package:audio_service/audio_service.dart';
import 'package:hive/hive.dart';

/// Local, private artist/track exclusions inspired by Spotube's blacklist.
/// No server requests, account connection or external permissions.
class JotifyBlocklist {
  JotifyBlocklist._();
  static const tracksKey = 'jotifyBlockedTracks';
  static const artistsKey = 'jotifyBlockedArtists';
  static Box get _box => Hive.box('settings');

  static List<Map<String, String>> get blockedTracks {
    final value = _box.get(tracksKey, defaultValue: <dynamic>[]);
    if (value is! List) return [];
    return value.whereType<Map>().map((entry) => <String, String>{
      'id': (entry['id'] ?? '').toString(),
      'title': (entry['title'] ?? '').toString(),
      'artist': (entry['artist'] ?? '').toString(),
    }).where((entry) => entry['id']!.isNotEmpty).toList();
  }

  static List<String> get blockedArtists {
    final value = _box.get(artistsKey, defaultValue: <dynamic>[]);
    if (value is! List) return [];
    return value.map((item) => item.toString()).where((s) => s.trim().isNotEmpty).toList();
  }

  static String _norm(Object? value) =>
      (value ?? '').toString().toLowerCase().trim().replaceAll(RegExp(r'\s+'), ' ');

  static bool isBlockedArtist(Object? raw) {
    final names = _norm(raw).split(RegExp(r'[,;&]')).map((e) => e.trim()).toList();
    final blocked = blockedArtists.map(_norm).toSet();
    return names.any((part) => part.isNotEmpty && blocked.contains(part));
  }

  static bool isBlockedId(Object? raw) =>
      blockedTracks.any((item) => item['id'] == (raw ?? '').toString());

  static bool isBlockedMap(Map item) =>
      isBlockedId(item['id']) || isBlockedArtist(item['artist'] ?? item['subtitle']);

  static bool isBlockedMediaItem(MediaItem item) =>
      isBlockedId(item.id) || isBlockedArtist(item.artist);

  static Future<void> blockTrack(Map item) async {
    final id = (item['id'] ?? '').toString();
    if (id.isEmpty) return;
    final items = blockedTracks..removeWhere((entry) => entry['id'] == id);
    items.add(<String, String>{
      'id': id,
      'title': (item['title'] ?? 'Unknown track').toString(),
      'artist': (item['artist'] ?? '').toString(),
    });
    await _box.put(tracksKey, items);
  }

  static Future<void> unblockTrack(String id) async {
    final items = blockedTracks..removeWhere((item) => item['id'] == id);
    await _box.put(tracksKey, items);
  }

  static Future<void> blockArtist(String artist) async {
    final name = artist.trim();
    if (name.isEmpty) return;
    final items = blockedArtists;
    if (!items.any((entry) => _norm(entry) == _norm(name))) items.add(name);
    await _box.put(artistsKey, items);
  }

  static Future<void> unblockArtist(String artist) async {
    final items = blockedArtists..removeWhere((entry) => _norm(entry) == _norm(artist));
    await _box.put(artistsKey, items);
  }
}
