import 'package:flutter/material.dart';
import 'package:jotify/Features/spotube_parity/blocklist.dart';

/// Manage hidden songs/artists. Blocking affects search and playback queue,
/// but never deletes previously downloaded files or saved playlists.
class JotifyBlocklistPage extends StatefulWidget {
  const JotifyBlocklistPage({super.key});
  @override
  State<JotifyBlocklistPage> createState() => _JotifyBlocklistPageState();
}

class _JotifyBlocklistPageState extends State<JotifyBlocklistPage> {
  final TextEditingController _artist = TextEditingController();
  @override
  void dispose() { _artist.dispose(); super.dispose(); }

  void _feedback(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    final songs = JotifyBlocklist.blockedTracks;
    final artists = JotifyBlocklist.blockedArtists;
    return Scaffold(
      appBar: AppBar(title: const Text('Hidden songs & artists')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        const Text('Hide unwanted songs or artists from new searches, recommendations and queues. Your saved playlists and downloads are not deleted.'),
        const SizedBox(height: 18),
        Text('Hidden artists', style: Theme.of(context).textTheme.titleLarge),
        const SizedBox(height: 8),
        Row(children: [
          Expanded(child: TextField(controller: _artist,
            textInputAction: TextInputAction.done,
            decoration: const InputDecoration(labelText: 'Artist name', border: OutlineInputBorder()),
            onSubmitted: (_) => _addArtist())),
          const SizedBox(width: 8),
          IconButton.filled(onPressed: _addArtist, icon: const Icon(Icons.add),
            tooltip: 'Hide artist'),
        ]),
        if (artists.isEmpty) const Padding(padding: EdgeInsets.all(10), child: Text('No hidden artists')),
        ...artists.map((artist) => ListTile(
          title: Text(artist),
          leading: const Icon(Icons.person_off_outlined),
          trailing: IconButton(tooltip: 'Unhide artist', icon: const Icon(Icons.close),
            onPressed: () async { await JotifyBlocklist.unblockArtist(artist); if (mounted) setState(() {}); }),
        )),
        const Divider(height: 32),
        Text('Hidden tracks (${songs.length})', style: Theme.of(context).textTheme.titleLarge),
        if (songs.isEmpty) const Padding(padding: EdgeInsets.all(10),
          child: Text('No hidden tracks. Use the song ••• menu to hide any track.')),
        ...songs.map((song) => ListTile(
          leading: const Icon(Icons.music_off_outlined),
          title: Text(song['title'] ?? 'Unknown'),
          subtitle: Text(song['artist'] ?? ''),
          trailing: IconButton(tooltip: 'Unhide song', icon: const Icon(Icons.close),
            onPressed: () async { await JotifyBlocklist.unblockTrack(song['id'] ?? ''); if (mounted) setState(() {}); }),
        )),
      ]),
    );
  }

  Future<void> _addArtist() async {
    final name = _artist.text.trim();
    if (name.isEmpty) { _feedback('Enter an artist name first.'); return; }
    await JotifyBlocklist.blockArtist(name);
    _artist.clear();
    if (mounted) { setState(() {}); _feedback('Artist hidden from future playback.'); }
  }
}
