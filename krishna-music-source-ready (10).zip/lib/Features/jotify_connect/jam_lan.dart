import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:audio_service/audio_service.dart';
import 'package:jotify/Helpers/saavn_source_guard.dart';
import 'package:jotify/Features/jotify_connect/lan_discovery.dart';

/// LAN jam: each device plays its own provider URL; NO audio bytes are relayed.
/// Pairing is room-code gated. This is intentionally local-network only.
class JotifyLanJam {
  static final JotifyLanJam instance = JotifyLanJam._();
  JotifyLanJam._();

  HttpServer? _server;
  WebSocket? _client;
  final Set<WebSocket> _guests = {};
  StreamSubscription<MediaItem?>? _mediaSub;
  StreamSubscription<PlaybackState>? _playSub;
  Timer? _heartbeat;
  late AudioHandler _player;
  String roomCode = '';
  String address = '';
  String status = 'Not connected';
  bool get hosting => _server != null;
  bool get joined => _client != null;
  bool allowRemoteControl = false;
  bool allowLocalAudioSharing = false;
  MediaItem? currentRemoteTrack;
  final StreamController<String> _events = StreamController<String>.broadcast();
  Stream<String> get events => _events.stream;
  void _status(String next) { status = next; _events.add(next); }

  Future<void> startHost(AudioHandler player) async {
    await disconnect();
    _player = player;
    roomCode = (100000 + Random.secure().nextInt(900000)).toString();
    _server = await HttpServer.bind(InternetAddress.anyIPv4, 0, shared: false);
    final addresses = await NetworkInterface.list(type: InternetAddressType.IPv4);
    var chosen = '';
    for (final interface in addresses) {
      for (final ip in interface.addresses) {
        if (JotifyLanDiscovery.isPrivateAddress(ip.address) && chosen.isEmpty) chosen = ip.address;
      }
    }
    address = '${chosen.isEmpty ? 'PHONE_IP' : chosen}:${_server!.port}';
    _server!.listen((request) async {
      if (request.uri.path == '/audio' && request.uri.queryParameters['code'] == roomCode) {
        await _serveLocalAudio(request);
        return;
      }
      if (request.uri.path != '/jam' || !WebSocketTransformer.isUpgradeRequest(request)) {
        request.response.statusCode = HttpStatus.badRequest;
        await request.response.close();
        return;
      }
      if (request.uri.queryParameters['code'] != roomCode) {
        request.response.statusCode = HttpStatus.forbidden;
        await request.response.close();
        return;
      }
      final peer = await WebSocketTransformer.upgrade(request);
      _guests.add(peer);
      _sendState(peer);
      peer.listen((message) => _fromGuest(message),
          onDone: () { _guests.remove(peer); _status('Hosting: ${_guests.length} connected'); },
          onError: (_) { _guests.remove(peer); });
      _status('Hosting: ${_guests.length} connected');
    });
    _mediaSub = player.mediaItem.listen((_) { _broadcast(); });
    _playSub = player.playbackState.listen((_) { _broadcast(); });
    _heartbeat = Timer.periodic(const Duration(seconds: 5), (_) => _broadcast());
    if (!address.startsWith('PHONE_IP')) {
      await JotifyLanDiscovery.instance.advertise(_server!.port);
    }
    _status('Hosting at $address (room $roomCode)');
  }

  Future<void> join(AudioHandler player, String host, String code) async {
    await disconnect();
    _player = player;
    final parts = host.trim().split(':');
    if (parts.length != 2 || !JotifyLanDiscovery.isPrivateAddress(parts[0]) ||
        int.tryParse(parts[1]) == null || !RegExp(r'^\d{6}$').hasMatch(code.trim())) {
      throw const FormatException('Enter LAN IP:port and 6-digit room code');
    }
    final uri = Uri(scheme: 'ws', host: parts[0], port: int.parse(parts[1]),
        path: '/jam', queryParameters: {'code': code.trim()});
    _client = await WebSocket.connect(uri.toString()).timeout(const Duration(seconds: 12));
    address = host;
    roomCode = code.trim();
    SaavnSourceGuard.trustLanHost(parts[0], int.parse(parts[1]));
    _client!.listen((message) => _fromHost(message),
      onDone: () { _client = null; SaavnSourceGuard.clearLanHost(); _status('Jam host disconnected'); },
      onError: (_) { _client = null; SaavnSourceGuard.clearLanHost(); _status('Jam connection lost'); });
    _status('Joined Jam $roomCode');
  }

  void _sendState(WebSocket socket) {
    final item = _player.mediaItem.value;
    final state = _player.playbackState.value;
    // Never transmit local-file paths, private playlists, auth credentials or
    // unsupported-source streaming URLs over the local network.
    final online = item != null && SaavnSourceGuard.isSaavnUrl(item.extras?['url']);
    final sharingLocal = !online && item != null && allowLocalAudioSharing &&
        _localFile(item) != null;
    final shareUrl = sharingLocal && !address.startsWith('PHONE_IP')
      ? 'http://$address/audio?code=$roomCode' : null;
    final payload = {
      'kind': 'state',
      'playing': state.playing,
      'positionMs': state.updatePosition.inMilliseconds + (state.playing ? DateTime.now().difference(state.updateTime).inMilliseconds.clamp(0, 10000).toInt() : 0),
      'sentAtMs': DateTime.now().millisecondsSinceEpoch,
      'track': online || shareUrl != null ? {
        'id': item!.id, 'title': item.title, 'artist': item.artist ?? '',
        'album': item.album ?? '', 'durationMs': item.duration?.inMilliseconds ?? 180000,
        'art': online ? item.artUri?.toString() : null,
        'url': online ? item.extras?['url'] : shareUrl,
      } : null,
    };
    try { socket.add(jsonEncode(payload)); } catch (_) { _guests.remove(socket); }
  }

  void _broadcast() { for (final s in _guests.toList()) { _sendState(s); } }

  Future<void> _fromHost(dynamic raw) async {
    if (raw is! String) return;
    try {
      final json = jsonDecode(raw);
      if (json is! Map || json['kind'] != 'state') return;
      final track = json['track'];
      if (track is! Map || !(SaavnSourceGuard.isSaavnUrl(track['url']) || SaavnSourceGuard.isTrustedLanUrl(track['url']))) {
        if (currentRemoteTrack != null) await _player.pause();
        currentRemoteTrack = null;
        _status('Host is playing unsupported/local audio (not shared)');
        return;
      }
      final media = MediaItem(
        id: track['id'].toString(), title: track['title'].toString(),
        artist: track['artist']?.toString(), album: track['album']?.toString(),
        duration: Duration(milliseconds: (track['durationMs'] as num?)?.toInt() ?? 180000),
        artUri: Uri.tryParse(track['art']?.toString() ?? ''),
        extras: {'url': track['url'], 'autoplay': false},
      );
      final different = _player.mediaItem.value?.id != media.id;
      if (different) {
        currentRemoteTrack = media;
        await _player.updateQueue([media]);
        await _player.skipToQueueItem(0);
      }
      final millis = (json['positionMs'] as num?)?.toInt() ?? 0;
      final sent = (json['sentAtMs'] as num?)?.toInt() ?? DateTime.now().millisecondsSinceEpoch;
      final playing = json['playing'] == true;
      final target = millis + (playing ? (DateTime.now().millisecondsSinceEpoch - sent).clamp(0, 3000).toInt() : 0);
      final local = _player.playbackState.value.updatePosition.inMilliseconds;
      if (different || (local - target).abs() > 2500) await _player.seek(Duration(milliseconds: target.clamp(0, media.duration!.inMilliseconds).toInt()));
      if (playing && !_player.playbackState.value.playing) await _player.play();
      if (!playing && _player.playbackState.value.playing) await _player.pause();
      _status('Jam syncing: ${media.title}');
    } catch (e) { _status('Jam sync error: $e'); }
  }

  void _fromGuest(dynamic raw) {
    if (!allowRemoteControl || raw is! String) return;
    try {
      final data = jsonDecode(raw);
      if (data is! Map || data['kind'] != 'command') return;
      switch (data['action']) {
        case 'play': _player.play(); break;
        case 'pause': _player.pause(); break;
        case 'next': _player.skipToNext(); break;
        case 'previous': _player.skipToPrevious(); break;
        case 'seek':
          final ms = data['milliseconds'];
          if (ms is int && ms >= 0 && ms <= 86400000) _player.seek(Duration(milliseconds: ms));
          break;
      }
    } catch (_) { /* Ignore malformed client messages. */ }
  }

  void sendCommand(String action) {
    if (!{'play', 'pause', 'next', 'previous'}.contains(action)) return;
    _client?.add(jsonEncode({'kind': 'command', 'action': action}));
  }

  Future<void> disconnect() async {
    await _mediaSub?.cancel(); _mediaSub = null;
    await _playSub?.cancel(); _playSub = null;
    _heartbeat?.cancel(); _heartbeat = null;
    JotifyLanDiscovery.instance.stopAdvertising();
    for (final s in _guests.toList()) { await s.close(); }
    _guests.clear();
    await _client?.close(); _client = null;
    await _server?.close(force: true); _server = null;
    roomCode = ''; address = ''; currentRemoteTrack = null;
    SaavnSourceGuard.clearLanHost();
    _status('Not connected');
  }

  File? _localFile(MediaItem? item) {
    if (item == null) return null;
    final src = item.extras?['url']?.toString() ?? '';
    if (!SaavnSourceGuard.isLocalUrl(src)) return null;
    final uri = Uri.tryParse(src);
    if (uri != null && uri.scheme == 'content') return null;
    try {
      final file = File(uri?.scheme == 'file' ? uri!.toFilePath() : src);
      return file;
    } catch (_) { return null; }
  }

  Future<void> _serveLocalAudio(HttpRequest request) async {
    final response = request.response;
    if (!allowLocalAudioSharing || !{'GET', 'HEAD'}.contains(request.method)) {
      response.statusCode = HttpStatus.forbidden; await response.close(); return;
    }
    final file = _localFile(_player.mediaItem.value);
    if (file == null || !await file.exists()) {
      response.statusCode = HttpStatus.notFound; await response.close(); return;
    }
    final size = await file.length();
    if (size <= 0) { response.statusCode = HttpStatus.notFound; await response.close(); return; }
    var start = 0;
    var end = size - 1;
    final range = request.headers.value(HttpHeaders.rangeHeader);
    if (range != null) {
      final match = RegExp(r'^bytes=(\d+)-(\d*)$').firstMatch(range);
      if (match == null) {
        response.statusCode = HttpStatus.requestedRangeNotSatisfiable;
        await response.close(); return;
      }
      start = int.parse(match.group(1)!);
      if (match.group(2)!.isNotEmpty) end = int.parse(match.group(2)!);
      if (start >= size || end < start) {
        response.statusCode = HttpStatus.requestedRangeNotSatisfiable;
        await response.close(); return;
      }
      if (end >= size) end = size - 1;
      response.statusCode = HttpStatus.partialContent;
      response.headers.set(HttpHeaders.contentRangeHeader, 'bytes $start-$end/$size');
    }
    response.headers.set(HttpHeaders.acceptRangesHeader, 'bytes');
    final ext = file.path.toLowerCase();
    final mime = ext.endsWith('.m4a') || ext.endsWith('.mp4') ? 'audio/mp4'
        : ext.endsWith('.wav') ? 'audio/wav'
        : ext.endsWith('.flac') ? 'audio/flac'
        : ext.endsWith('.ogg') ? 'audio/ogg'
        : ext.endsWith('.aac') ? 'audio/aac' : 'audio/mpeg';
    response.headers.contentType = ContentType.parse(mime);
    response.contentLength = end - start + 1;
    if (request.method == 'HEAD') { await response.close(); return; }
    // Stream only the currently selected file. Never allow arbitrary paths.
    try { await response.addStream(file.openRead(start, end + 1)); }
    catch (_) { /* Client may disconnect mid stream. */ }
    await response.close();
  }
}
