import 'package:flutter/material.dart';
import 'package:jotify/Features/jotify_connect/provider_adapters.dart';
import 'package:jotify/Screens/Search/search.dart';

/// Metadata provider demonstration and Saavn track fallback, not remote audio.
class JotifyMetadataSearchPage extends StatefulWidget {
  const JotifyMetadataSearchPage({super.key});
  @override
  State<JotifyMetadataSearchPage> createState() => _JotifyMetadataSearchPageState();
}

class _JotifyMetadataSearchPageState extends State<JotifyMetadataSearchPage> {
  final _text = TextEditingController();
  String _provider = 'musicbrainz';
  bool _busy = false;
  String _error = '';
  List<Map<String, dynamic>> _results = [];

  @override
  void dispose() { _text.dispose(); super.dispose(); }
  Future<void> _search() async {
    final term = _text.text.trim();
    if (term.isEmpty || _busy) return;
    setState(() { _busy = true; _error = ''; _results = []; });
    try {
      final results = _provider == 'musicbrainz'
        ? await JotifyMusicBrainzAdapter().search(term)
        : await JotifySaavnSearchAdapter().search(term);
      if (mounted) setState(() => _results = results);
    } catch (error) {
      if (mounted) setState(() => _error = '$error');
    } finally { if (mounted) setState(() => _busy = false); }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Music Metadata Studio')),
    body: Column(children: [
      Padding(padding: const EdgeInsets.all(16), child: Column(children: [
        const Text('Try a public metadata provider or Saavn. MusicBrainz results are song metadata only; tap one to find a playable Saavn version.'),
        const SizedBox(height: 8),
        DropdownButton<String>(value: _provider, isExpanded: true, items: const [
          DropdownMenuItem(value: 'musicbrainz', child: Text('MusicBrainz · metadata')),
          DropdownMenuItem(value: 'saavn', child: Text('JioSaavn · playable results')),
        ], onChanged: _busy ? null : (provider) => setState(() => _provider = provider ?? 'musicbrainz')),
        TextField(controller: _text, textInputAction: TextInputAction.search,
          decoration: const InputDecoration(labelText: 'Song / artist', border: OutlineInputBorder()),
          onSubmitted: (_) => _search()),
        const SizedBox(height: 8),
        FilledButton(onPressed: _busy ? null : _search, child: Text(_busy ? 'Searching...' : 'Search provider')),
        if (_error.isNotEmpty) Text(_error, style: const TextStyle(color: Colors.redAccent)),
      ])),
      Expanded(child: ListView.builder(itemCount: _results.length, itemBuilder: (context, i) {
        final row = _results[i];
        final name = (row['name'] ?? row['title'] ?? '').toString();
        final artist = (row['artist'] ?? '').toString();
        return ListTile(leading: const Icon(Icons.music_note), title: Text(name),
          subtitle: Text(artist), trailing: const Icon(Icons.search),
          onTap: () => Navigator.push(context, MaterialPageRoute<void>(
            builder: (_) => SearchPage(query: '$name $artist'),
          )),
        );
      })),
    ]),
  );
}
