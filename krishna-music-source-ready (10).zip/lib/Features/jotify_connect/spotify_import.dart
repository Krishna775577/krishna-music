import 'dart:async';

import 'package:flutter/material.dart';
import 'package:jotify/APIs/api.dart';
import 'package:jotify/Features/jotify_connect/track_matcher.dart';
import 'package:jotify/Features/spotube_parity/blocklist.dart';
import 'package:jotify/Helpers/playlist.dart';
import 'package:jotify/Helpers/saavn_source_guard.dart';

/// Spotify metadata -> user-confirmed Saavn matches. Does not stream Spotify.
/// A batch is limited to avoid stressing unauthenticated Saavn endpoints.
class JotifySpotifyImportPage extends StatefulWidget {
  const JotifySpotifyImportPage({super.key, required this.name, required this.tracks});
  final String name;
  final List tracks;
  @override
  State<JotifySpotifyImportPage> createState() => _JotifySpotifyImportPageState();
}

class _MatchRow {
  _MatchRow(this.spotify, this.candidates, this.scores, this.selection);
  final Map spotify;
  final List<Map<dynamic, dynamic>> candidates;
  final List<double> scores;
  int? selection;
}

class _JotifySpotifyImportPageState extends State<JotifySpotifyImportPage> {
  final List<_MatchRow> _rows = [];
  bool _busy = false;
  String _status = '';
  int _cursor = 0;
  bool _saved = false;
  int get _selected => _rows.where((r) => r.selection != null).length;

  Future<void> _preview() async {
    if (_busy || _cursor >= widget.tracks.length) return;
    setState(() { _busy = true; _saved = false; _status = 'Looking up Saavn candidates...'; });
    final end = (_cursor + 12).clamp(0, widget.tracks.length).toInt();
    for (var i = _cursor; i < end; i++) {
      final raw = widget.tracks[i];
      if (raw is! Map) { _cursor = i + 1; continue; }
      final track = Map<dynamic, dynamic>.from(raw);
      final title = track['name']?.toString() ?? '';
      final artist = track['artist']?.toString() ?? '';
      final matches = <Map<dynamic, dynamic>>[];
      final scores = <double>[];
      if (title.trim().isNotEmpty) {
        try {
          final search = await SaavnAPI().fetchExpandedSongSearchResults(
            searchQuery: '$title ${artist.split(',').first}', count: 12,
          ).timeout(const Duration(seconds: 16));
          final rawResults = search['songs'];
          if (rawResults is List) {
            final ranked = <MapEntry<double, Map<dynamic, dynamic>>>[];
            for (final possible in rawResults) {
              if (possible is! Map || JotifyBlocklist.isBlockedMap(possible) ||
                  !SaavnSourceGuard.isSaavnUrl(possible['url'])) continue;
              final seconds = int.tryParse(possible['duration']?.toString() ?? '');
              final weight = JotifyTrackMatcher.score(
                title: title, artist: artist,
                candidateTitle: possible['title']?.toString() ?? '',
                candidateArtist: possible['artist']?.toString() ?? '',
                durationMs: int.tryParse(track['durationMs']?.toString() ?? ''),
                candidateDurationSeconds: seconds,
              );
              if (weight >= 0.42) ranked.add(MapEntry(weight, Map<dynamic, dynamic>.from(possible)));
            }
            ranked.sort((a, b) => b.key.compareTo(a.key));
            for (final entry in ranked.take(3)) {
              scores.add(entry.key); matches.add(entry.value);
            }
          }
        } catch (_) { /* One unavailable song shouldn't abort playlist preview. */ }
      }
      final selected = scores.isNotEmpty && scores[0] >= 0.88 ? 0 : null;
      if (!mounted) return;
      setState(() {
        _rows.add(_MatchRow(track, matches, scores, selected));
        _cursor = i + 1;
        _status = 'Checked $_cursor / ${widget.tracks.length} · $_selected selected';
      });
    }
    if (mounted) setState(() { _busy = false; _status = 'Review $_selected selected matches before saving.'; });
  }

  Future<void> _save() async {
    if (_busy || _selected == 0 || _saved) return;
    setState(() { _busy = true; _status = 'Saving confirmed Saavn songs...'; });
    try {
      final songs = <Map>[];
      final seen = <String>{};
      for (final row in _rows) {
        final selection = row.selection;
        if (selection == null || selection >= row.candidates.length) continue;
        final song = Map<dynamic, dynamic>.from(row.candidates[selection]);
        if (SaavnSourceGuard.isSaavnUrl(song['url']) &&
            seen.add(song['id']?.toString() ?? '') && song['id'] != null) {
          songs.add(song);
        }
      }
      if (songs.isEmpty) throw StateError('No valid Saavn songs selected');
      await addPlaylist('Spotify ${widget.name} (Saavn matches)', songs);
      if (mounted) setState(() {
        _saved = true;
        _status = 'Saved ${songs.length} confirmed Saavn tracks as a new Jotify playlist.';
      });
    } catch (error) {
      if (mounted) setState(() => _status = 'Playlist save failed: $error');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Spotify → Saavn matcher')),
    body: Column(children: [
      Padding(padding: const EdgeInsets.all(12), child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const Text('Matches are suggestions, not the original Spotify audio. Review artist, duration and version before importing. Unmatched tracks are skipped.'),
          const SizedBox(height: 8),
          Text('${widget.name} · $_cursor/${widget.tracks.length} checked · $_selected selected'),
          Wrap(spacing: 8, children: [
            FilledButton.tonal(onPressed: _busy || _cursor >= widget.tracks.length ? null : _preview,
              child: Text(_busy ? 'Checking...' : 'Find next 12 matches')),
            FilledButton(onPressed: _busy || _selected == 0 || _saved ? null : _save,
              child: const Text('Save selected as Jotify playlist')),
          ]),
          Text(_status, style: Theme.of(context).textTheme.bodySmall),
        ],
      )),
      Expanded(child: ListView.builder(itemCount: _rows.length, itemBuilder: (context, index) {
        final row = _rows[index];
        final name = row.spotify['name']?.toString() ?? 'Unknown song';
        final artist = row.spotify['artist']?.toString() ?? '';
        return Card(margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 5), child: Padding(
          padding: const EdgeInsets.all(10), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(name, style: const TextStyle(fontWeight: FontWeight.w600)),
            Text('Spotify: $artist', style: Theme.of(context).textTheme.bodySmall),
            if (row.candidates.isEmpty) const Text('No playable Saavn match found'),
            if (row.candidates.isNotEmpty) DropdownButton<int?>(
              value: row.selection, isExpanded: true,
              hint: const Text('Skip / choose a confirmed match'),
              items: [
                const DropdownMenuItem<int?>(value: null, child: Text('Skip / no confirmed match')),
                for (var i = 0; i < row.candidates.length; i++) DropdownMenuItem<int?>(
                  value: i, child: Text(
                    '${(row.scores[i] * 100).round()}% · ${row.candidates[i]['title']} — ${row.candidates[i]['artist']}',
                    maxLines: 1, overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
              onChanged: _saved || _busy ? null : (value) => setState(() { row.selection = value; }),
            ),
          ]),
        ));
      })),
    ]),
  );
}
