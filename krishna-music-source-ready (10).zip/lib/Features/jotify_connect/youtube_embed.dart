import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';

/// YouTube official visible embeds, not extracted/background audio streaming.
/// YouTube Music does not provide a general public in-app music playback API.
class JotifyYouTubePage extends StatefulWidget {
  const JotifyYouTubePage({super.key});
  @override
  State<JotifyYouTubePage> createState() => _JotifyYouTubePageState();
}

class _JotifyYouTubePageState extends State<JotifyYouTubePage> {
  final _input = TextEditingController();
  final _api = TextEditingController();
  final _search = TextEditingController();
  String? _videoId;
  String? _error;
  WebViewController? _controller;
  bool _loading = false;
  bool _musicMode = true;
  List<Map<String, String>> _results = [];

  @override
  void initState() {
    super.initState();
    _api.text = Hive.box('settings').get('j8YouTubeApiKey', defaultValue: '').toString();
  }
  @override
  void dispose() { _input.dispose(); _api.dispose(); _search.dispose(); super.dispose(); }

  static String? parseVideoId(String input) {
    final value = input.trim();
    if (RegExp(r'^[a-zA-Z0-9_-]{11}$').hasMatch(value)) return value;
    final uri = Uri.tryParse(value);
    if (uri == null || uri.scheme != 'https') return null;
    final host = uri.host.toLowerCase();
    String? candidate;
    if (host == 'youtu.be' || host == 'www.youtu.be') {
      candidate = uri.pathSegments.isNotEmpty ? uri.pathSegments.first : null;
    } else if ({'youtube.com', 'www.youtube.com', 'm.youtube.com', 'music.youtube.com'}.contains(host)) {
      if (uri.pathSegments.isNotEmpty && ['shorts', 'embed', 'live'].contains(uri.pathSegments.first)) {
        candidate = uri.pathSegments.length > 1 ? uri.pathSegments[1] : null;
      } else { candidate = uri.queryParameters['v']; }
    }
    return candidate != null && RegExp(r'^[a-zA-Z0-9_-]{11}$').hasMatch(candidate) ? candidate : null;
  }

  Future<void> _openVideo(String text) async {
    final id = parseVideoId(text);
    if (id == null) { setState(() => _error = 'Enter a valid YouTube video URL or 11-character ID'); return; }
    // HTTP Referer must identify the installed application (YouTube API policy).
    const referrer = 'https://com.shadow.blackhole'; // Preserve existing package ID.
    final controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(NavigationDelegate(onWebResourceError: (error) {
        if (mounted && error.isForMainFrame == true) setState(() => _error = error.description);
      }));
    setState(() { _videoId = id; _controller = controller; _error = null; });
    await controller.loadRequest(
      Uri.https('www.youtube.com', '/embed/$id', {
        'playsinline': '1', 'enablejsapi': '1', 'rel': '0',
      }),
      headers: {'Referer': referrer},
    );
  }

  Future<void> _searchYouTube() async {
    final key = _api.text.trim();
    final q = _search.text.trim();
    if (key.isEmpty || q.isEmpty) {
      setState(() => _error = 'Add your YouTube Data API key and a search term'); return;
    }
    await Hive.box('settings').put('j8YouTubeApiKey', key);
    setState(() { _loading = true; _error = null; });
    final http = HttpClient();
    try {
      final uri = Uri.https('www.googleapis.com', '/youtube/v3/search', {
        'part': 'snippet', 'q': q, 'maxResults': '10', 'type': 'video',
        'videoCategoryId': _musicMode ? '10' : '', 'key': key,
      }..removeWhere((k, v) => v.isEmpty));
      final request = await http.getUrl(uri).timeout(const Duration(seconds: 20));
      final response = await request.close().timeout(const Duration(seconds: 20));
      final data = jsonDecode(await utf8.decoder.bind(response).join());
      if (response.statusCode != 200) throw StateError('YouTube API: ${data['error']?['message'] ?? response.statusCode}');
      final result = <Map<String, String>>[];
      for (final raw in data['items'] as List? ?? []) {
        if (raw is! Map) continue;
        final id = (raw['id'] as Map?)?['videoId']?.toString();
        final title = (raw['snippet'] as Map?)?['title']?.toString();
        if (id != null && title != null) result.add({'id': id, 'title': title});
      }
      if (mounted) setState(() => _results = result);
    } catch (e) { if (mounted) setState(() => _error = '$e'); }
    finally { http.close(force: true); if (mounted) setState(() => _loading = false); }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('YouTube · Official Player')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        const Text('Visible YouTube video embeds only. No background audio ripping or downloads. Some videos disable embedding.'),
        const SizedBox(height: 12),
        TextField(controller: _input, decoration: const InputDecoration(labelText: 'YouTube URL / video ID', border: OutlineInputBorder())),
        const SizedBox(height: 8),
        FilledButton.icon(onPressed: () => _openVideo(_input.text), icon: const Icon(Icons.play_arrow), label: const Text('Play inside Jotify')),
        if (_error != null) Padding(padding: const EdgeInsets.all(8), child: Text(_error!, style: const TextStyle(color: Colors.redAccent))),
        if (_controller != null) ...[
          const SizedBox(height: 12),
          AspectRatio(aspectRatio: 16 / 9, child: WebViewWidget(controller: _controller!)),
          TextButton(onPressed: () => launchUrl(Uri.https('www.youtube.com', '/watch', {'v': _videoId}), mode: LaunchMode.externalApplication), child: const Text('Open on YouTube if embed is unavailable')),
        ],
        const Divider(height: 32),
        const Text('Search YouTube Data API', style: TextStyle(fontWeight: FontWeight.bold)),
        const Text('Optional: a Google Cloud YouTube Data API v3 key is required for in-app search.'),
        TextField(controller: _api, decoration: const InputDecoration(labelText: 'YouTube API key')),
        TextField(controller: _search, decoration: const InputDecoration(labelText: 'Search music/videos'), onSubmitted: (_) => _searchYouTube()),
        SwitchListTile(value: _musicMode, onChanged: (value) => setState(() => _musicMode = value), title: const Text('Music video category only')),
        OutlinedButton(onPressed: _loading ? null : _searchYouTube, child: Text(_loading ? 'Searching...' : 'Search videos')),
        for (final item in _results) ListTile(leading: const Icon(Icons.smart_display), title: Text(item['title']!), onTap: () => _openVideo(item['id']!)),
        const Divider(height: 32),
        const Text('YouTube Music does not expose a general-purpose official third-party audio player API. Use the official site for YT Music subscriptions and library.'),
        OutlinedButton(onPressed: () => launchUrl(Uri.https('music.youtube.com', '/'), mode: LaunchMode.externalApplication), child: const Text('Open YouTube Music')),
      ]),
    );
  }
}

/// Pure parser facade for widget tests without starting a WebView.
class JotifyYouTubePageIdParse {
  static String? parse(String value) => _JotifyYouTubePageState.parseVideoId(value);
}
