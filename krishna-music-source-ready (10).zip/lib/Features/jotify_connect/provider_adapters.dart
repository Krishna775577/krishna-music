import 'dart:convert';
import 'dart:io';

import 'package:jotify/APIs/api.dart';
import 'package:jotify/Features/jotify_connect/provider_contracts.dart';
import 'package:jotify/Helpers/lyrics.dart';
import 'package:jotify/Helpers/saavn_source_guard.dart';

/// Built-in, typed Dart adapters. No downloading or executing remote plugins.
class JotifySaavnSearchAdapter implements JotifyTrackSearchProvider<Map<String, dynamic>> {
  @override
  String get providerId => 'saavn';
  @override
  Future<List<Map<String, dynamic>>> search(String query, {int limit = 15}) async {
    if (query.trim().isEmpty) return [];
    final result = await SaavnAPI().fetchExpandedSongSearchResults(
      searchQuery: query.trim(), count: limit.clamp(1, 25).toInt(),
    );
    final songs = result['songs'];
    return songs is List ? songs.whereType<Map>().where((s) =>
      SaavnSourceGuard.isSaavnUrl(s['url'])).map((s) =>
        Map<String, dynamic>.from(s)).take(limit).toList() : [];
  }
}

/// Metadata-only public search. Follows MusicBrainz's 1-request/sec etiquette.
class JotifyMusicBrainzAdapter implements JotifyTrackSearchProvider<Map<String, dynamic>> {
  static DateTime? _lastRequest;
  @override
  String get providerId => 'musicbrainz';

  @override
  Future<List<Map<String, dynamic>>> search(String query, {int limit = 10}) async {
    if (query.trim().isEmpty) return [];
    final last = _lastRequest;
    if (last != null) {
      final remaining = const Duration(milliseconds: 1100) - DateTime.now().difference(last);
      if (remaining > Duration.zero) await Future<void>.delayed(remaining);
    }
    _lastRequest = DateTime.now();
    final uri = Uri.https('musicbrainz.org', '/ws/2/recording/', {
      'query': query.trim(), 'fmt': 'json', 'limit': '${limit.clamp(1, 15)}',
    });
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 12);
    try {
      final request = await client.getUrl(uri).timeout(const Duration(seconds: 12));
      request.headers.set(HttpHeaders.userAgentHeader, 'Jotify/9.0 (https://github.com/Krishna775577)');
      request.headers.set(HttpHeaders.acceptHeader, 'application/json');
      request.followRedirects = false;
      final response = await request.close().timeout(const Duration(seconds: 12));
      if (response.statusCode != 200) throw HttpException('MusicBrainz HTTP ${response.statusCode}');
      final bytes = <int>[];
      await for (final chunk in response.timeout(const Duration(seconds: 12))) {
        bytes.addAll(chunk);
        if (bytes.length > 256 * 1024) throw const FormatException('MusicBrainz response too large');
      }
      final decoded = jsonDecode(utf8.decode(bytes));
      if (decoded is! Map) return [];
      return parseRecordings(decoded);
    } finally { client.close(force: true); }
  }

  /// Pure parser for offline tests. MusicBrainz records have no playable URL.
  static List<Map<String, dynamic>> parseRecordings(Map decoded) {
      if (decoded['recordings'] is! List) return [];
      final recordings = decoded['recordings'] as List;
      final found = <Map<String, dynamic>>[];
      for (final entry in recordings) {
        if (entry is! Map) continue;
        final artists = entry['artist-credit'];
        final names = <String>[];
        if (artists is List) {
          for (final credit in artists) {
            if (credit is Map) {
              final value = credit['name'] ?? (credit['artist'] is Map ? (credit['artist'] as Map)['name'] : null);
              if (value is String && value.isNotEmpty) names.add(value);
            }
          }
        }
        found.add({
          'name': entry['title']?.toString() ?? '',
          'artist': names.join(', '),
          'durationMs': entry['length'],
          'musicbrainzId': entry['id']?.toString() ?? '',
        });
      }
      return found;
  }
}

class JotifyLrclibAdapter implements JotifyLyricsLookupProvider {
  @override
  String get providerId => 'lrclib';
  @override
  Future<String?> getLyrics(String title, String artist) async {
    final data = await Lyrics.getLRCLIBLyrics(title: title, artist: artist);
    final text = data['lyrics']?.trim();
    return text == null || text.isEmpty ? null : text;
  }
}
