import 'dart:math';

/// Conservative, deterministic metadata matcher. It does not access or copy
/// audio from Spotify or YouTube. Users review alternatives before importing.
class JotifyTrackMatcher {
  const JotifyTrackMatcher._();

  static String normalize(String text) => text.toLowerCase()
      .replaceAll(RegExp(r'&'), ' and ')
      .replaceAll(RegExp(r'[^a-z0-9\u0900-\u097f]+'), ' ')
      .replaceAll(RegExp(r'\s+'), ' ').trim();

  static double similarity(String left, String right) {
    final a = normalize(left);
    final b = normalize(right);
    if (a.isEmpty || b.isEmpty) return 0;
    if (a == b) return 1;
    final leftTokens = a.split(' ').toSet();
    final rightTokens = b.split(' ').toSet();
    final intersect = leftTokens.intersection(rightTokens).length;
    final union = leftTokens.union(rightTokens).length;
    final overlap = intersect / max(leftTokens.length, rightTokens.length);
    final jaccard = intersect / union;
    return (0.65 * overlap + 0.35 * jaccard).clamp(0.0, 1.0).toDouble();
  }

  static double score({
    required String title,
    required String artist,
    required String candidateTitle,
    required String candidateArtist,
    int? durationMs,
    int? candidateDurationSeconds,
  }) {
    final name = similarity(title, candidateTitle);
    final performer = similarity(artist.split(',').first, candidateArtist);
    if (name < 0.46) return 0;
    var result = (name * 0.80 + performer * 0.20);
    if (durationMs != null && durationMs > 0 && candidateDurationSeconds != null && candidateDurationSeconds > 0) {
      final delta = (durationMs / 1000 - candidateDurationSeconds).abs();
      if (delta > 25) result *= 0.65;
      else if (delta > 12) result *= 0.82;
    }
    return result.clamp(0.0, 1.0).toDouble();
  }
}
