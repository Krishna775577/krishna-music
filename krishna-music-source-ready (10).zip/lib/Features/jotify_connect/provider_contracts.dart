/// Flutter-native provider contracts inspired by Spotube's typed interfaces.
/// No arbitrary third-party executable plugin code is loaded. Providers are
/// compiled into Jotify; optional manifests are HTTPS external-search links.
enum JotifyProviderCapability {
  metadataSearch,
  accountLibrary,
  audioPlayback,
  videoEmbed,
  lyrics,
  scrobbling,
  externalSearch,
  localSharing,
}

class JotifyProviderInfo {
  const JotifyProviderInfo({
    required this.id, required this.name, required this.capabilities,
    required this.notes,
  });
  final String id;
  final String name;
  final Set<JotifyProviderCapability> capabilities;
  final String notes;
  bool supports(JotifyProviderCapability capability) => capabilities.contains(capability);
}

/// Descriptors reflect capability boundaries, not a guarantee of API uptime.
class JotifyProviderRegistry {
  static const List<JotifyProviderInfo> builtIn = [
    JotifyProviderInfo(id: 'saavn', name: 'JioSaavn', notes: 'Primary online audio source',
      capabilities: {JotifyProviderCapability.metadataSearch, JotifyProviderCapability.audioPlayback, JotifyProviderCapability.lyrics}),
    JotifyProviderInfo(id: 'local', name: 'Local files', notes: 'On-device audio and opt-in paired LAN sharing',
      capabilities: {JotifyProviderCapability.audioPlayback, JotifyProviderCapability.localSharing}),
    JotifyProviderInfo(id: 'spotify', name: 'Spotify', notes: 'Authorized library metadata only; not a Spotify audio player',
      capabilities: {JotifyProviderCapability.accountLibrary, JotifyProviderCapability.metadataSearch}),
    JotifyProviderInfo(id: 'youtube', name: 'YouTube', notes: 'Official visible video embeds only',
      capabilities: {JotifyProviderCapability.videoEmbed}),
    JotifyProviderInfo(id: 'musicbrainz', name: 'MusicBrainz', notes: 'Metadata-only recording discovery, no audio',
      capabilities: {JotifyProviderCapability.metadataSearch}),
    JotifyProviderInfo(id: 'lrclib', name: 'LRCLIB', notes: 'Online synchronized lyrics lookup',
      capabilities: {JotifyProviderCapability.lyrics}),
    JotifyProviderInfo(id: 'lastfm', name: 'Last.fm', notes: 'Authorized play history scrobbling',
      capabilities: {JotifyProviderCapability.scrobbling}),
  ];

  static JotifyProviderInfo? find(String id) {
    for (final p in builtIn) { if (p.id == id) return p; }
    return null;
  }

  static bool mayServeOnlineAudio(String providerId) => providerId == 'saavn';
}

abstract class JotifyTrackSearchProvider<T> {
  String get providerId;
  Future<List<T>> search(String query, {int limit = 15});
}

abstract class JotifyLyricsLookupProvider {
  String get providerId;
  Future<String?> getLyrics(String title, String artist);
}
