import 'dart:convert';
import 'package:hive/hive.dart';
import 'package:url_launcher/url_launcher.dart';

/// Restrictive metadata discovery plugin registry. Manifest-only, no JS eval,
/// executable network code, file access or provider stream extraction.
class JotifyDiscoveryPlugins {
  static const examples = <Map<String, String>>[
    {'id': 'spotify-search', 'name': 'Spotify Discover',
      'url': 'https://open.spotify.com/search/{query}'},
    {'id': 'youtube-search', 'name': 'YouTube Discover',
      'url': 'https://www.youtube.com/results?search_query={query}'},
    {'id': 'lastfm-search', 'name': 'Last.fm Discover',
      'url': 'https://www.last.fm/search?q={query}'},
    {'id': 'musicbrainz-search', 'name': 'MusicBrainz Discover',
      'url': 'https://musicbrainz.org/search?query={query}&type=recording'},
    {'id': 'bandcamp-search', 'name': 'Bandcamp Discover',
      'url': 'https://bandcamp.com/search?q={query}'},
  ];
  static List<Map<String, String>> get installed {
    final raw = Hive.box('settings').get('j8DiscoveryPlugins', defaultValue: <String>[]);
    if (raw is! List) return [];
    return raw.whereType<String>().map((x) {
      try { return Map<String, String>.from(jsonDecode(x) as Map); }
      catch (_) { return <String, String>{}; }
    }).where((m) => m.isNotEmpty).toList();
  }

  static Future<void> install(String jsonText, {bool allowExternalLinks = false}) async {
    if (!allowExternalLinks) throw StateError('External link permission must be granted before installing a discovery plugin');
    final manifest = jsonDecode(jsonText);
    if (manifest is! Map) throw const FormatException('Expected a JSON object');
    final id = manifest['id']?.toString() ?? '';
    final name = manifest['name']?.toString() ?? '';
    final url = manifest['url']?.toString() ?? '';
    final test = Uri.tryParse(url.replaceAll('{query}', 'test'));
    if (!RegExp(r'^[a-z0-9-]{3,40}$').hasMatch(id) || name.isEmpty || name.length > 50 ||
        !url.contains('{query}') || test == null || test.scheme != 'https' || test.host.isEmpty ||
        url.contains('@') || url.length > 1000 || test.userInfo.isNotEmpty ||
        test.host == 'localhost' || test.host.endsWith('.local') ||
        RegExp(r'^\d+\.\d+\.\d+\.\d+$').hasMatch(test.host)) {
      throw const FormatException('Invalid discovery plugin. Must use an HTTPS search URL with {query}');
    }
    final all = installed.where((x) => x['id'] != id).toList();
    all.add({'id': id, 'name': name, 'url': url, 'permission': 'external_search'});
    await Hive.box('settings').put('j8DiscoveryPlugins', all.map(jsonEncode).toList());
  }

  static Future<void> uninstall(String id) async {
    await Hive.box('settings').put('j8DiscoveryPlugins',
        installed.where((p) => p['id'] != id).map(jsonEncode).toList());
  }

  static Future<bool> search(String id, String query) async {
    final results = installed.where((p) => p['id'] == id);
    if (results.isEmpty || query.trim().isEmpty) return false;
    final manifest = results.first;
    if (manifest['permission'] != 'external_search') {
      throw StateError('This older plugin has no permission grant. Reinstall it to approve external search links.');
    }
    final url = manifest['url']!.replaceAll('{query}', Uri.encodeComponent(query.trim()));
    return launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
  }
}
