import 'dart:async';
import 'dart:convert';
import 'dart:io';

/// Nearby Jotify Jam discovery using opt-in UDP LAN announcements.
/// No room code or music URL is broadcast: joining still requires pairing.
/// This is a lightweight, dependency-free alternative to Spotube's DNS-SD,
/// NOT a wire-compatible implementation of Spotube's protocol.
class NearbyJamRoom {
  const NearbyJamRoom(this.address, this.label, this.lastSeen);
  final String address;
  final String label;
  final DateTime lastSeen;
}

class JotifyLanDiscovery {
  JotifyLanDiscovery._();
  static final JotifyLanDiscovery instance = JotifyLanDiscovery._();
  static const int discoveryPort = 41479;
  static const Duration staleAfter = Duration(seconds: 12);
  final Map<String, NearbyJamRoom> _rooms = {};
  final StreamController<void> _events = StreamController<void>.broadcast();
  Stream<void> get changes => _events.stream;
  RawDatagramSocket? _socket;
  StreamSubscription<RawSocketEvent>? _sub;
  Timer? _advertise;
  Timer? _reap;
  int? _hostPort;
  String lastError = '';
  bool get active => _socket != null;

  List<NearbyJamRoom> get rooms {
    final result = _rooms.values.toList()
      ..sort((a, b) => b.lastSeen.compareTo(a.lastSeen));
    return result;
  }

  static bool isPrivateAddress(String host) {
    final address = InternetAddress.tryParse(host);
    if (address == null || address.type != InternetAddressType.IPv4) return false;
    final parts = host.split('.').map(int.tryParse).toList();
    if (parts.length != 4 || parts.any((part) => part == null)) return false;
    final a = parts[0]!;
    final b = parts[1]!;
    return a == 10 || (a == 172 && b >= 16 && b <= 31) ||
        (a == 192 && b == 168) || (a == 169 && b == 254);
  }

  Future<void> start() async {
    if (_socket != null) return;
    try {
      final socket = await RawDatagramSocket.bind(
        InternetAddress.anyIPv4, discoveryPort, reuseAddress: true,
      );
      socket.broadcastEnabled = true;
      _socket = socket;
      _sub = socket.listen((event) {
        if (event != RawSocketEvent.read) return;
        Datagram? datagram;
        while ((datagram = socket.receive()) != null) {
          final packet = datagram!;
          if (!isPrivateAddress(packet.address.address) || packet.data.length > 512) continue;
          try {
            final data = jsonDecode(utf8.decode(packet.data));
            if (data is! Map || data['app'] != 'jotify' || data['type'] != 'jam-beacon' || data['version'] != 1) continue;
            final port = data['port'];
            if (port is! int || port < 1024 || port > 65535) continue;
            final address = '${packet.address.address}:$port';
            final label = data['label']?.toString() ?? 'Jotify Jam';
            _rooms[address] = NearbyJamRoom(address,
                label.length > 36 ? label.substring(0, 36) : label,
                DateTime.now());
            _events.add(null);
          } on FormatException { /* Ignore unrelated broadcast traffic. */ }
            catch (_) { /* Ignore malformed / untrusted packets. */ }
        }
      }, onError: (Object error) {
        lastError = 'LAN discovery unavailable: $error';
        _events.add(null);
      });
      _reap = Timer.periodic(const Duration(seconds: 4), (_) {
        final now = DateTime.now();
        _rooms.removeWhere((_, room) => now.difference(room.lastSeen) > staleAfter);
        _events.add(null);
      });
      lastError = '';
    } on SocketException catch (error) {
      lastError = 'LAN discovery permission/network error: $error';
      _events.add(null);
    }
  }

  Future<void> advertise(int hostPort) async {
    if (hostPort < 1024 || hostPort > 65535) return;
    await start();
    _hostPort = hostPort;
    _advertise?.cancel();
    _sendBeacon();
    _advertise = Timer.periodic(const Duration(seconds: 3), (_) => _sendBeacon());
  }

  void _sendBeacon() {
    final socket = _socket;
    final port = _hostPort;
    if (socket == null || port == null) return;
    final bytes = utf8.encode(jsonEncode({
      'app': 'jotify', 'version': 1, 'type': 'jam-beacon',
      'label': 'Jotify Jam', 'port': port,
    }));
    try { socket.send(bytes, InternetAddress('255.255.255.255'), discoveryPort); }
    catch (_) { /* Broadcasting may be disabled by the Wi-Fi router. */ }
  }

  void stopAdvertising() {
    _hostPort = null;
    _advertise?.cancel();
    _advertise = null;
  }

  Future<void> stop() async {
    stopAdvertising();
    _reap?.cancel(); _reap = null;
    await _sub?.cancel(); _sub = null;
    _socket?.close(); _socket = null;
    _rooms.clear();
    _events.add(null);
  }
}
