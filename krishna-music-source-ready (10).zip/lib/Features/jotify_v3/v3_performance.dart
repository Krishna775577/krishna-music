import 'package:flutter/material.dart';
import 'package:hive/hive.dart';

class V3Performance {
  const V3Performance._();
  static bool get enabled => Hive.isBoxOpen('settings') &&
      Hive.box('settings').get('v3PerformanceMode', defaultValue: false) == true;
  static bool get reduceMotion => Hive.isBoxOpen('settings') &&
      Hive.box('settings').get('v3ReduceMotion', defaultValue: false) == true;
  static bool get lowDataArtwork => Hive.isBoxOpen('settings') &&
      Hive.box('settings').get('useLessDataImage', defaultValue: false) == true;
  static Duration animation(Duration normal) => reduceMotion
      ? Duration.zero
      : enabled ? const Duration(milliseconds: 90) : normal;
}

class JotifyV3Performance extends StatefulWidget {
  const JotifyV3Performance({super.key});

  @override
  State<JotifyV3Performance> createState() => _JotifyV3PerformanceState();
}

class _JotifyV3PerformanceState extends State<JotifyV3Performance> {
  Future<void> _save(String key, bool value) async {
    await Hive.box('settings').put(key, value);
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final settings = Hive.box('settings');
    return Scaffold(
      appBar: AppBar(title: const Text('Jotify Performance Mode')),
      body: ListView(padding: const EdgeInsets.all(16), children: <Widget>[
        const ListTile(
          leading: Icon(Icons.bolt_rounded),
          title: Text('Smoothness & battery'),
          subtitle: Text('These controls are device-side preferences; they do not speed up your network or unblock video streams.'),
        ),
        SwitchListTile.adaptive(
          title: const Text('Performance Mode'),
          subtitle: const Text('Shorter navigation transitions and fewer decorative player animations.'),
          value: V3Performance.enabled,
          onChanged: (value) => _save('v3PerformanceMode', value),
        ),
        SwitchListTile.adaptive(
          title: const Text('Reduce Motion'),
          subtitle: const Text('Turn off V2 visualizer movement and bottom tab transitions.'),
          value: V3Performance.reduceMotion,
          onChanged: (value) => _save('v3ReduceMotion', value),
        ),
        SwitchListTile.adaptive(
          title: const Text('Lower-data artwork'),
          subtitle: const Text('Use the existing low-data artwork mode where supported.'),
          value: V3Performance.lowDataArtwork,
          onChanged: (value) => _save('useLessDataImage', value),
        ),
        SwitchListTile.adaptive(
          title: const Text('Compact mini-player'),
          subtitle: const Text('Reduce mini-player spacing on smaller phones.'),
          value: settings.get('useDenseMini', defaultValue: false) == true,
          onChanged: (value) => _save('useDenseMini', value),
        ),
        const Padding(
          padding: EdgeInsets.all(18),
          child: Text('For accurate FPS measurement, test a Flutter profile/release APK on your phone. Debug builds can appear less smooth.'),
        ),
      ]),
    );
  }
}
