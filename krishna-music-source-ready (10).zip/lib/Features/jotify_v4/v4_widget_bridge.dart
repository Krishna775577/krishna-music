import 'dart:async';
import 'dart:io';

import 'package:audio_service/audio_service.dart';
import 'package:flutter/services.dart';
import 'package:get_it/get_it.dart';
import 'package:jotify/Screens/Player/audioplayer.dart';

/// Broadcasts title/artist to our Android home widget. No user data leaves device.
class JotifyWidgetBridge {
  JotifyWidgetBridge._();
  static const MethodChannel _channel = MethodChannel('jotify/home_widget');
  static StreamSubscription<MediaItem?>? _subscription;

  static void start() {
    if (!Platform.isAndroid || _subscription != null) return;
    final audio = GetIt.I<AudioPlayerHandler>();
    _subscription = audio.mediaItem.listen((item) {
      _channel.invokeMethod<void>('update', <String, String>{
        'title': item?.title ?? 'Jotify',
        'artist': item?.artist ?? 'Open Jotify to listen',
      }).catchError((Object _) {});
    });
  }
}
