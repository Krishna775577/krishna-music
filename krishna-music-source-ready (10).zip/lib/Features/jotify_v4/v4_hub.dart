import 'dart:math';

import 'package:audio_service/audio_service.dart';
import 'package:flutter/material.dart';
import 'package:get_it/get_it.dart';
import 'package:hive/hive.dart';
import 'package:jotify/Features/jotify_v2/v2_hub.dart';
import 'package:jotify/Features/jotify_v2/v2_library.dart';
import 'package:jotify/Features/jotify_v4/v4_player.dart';
import 'package:jotify/Features/jotify_v4/v4_share.dart';
import 'package:jotify/Screens/LocalMusic/downed_songs.dart';
import 'package:jotify/Screens/Player/audioplayer.dart';
import 'package:jotify/Screens/Settings/backup_and_restore.dart';
import 'package:jotify/Services/player_service.dart';

class JotifyV4Hub extends StatefulWidget {
  const JotifyV4Hub({super.key});
  @override
  State<JotifyV4Hub> createState() => _JotifyV4HubState();
}

class _JotifyV4HubState extends State<JotifyV4Hub> {
  Box get settings => Hive.box('settings');
  final AudioPlayerHandler _audio = GetIt.I<AudioPlayerHandler>();
  bool _mixBusy = false;

  void _open(Widget page) {
    Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => page));
  }

  void _show(String message) {
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> _toggle(String key, bool value) async {
    await settings.put(key, value);
    if (mounted) setState(() {});
  }

  Future<void> _dailyMix({required bool save}) async {
    if (_mixBusy) return;
    final library = V2Library.unique(<Map<String, dynamic>>[
      ...V2Library.favorites, ...V2Library.recent,
    ]);
    if (library.isEmpty) {
      _show('Add favourite songs or listen to a few tracks first.');
      return;
    }
    setState(() => _mixBusy = true);
    try {
      final now = DateTime.now();
      final random = Random(now.year * 1000 + now.month * 32 + now.day);
      final songs = List<Map<String, dynamic>>.from(library)..shuffle(random);
      final picked = songs.take(30).toList();
      if (save) {
        final name = await V2Library.saveAutoMix(
            'Daily ${now.year}-${now.month}-${now.day}', picked);
        _show('Saved $name (${picked.length} tracks)');
      } else {
        await PlayerInvoke.init(songsList: picked, index: 0);
      }
    } catch (error) {
      _show('Daily Mix failed: $error');
    } finally {
      if (mounted) setState(() => _mixBusy = false);
    }
  }

  Widget _group(String title, IconData icon, String detail, List<Widget> children) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 7),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(19)),
      child: Padding(padding: const EdgeInsets.all(15), child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(children: <Widget>[
            Icon(icon, color: Theme.of(context).colorScheme.secondary),
            const SizedBox(width: 9),
            Expanded(child: Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800))),
          ]),
          const SizedBox(height: 5),
          Text(detail, style: Theme.of(context).textTheme.bodySmall),
          const SizedBox(height: 10),
          ...children,
        ],
      )),
    );
  }

  Widget _button(String text, Widget target, IconData icon) =>
      OutlinedButton.icon(onPressed: () => _open(target), icon: Icon(icon, size: 18), label: Text(text));

  @override
  Widget build(BuildContext context) {
    final fade = (settings.get('v4FadeOnSkipMs', defaultValue: 0) as num).toInt();
    final fadeLabel = fade == 0 ? 'Off' : '$fade ms';
    final now = DateTime.now();
    return Scaffold(
      appBar: AppBar(title: const Text('Jotify V4 Experience')),
      body: ListView(padding: const EdgeInsets.fromLTRB(14, 12, 14, 35), children: <Widget>[
        Container(
          padding: const EdgeInsets.all(23),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(23),
            gradient: LinearGradient(colors: [
              Theme.of(context).colorScheme.secondary.withOpacity(.35),
              Theme.of(context).cardColor,
            ]),
          ),
          child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: <Widget>[
            Text('YOUR MUSIC, EVOLVED', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
            SizedBox(height: 8),
            Text('Private listening, personal mixes, album-inspired visuals and practical playback tools.'),
          ]),
        ),
        const SizedBox(height: 8),
        _group('1. Dynamic Ambient Player', Icons.blur_on_rounded,
          'Artwork-based gradients. Reuses Jotify audio playback and V3 reduced-motion preferences.', [
            _button('Open ambient player', const JotifyAmbientPlayer(), Icons.play_circle),
          ]),
        _group('2. Gapless playback & fades', Icons.all_inclusive_rounded,
          'Existing just_audio concatenated queue supports gapless audio where the source/OS allows. Manual skip fades are not true overlapping crossfade.', [
            Text('Manual next-track fade: $fadeLabel'),
            Wrap(spacing: 6, children: <Widget>[
              for (final ms in <int>[0, 300, 600])
                ChoiceChip(label: Text(ms == 0 ? 'Off' : '${ms}ms'),
                  selected: fade == ms,
                  onSelected: (_) async {
                    await settings.put('v4FadeOnSkipMs', ms);
                    if (mounted) setState(() {});
                  }),
            ]),
            const Text('True overlap crossfade needs dual-player engine and source compatibility testing.',
                style: TextStyle(fontSize: 12)),
          ]),
        _group('3. Home Screen Widget', Icons.widgets_rounded,
          'Android: add Jotify from your launcher widget picker. Shows the current song and forwards play/pause/next/previous media buttons.', [
            const Text('Widget controls require the Jotify audio service to be running. Some Android launchers restrict background media actions.'),
          ]),
        _group('4. Music Story Maker', Icons.auto_stories_rounded,
          'Share a beautiful PNG of the current track.', [
            _button('Create a story', const JotifyShareStudio(), Icons.ios_share_rounded),
          ]),
        _group('5. Offline Music Manager', Icons.offline_pin_rounded,
          'Opens the existing on-device music browser. No DRM bypasses or unsupported source downloads.', [
            _button('Browse local music', const DownloadedSongs(), Icons.folder_rounded),
          ]),
        _group('6. Smart Resume', Icons.restore_rounded,
          'Restore your last audio queue and playback position after reopening Jotify.', [
            SwitchListTile.adaptive(contentPadding: EdgeInsets.zero,
              title: const Text('Restore last listening session'),
              subtitle: const Text('Uses existing saved queue; does not auto-resume protected video streams.'),
              value: settings.get('loadStart', defaultValue: true) == true,
              onChanged: (value) => _toggle('loadStart', value)),
          ]),
        _group('7. Private Listening Mode', Icons.shield_outlined,
          'While enabled, newly played songs are not added to recent songs or listening statistics. Existing history is not deleted.', [
            SwitchListTile.adaptive(contentPadding: EdgeInsets.zero,
              title: const Text('Private listening'),
              value: settings.get('v4PrivateListening', defaultValue: false) == true,
              onChanged: (value) => _toggle('v4PrivateListening', value)),
            const Text('Search history and files downloaded separately are unaffected.', style: TextStyle(fontSize: 12)),
          ]),
        _group('8. Playlist QR Sharing', Icons.qr_code_2_rounded,
          'Share a scannable image containing playlist track names. No account or cloud link needed.', [
            _button('Choose playlist & create QR', const JotifyShareStudio(), Icons.qr_code),
          ]),
        _group('9. Driving Mode', Icons.directions_car_filled_rounded,
          'Large, simple playback controls. Never interact with your phone while driving.', [
            _button('Open Driving Mode', const JotifyDrivingMode(), Icons.open_in_full_rounded),
          ]),
        _group('10. Bluetooth & Headset Controls', Icons.bluetooth_audio_rounded,
          'Reuses the current Android AudioService media session and headphone/notification transport actions.', [
            const Text('Use your paired headset controls. Hardware key behavior can vary with device and Android version.'),
          ]),
        _group('11. Backup & Restore', Icons.backup_rounded,
          'Open the original backup utility for settings, playlists and downloads database.', [
            _button('Backup / Restore', const BackupAndRestorePage(), Icons.settings_backup_restore_rounded),
          ]),
        _group('12. Jotify Daily Mix', Icons.auto_awesome_rounded,
          'Shuffles your own favourites/recent songs deterministically for ${now.day}/${now.month}/${now.year}. No fake AI or external tokens.', [
            Wrap(spacing: 8, children: <Widget>[
              FilledButton.icon(onPressed: _mixBusy ? null : () => _dailyMix(save: false),
                icon: const Icon(Icons.play_arrow_rounded), label: const Text('Play today\'s mix')),
              OutlinedButton.icon(onPressed: _mixBusy ? null : () => _dailyMix(save: true),
                icon: const Icon(Icons.playlist_add), label: const Text('Save mix')),
            ]),
          ]),
        _group('Lyrics Studio — V4 Fix', Icons.lyrics_rounded,
          'LRCLIB first, corrected JioSaavn URL, bounded fallback and offline cache for successful lyrics.', [
            SwitchListTile.adaptive(contentPadding: EdgeInsets.zero,
              title: const Text('Enable online lyrics for local tracks'),
              value: settings.get('getLyricsOnline', defaultValue: true) == true,
              onChanged: (value) => _toggle('getLyricsOnline', value)),
            _button('Open Lyrics Studio', const JotifyLyricsStudio(), Icons.music_note_outlined),
          ]),
        const Padding(padding: EdgeInsets.all(14), child: Text(
          'Core Saavn player remains available except for playback history privacy and optional fades on manual next. Test all features on your own phone before replacing a working APK.',
          textAlign: TextAlign.center,
        )),
      ]),
    );
  }
}

class JotifyDrivingMode extends StatelessWidget {
  const JotifyDrivingMode({super.key});
  @override
  Widget build(BuildContext context) {
    final audio = GetIt.I<AudioPlayerHandler>();
    return Scaffold(
      appBar: AppBar(title: const Text('Jotify Driving Mode')),
      body: SafeArea(child: Padding(padding: const EdgeInsets.all(24),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: <Widget>[
          const Icon(Icons.directions_car_filled_rounded, size: 44),
          const SizedBox(height: 14),
          StreamBuilder<MediaItem?>(stream: audio.mediaItem,
            builder: (context, snapshot) => Column(children: <Widget>[
              Text(snapshot.data?.title ?? 'Nothing playing', maxLines: 2,
                overflow: TextOverflow.ellipsis, textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              Text(snapshot.data?.artist ?? '', textAlign: TextAlign.center),
            ])),
          const SizedBox(height: 35),
          StreamBuilder<PlaybackState>(stream: audio.playbackState,
            builder: (context, snap) {
              final playing = snap.data?.playing ?? false;
              return Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: <Widget>[
                IconButton(tooltip: 'Previous', onPressed: audio.skipToPrevious,
                  icon: const Icon(Icons.skip_previous_rounded, size: 57)),
                IconButton(tooltip: playing ? 'Pause' : 'Play',
                  onPressed: playing ? audio.pause : audio.play,
                  icon: Icon(playing ? Icons.pause_circle_filled_rounded : Icons.play_circle_fill_rounded,
                    size: 82)),
                IconButton(tooltip: 'Next', onPressed: audio.skipToNext,
                  icon: const Icon(Icons.skip_next_rounded, size: 57)),
              ]);
            }),
          const SizedBox(height: 32),
          const Text('Set up before driving. Do not operate your phone while driving.',
            textAlign: TextAlign.center),
        ]))),
    );
  }
}
