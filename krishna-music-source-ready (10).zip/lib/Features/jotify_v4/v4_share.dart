import 'dart:convert';
import 'dart:io';
import 'dart:ui' as ui;

import 'package:audio_service/audio_service.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:get_it/get_it.dart';
import 'package:hive/hive.dart';
import 'package:jotify/Screens/Player/audioplayer.dart';
import 'package:path_provider/path_provider.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:share_plus/share_plus.dart';

/// Export self-contained song story PNGs and standard QR/text playlist cards.
/// Does not suggest a public URL or a cloud playlist backend exists.
class JotifyShareStudio extends StatefulWidget {
  const JotifyShareStudio({super.key});
  @override
  State<JotifyShareStudio> createState() => _JotifyShareStudioState();
}

class _JotifyShareStudioState extends State<JotifyShareStudio> {
  final AudioPlayerHandler _audio = GetIt.I<AudioPlayerHandler>();
  final GlobalKey _storyKey = GlobalKey();
  final GlobalKey _qrKey = GlobalKey();
  bool _busy = false;
  String? _playlistName;
  String _qrText = '';

  List<String> get _playlistNames {
    final raw = Hive.box('settings').get('playlistNames', defaultValue: <String>['Favorite Songs']);
    return raw is List ? raw.map((e) => e.toString()).toSet().toList() : <String>['Favorite Songs'];
  }

  Future<void> _prepareQR(String name) async {
    setState(() => _playlistName = name);
    try {
      final box = Hive.isBoxOpen(name) ? Hive.box(name) : await Hive.openBox(name);
      final tracks = box.values.whereType<Map>().take(15).toList();
      // A standard QR reader will show readable song information; no invented
      // playlist hosting or import endpoint. Keep data small enough for a QR.
      final lines = tracks.map((m) => '${m['title'] ?? 'Song'} — ${m['artist'] ?? 'Artist'}').toList();
      final message = 'Jotify playlist: $name\n${lines.join('\n')}';
      final buffer = StringBuffer();
      for (final character in message.runes) {
        final next = String.fromCharCode(character);
        if (utf8.encode(buffer.toString() + next).length > 650) break;
        buffer.write(next);
      }
      if (!mounted) return;
      setState(() => _qrText = buffer.toString());
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Playlist read failed: $error')));
    }
  }

  Future<void> _export(GlobalKey key, String fileName, String text) async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      // RepaintBoundary uses rendered Flutter content; no external image API.
      final boundary = key.currentContext?.findRenderObject() as RenderRepaintBoundary?;
      if (boundary == null) throw StateError('Preview is not ready');
      final image = await boundary.toImage(pixelRatio: 2.5);
      final bytes = await image.toByteData(format: ui.ImageByteFormat.png);
      image.dispose();
      if (bytes == null) throw StateError('Could not encode PNG');
      final dir = await getTemporaryDirectory();
      final file = File('${dir.path}/$fileName');
      await file.writeAsBytes(bytes.buffer.asUint8List(), flush: true);
      await Share.shareXFiles([XFile(file.path)], text: text);
    } catch (error) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Sharing failed: $error')));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final names = _playlistNames;
    final accent = Theme.of(context).colorScheme.secondary;
    return Scaffold(
      appBar: AppBar(title: const Text('Jotify Story & Playlist QR')),
      body: ListView(padding: const EdgeInsets.all(18), children: <Widget>[
        const Text('Music Story Maker', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        StreamBuilder<MediaItem?>(stream: _audio.mediaItem, builder: (context, snap) {
          final track = snap.data;
          if (track == null) return const ListTile(title: Text('Play a song first'));
          return Column(children: <Widget>[
            RepaintBoundary(key: _storyKey, child: Container(
              width: 300, height: 340,
              decoration: BoxDecoration(
                gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight,
                  colors: [accent, Colors.deepPurple.shade900, Colors.black]),
                borderRadius: BorderRadius.circular(26),
              ),
              child: Padding(padding: const EdgeInsets.all(23), child: Column(
                mainAxisAlignment: MainAxisAlignment.center, children: <Widget>[
                  const Icon(Icons.graphic_eq_rounded, size: 65, color: Colors.white),
                  const Spacer(),
                  Text(track.title, textAlign: TextAlign.center, maxLines: 3, overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w900, color: Colors.white)),
                  const SizedBox(height: 8),
                  Text(track.artist ?? '', textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 16, color: Colors.white70)),
                  const Spacer(),
                  const Text('LISTENING ON JOTIFY', style: TextStyle(letterSpacing: 2,
                    color: Colors.white70, fontWeight: FontWeight.bold)),
                ])),
            )),
            const SizedBox(height: 12),
            FilledButton.icon(onPressed: _busy ? null : () => _export(_storyKey, 'jotify_story.png',
              'Listening to ${track.title} on Jotify'),
              icon: const Icon(Icons.ios_share_rounded), label: const Text('Share story as PNG')),
          ]);
        }),
        const Divider(height: 45),
        const Text('Playlist QR Sharing', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
        const Text('QR contains track names for standard QR readers. It is not a cloud playlist link.',
          style: TextStyle(fontSize: 12)),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(
          value: names.contains(_playlistName) ? _playlistName : null,
          hint: const Text('Choose a playlist'),
          items: names.map((n) => DropdownMenuItem(value: n, child: Text(n))).toList(),
          onChanged: (value) { if (value != null) _prepareQR(value); },
        ),
        if (_qrText.isNotEmpty) ...<Widget>[
          const SizedBox(height: 14),
          Center(child: RepaintBoundary(key: _qrKey, child: Container(
            color: Colors.white, padding: const EdgeInsets.all(12),
            child: QrImageView(data: _qrText, version: QrVersions.auto,
              size: 252, backgroundColor: Colors.white),
          ))),
          const SizedBox(height: 8),
          FilledButton.icon(onPressed: _busy ? null : () => _export(_qrKey,
            'jotify_playlist_qr.png', _qrText),
            icon: const Icon(Icons.qr_code_2), label: const Text('Share QR image')),
          OutlinedButton.icon(onPressed: () => Share.share(_qrText),
            icon: const Icon(Icons.share), label: const Text('Share playlist as text')),
        ],
        const SizedBox(height: 24),
      ]),
    );
  }
}
