import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:jotify/Features/jotify_connect/connect_hub.dart';
import 'package:jotify/Features/jotify_connect/jam_lan.dart';
import 'package:jotify/Features/jotify_connect/lastfm_scrobble.dart';
import 'package:jotify/Features/jotify_connect/provider_contracts.dart';
import 'package:jotify/Features/jotify_connect/spotify_auth.dart';
import 'package:jotify/Features/jotify_v2/v2_hub.dart';
import 'package:jotify/Features/jotify_v3/v3_hub.dart';
import 'package:jotify/Features/jotify_v4/v4_hub.dart';
import 'package:jotify/Features/jotify_v5/v5_hub.dart';
import 'package:jotify/Features/spotube_parity/blocklist_page.dart';

/// The user-facing route that proves which build is INSTALLED, not which ZIP
/// has been uploaded. Also exposes previously buried feature hubs.
class JotifyReleaseCenter extends StatefulWidget {
  const JotifyReleaseCenter({super.key});

  @override
  State<JotifyReleaseCenter> createState() => _JotifyReleaseCenterState();
}

class _JotifyReleaseCenterState extends State<JotifyReleaseCenter> {
  String _installed = 'Checking installed APK…';
  bool _spotifyConnected = false;
  bool _lastFmConnected = false;
  String _error = '';

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    try {
      final info = await PackageInfo.fromPlatform();
      final spotify = await JotifySpotify.hasStoredSession();
      final lastFm = await JotifyLastFm.hasStoredSession();
      if (!mounted) return;
      setState(() {
        _installed = '${info.appName} ${info.version} (build ${info.buildNumber})';
        _spotifyConnected = spotify;
        _lastFmConnected = lastFm;
        _error = '';
      });
    } catch (error) {
      if (!mounted) return;
      setState(() => _error = 'Version check unavailable: $error');
    }
  }

  void _open(Widget page) {
    Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => page));
  }

  Widget _feature(String title, String detail, IconData icon, Widget page) {
    return ListTile(
      leading: Icon(icon),
      title: Text(title),
      subtitle: Text(detail),
      trailing: const Icon(Icons.chevron_right),
      onTap: () => _open(page),
    );
  }

  @override
  Widget build(BuildContext context) {
    final settings = Hive.box('settings');
    final jam = JotifyLanJam.instance;
    final spotifyConfigured = JotifySpotify.clientId.isNotEmpty;
    final lastFmConfigured = JotifyLastFm.apiKey.isNotEmpty;
    final spotifyCache = settings.get('j8SpotifySnapshot');
    final hasSpotifyCache = spotifyCache is Map && spotifyCache.isNotEmpty;
    return Scaffold(
      appBar: AppBar(title: const Text('Jotify V10 · All Features')),
      body: ListView(padding: const EdgeInsets.fromLTRB(14, 12, 14, 30), children: [
        Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('INSTALLED APP', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 7),
            Text(_installed, style: Theme.of(context).textTheme.titleMedium),
            const Text('Expected source: Jotify 10.0.1 · build 71'),
            if (_error.isNotEmpty) Text(_error),
            const SizedBox(height: 6),
            OutlinedButton.icon(onPressed: _refresh,
              icon: const Icon(Icons.refresh), label: const Text('Check installed version')),
            const Text('If the installed version is older, GitHub did not build this source or the new APK was not installed.'),
          ],
        ))),
        const SizedBox(height: 12),
        Text('MUSIC AND LIBRARY', style: Theme.of(context).textTheme.titleSmall),
        const ListTile(leading: Icon(Icons.music_note), title: Text('JioSaavn audio + local files'),
          subtitle: Text('Saavn is the primary online audio provider. Search, queue, favourites, offline downloads and local playback stay in the main app.')),
        _feature('V2 Studio', 'Themes, smart mixes, lyrics, sleep timer, gestures',
          Icons.library_music, const JotifyV2Hub()),
        _feature('V3 Studio', 'Smart search, queue and performance controls',
          Icons.search, const JotifyV3Hub()),
        _feature('V4 Experience', 'Ambient player, daily mix, privacy, widgets',
          Icons.auto_awesome_motion, const JotifyV4Hub()),
        _feature('V5–V7 Extras', 'Flow, voice search, lyrics studio and focus mode',
          Icons.graphic_eq, const JotifyV5Hub()),
        _feature('Hidden songs and artists', 'Blocklist management and unhide',
          Icons.block, const JotifyBlocklistPage()),
        const Divider(height: 26),
        Text('OPTIONAL CONNECTED SERVICES', style: Theme.of(context).textTheme.titleSmall),
        ListTile(leading: const Icon(Icons.account_circle), title: const Text('Spotify library'),
          subtitle: Text(_spotifyConnected ? 'Saved session on device' :
              (spotifyConfigured ? 'Client ID configured; login not confirmed' : 'Needs your Spotify developer Client ID'))),
        ListTile(leading: const Icon(Icons.history), title: const Text('Last.fm scrobbling'),
          subtitle: Text(_lastFmConnected ? 'Saved session on device' :
              (lastFmConfigured ? 'API key configured; login not confirmed' : 'Needs your Last.fm API credentials'))),
        ListTile(leading: const Icon(Icons.playlist_add), title: const Text('Spotify → Saavn playlist import'),
          subtitle: Text(hasSpotifyCache ? 'Synced metadata exists; manually confirm Saavn matches' : 'Sync Spotify library first')),
        ListTile(leading: const Icon(Icons.devices), title: const Text('Local-network Jams'),
          subtitle: Text(jam.hosting ? 'Hosting a LAN room' : jam.joined ? 'Joined a LAN room' : 'Not connected (same-Wi-Fi only)')),
        const ListTile(leading: Icon(Icons.smart_display), title: Text('YouTube / YouTube Music'),
          subtitle: Text('Official video embed and external Music link; no unrestricted audio extraction')),
        ListTile(leading: const Icon(Icons.extension), title: const Text('Provider interfaces'),
          subtitle: Text('${JotifyProviderRegistry.builtIn.length} built-in provider descriptors; not a full third-party executable plugin runtime')),
        _feature('Open connected services',
          'Spotify sync, Saavn matching, official YouTube video, LAN Jam, plugins and Last.fm',
          Icons.hub, const JotifyConnectHub()),
        const SizedBox(height: 12),
        const Padding(padding: EdgeInsets.symmetric(horizontal: 8), child: Text(
          'This panel shows source features and local connection state. It cannot certify that an external provider or device feature works until tested on your phone.',
        )),
      ]),
    );
  }
}
