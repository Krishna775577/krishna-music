/*
 *  This file is part of BlackHole (https://github.com/Sangwan5688/BlackHole).
 * 
 * BlackHole is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * BlackHole is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with BlackHole.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * Copyright (c) 2021-2023, Ankit Sangwan
 */

import 'package:jotify/Features/spotube_parity/blocklist.dart';
import 'package:audio_service/audio_service.dart';
import 'package:jotify/CustomWidgets/add_playlist.dart';
import 'package:jotify/Helpers/add_mediaitem_to_queue.dart';
import 'package:jotify/Helpers/mediaitem_converter.dart';
import 'package:jotify/Helpers/radio.dart';
import 'package:jotify/Screens/Common/song_list.dart';
import 'package:jotify/Screens/Search/albums.dart';
import 'package:jotify/Screens/Search/search.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';

class SongTileTrailingMenu extends StatefulWidget {
  final Map data;
  final bool isPlaylist;
  final Function(Map)? deleteLiked;
  const SongTileTrailingMenu({
    super.key,
    required this.data,
    this.isPlaylist = false,
    this.deleteLiked,
  });

  @override
  _SongTileTrailingMenuState createState() => _SongTileTrailingMenuState();
}

class _SongTileTrailingMenuState extends State<SongTileTrailingMenu> {
  @override
  Widget build(BuildContext context) {
    final MediaItem mediaItem = MediaItemConverter.mapToMediaItem(widget.data);
    return PopupMenuButton(
      icon: Icon(
        Icons.more_vert_rounded,
        color: Theme.of(context).iconTheme.color,
      ),
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.all(
          Radius.circular(15.0),
        ),
      ),
      itemBuilder: (context) => [
        if (widget.isPlaylist && widget.deleteLiked != null)
          PopupMenuItem(
            value: 6,
            child: Row(
              children: [
                const Icon(
                  Icons.delete_rounded,
                ),
                const SizedBox(
                  width: 10.0,
                ),
                Text(
                  AppLocalizations.of(
                    context,
                  )!
                      .remove,
                ),
              ],
            ),
          ),
        PopupMenuItem(
          value: 2,
          child: Row(
            children: [
              Icon(
                Icons.playlist_play_rounded,
                color: Theme.of(context).iconTheme.color,
                size: 26.0,
              ),
              const SizedBox(width: 10.0),
              Text(AppLocalizations.of(context)!.playNext),
            ],
          ),
        ),
        PopupMenuItem(
          value: 1,
          child: Row(
            children: [
              Icon(
                Icons.queue_music_rounded,
                color: Theme.of(context).iconTheme.color,
              ),
              const SizedBox(width: 10.0),
              Text(AppLocalizations.of(context)!.addToQueue),
            ],
          ),
        ),
        PopupMenuItem(
          value: 0,
          child: Row(
            children: [
              Icon(
                Icons.playlist_add_rounded,
                color: Theme.of(context).iconTheme.color,
              ),
              const SizedBox(width: 10.0),
              Text(AppLocalizations.of(context)!.addToPlaylist),
            ],
          ),
        ),
        PopupMenuItem(
          value: 4,
          child: Row(
            children: [
              Icon(
                Icons.album_rounded,
                color: Theme.of(context).iconTheme.color,
              ),
              const SizedBox(width: 10.0),
              Text(AppLocalizations.of(context)!.viewAlbum),
            ],
          ),
        ),
        if (mediaItem.artist != null)
          ...mediaItem.artist.toString().split(', ').map(
                (artist) => PopupMenuItem(
                  value: artist,
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: [
                        Icon(
                          Icons.person_rounded,
                          color: Theme.of(context).iconTheme.color,
                        ),
                        const SizedBox(width: 10.0),
                        Text(
                          '${AppLocalizations.of(context)!.viewArtist} ($artist)',
                        ),
                      ],
                    ),
                  ),
                ),
              ),
        const PopupMenuItem(
          value: 'find_alternative',
          child: Row(children: [Icon(Icons.manage_search_rounded), SizedBox(width: 10),
            Text('Find another version (Saavn)')]),
        ),
        const PopupMenuItem(
          value: 'block_track',
          child: Row(children: [Icon(Icons.hide_source_rounded), SizedBox(width: 10),
            Text('Hide this song')]),
        ),
        if ((mediaItem.artist ?? '').trim().isNotEmpty)
          const PopupMenuItem(
            value: 'block_artist',
            child: Row(children: [Icon(Icons.person_off_rounded), SizedBox(width: 10),
              Text('Hide this artist')]),
          ),
        PopupMenuItem(
          value: 7,
          child: Row(
            children: [
              Icon(
                Icons.podcasts_rounded,
                color: Theme.of(context).iconTheme.color,
              ),
              const SizedBox(width: 10.0),
              Text(AppLocalizations.of(context)!.playRadio),
            ],
          ),
        ),
        PopupMenuItem(
          value: 3,
          child: Row(
            children: [
              Icon(
                Icons.share_rounded,
                color: Theme.of(context).iconTheme.color,
              ),
              const SizedBox(width: 10.0),
              Text(AppLocalizations.of(context)!.share),
            ],
          ),
        ),
      ],
      onSelected: (value) async {
        if (value == 'block_track') {
          await JotifyBlocklist.blockTrack(widget.data);
          if (mounted) ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Song hidden. Manage it in Settings → Hidden songs & artists.')));
          return;
        }
        if (value == 'block_artist') {
          final artist = (mediaItem.artist ?? '').split(',').first.trim();
          await JotifyBlocklist.blockArtist(artist);
          if (mounted) ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('$artist hidden from new searches and queues.')));
          return;
        }
        if (value == 'find_alternative') {
          final text = '${mediaItem.title} ${mediaItem.artist ?? ''}'.trim();
          Navigator.push(context, MaterialPageRoute<void>(
            builder: (_) => SearchPage(query: text)));
          return;
        }
        switch (value) {
          case 3:
            Share.share(widget.data['perma_url'].toString());

          case 4:
            Navigator.push(
              context,
              PageRouteBuilder(
                opaque: false,
                pageBuilder: (_, __, ___) => SongsListPage(
                  listItem: {
                    'type': 'album',
                    'id': mediaItem.extras?['album_id'],
                    'title': mediaItem.album,
                    'image': mediaItem.artUri,
                  },
                ),
              ),
            );
          case 6:
            widget.deleteLiked!(widget.data);
          case 7:
            createRadioItems(stationNames: [mediaItem.id]);
          case 0:
            AddToPlaylist().addToPlaylist(context, mediaItem);
          case 1:
            addToNowPlaying(context: context, mediaItem: mediaItem);
          case 2:
            playNext(mediaItem, context);
          default:
            Navigator.push(
              context,
              PageRouteBuilder(
                opaque: false,
                pageBuilder: (_, __, ___) => AlbumSearchPage(
                  query: value.toString(),
                  type: 'Artists',
                ),
              ),
            );
            break;
        }
      },
    );
  }
}

