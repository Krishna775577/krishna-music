/*
 *  This file is part of BlackHole (https://github.com/Sangwan5688/BlackHole).
 * 
 * BlackHole is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * BlackHole is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with BlackHole.  If not, see <http://www.gnu.org/licenses/>.
 * 
 * Copyright (c) 2021-2023, Ankit Sangwan
 */

import 'dart:convert';
import 'dart:async';

import 'package:audiotagger/audiotagger.dart';
import 'package:audiotagger/models/tag.dart';
import 'package:http/http.dart';
import 'package:logging/logging.dart';
import 'package:hive/hive.dart';

// ignore: avoid_classes_with_only_static_members
class Lyrics {
  /// LRCLIB is tried first: an older lyrics proxy was unreliable,
  /// and the old Saavn URL constructed its query incorrectly.
  /// Only cache successful lyrics, never an unavailable/error response.
  static Future<Map<String, String>> getLyrics({
    required String id,
    required String title,
    required String artist,
    required bool saavnHas,
  }) async {
    // Manually imported LRC takes priority in both the classic player and
    // Lyrics Studio 3.0, including when offline.
    if (Hive.isBoxOpen('settings')) {
      final manualKey = 'v5lrc:${title.trim().toLowerCase()}:${artist.trim().toLowerCase()}';
      final manual = Hive.box('settings').get(manualKey);
      if (manual is String && manual.trim().isNotEmpty) {
        return <String, String>{
          'id': id, 'lyrics': manual, 'type': 'lrc', 'source': 'Imported LRC · offline',
        };
      }
    }
    final result = <String, String>{
      'id': id, 'lyrics': '', 'type': 'text', 'source': 'Not available',
    };
    final key = 'v4lyrics:${title.trim().toLowerCase()}:${artist.trim().toLowerCase()}';
    try {
      if (Hive.isBoxOpen('cache')) {
        final cached = Hive.box('cache').get(key);
        if (cached is Map && cached['lyrics'] is String &&
            (cached['lyrics'] as String).trim().isNotEmpty) {
          return <String, String>{
            'id': id,
            'lyrics': cached['lyrics'] as String,
            'type': (cached['type'] ?? 'text').toString(),
            'source': (cached['source'] ?? 'Cached lyrics').toString(),
          };
        }
      }
    } catch (error) {
      Logger.root.warning('Lyrics cache read failed: $error');
    }

    try {
      final lrclib = await getLRCLIBLyrics(title: title, artist: artist)
          .timeout(const Duration(seconds: 8));
      if ((lrclib['lyrics'] ?? '').trim().isNotEmpty) {
        result.addAll(lrclib);
      }
    } catch (error) {
      Logger.root.warning('LRCLIB lyrics lookup failed: $error');
    }

    if (result['lyrics']!.trim().isEmpty && saavnHas && id.isNotEmpty) {
      try {
        final text = await getSaavnLyrics(id).timeout(const Duration(seconds: 6));
        if (text.trim().isNotEmpty) {
          result.addAll({'lyrics': text, 'type': 'text', 'source': 'JioSaavn'});
        }
      } catch (error) {
        Logger.root.warning('JioSaavn lyrics lookup failed: $error');
      }
    }

    // Best-effort compatibility fallback, bounded so the UI never spins forever.
    if (result['lyrics']!.trim().isEmpty) {
      try {
        final text = await getMusixMatchLyrics(title: title, artist: artist)
            .timeout(const Duration(seconds: 5));
        if (text.trim().isNotEmpty) {
          result.addAll({'lyrics': text, 'type': 'text', 'source': 'Musixmatch'});
        }
      } catch (error) {
        Logger.root.warning('Musixmatch fallback failed: $error');
      }
    }

    if (result['lyrics']!.trim().isNotEmpty) {
      try {
        if (Hive.isBoxOpen('cache')) {
          await Hive.box('cache').put(key, <String, String>{
            'lyrics': result['lyrics']!,
            'type': result['type']!,
            'source': result['source']!,
          });
        }
      } catch (error) {
        Logger.root.warning('Lyrics cache write failed: $error');
      }
    }
    return result;
  }

  /// A manual Lyrics Studio retry must really retry, rather than returning
  /// a previously cached successful provider response.
  static Future<void> clearCache(String title, String artist) async {
    if (!Hive.isBoxOpen('cache')) return;
    final key = 'v4lyrics:${title.trim().toLowerCase()}:${artist.trim().toLowerCase()}';
    await Hive.box('cache').delete(key);
  }

  static String _normalize(String text) => text.toLowerCase()
      .replaceAll(RegExp(r'\([^)]*\)|\[[^]]*\]'), ' ')
      .replaceAll(RegExp(r'[^a-z0-9\u0900-\u097f]+'), ' ')
      .trim();

  /// LRCLIB title variants help with suffixes such as (Official Video),
  /// [Remastered] and "feat." while keeping artist/title validation.
  /// Search failures/timeouts are isolated from JioSaavn fallback.
  static Future<Map<String, String>> getLRCLIBLyrics({
    required String title,
    required String artist,
  }) async {
    const empty = <String, String>{'lyrics': '', 'type': 'text', 'source': 'LRCLIB'};
    final rawTitle = title.trim();
    if (rawTitle.isEmpty) return Map<String, String>.from(empty);
    final cleanTitle = rawTitle
        .replaceAll(RegExp(r'\s*\([^)]*\)|\s*\[[^]]*\]'), ' ')
        .replaceAll(RegExp(r'\s+(?:feat\.?|ft\.?|featuring)\s+.*$', caseSensitive: false), '')
        .replaceAll(RegExp(r'\s+(?:official video|lyrical video|lyrics video|full song)$', caseSensitive: false), '')
        .trim();
    final cleanArtist = artist.trim().toLowerCase() == 'null' ? '' : artist.trim();
    final firstArtist = cleanArtist.split(RegExp(r'[,;&]')).first.trim();
    final requests = <Map<String, String>>[];
    final original = <String, String>{'track_name': rawTitle};
    if (cleanArtist.isNotEmpty) original['artist_name'] = cleanArtist;
    requests.add(original);
    if (cleanTitle.isNotEmpty && cleanTitle.toLowerCase() != rawTitle.toLowerCase()) {
      final refined = <String, String>{'track_name': cleanTitle};
      if (firstArtist.isNotEmpty) refined['artist_name'] = firstArtist;
      requests.add(refined);
    }
    requests.add(<String, String>{'q': '${cleanTitle.isEmpty ? rawTitle : cleanTitle} $firstArtist'.trim()});
    final wanted = _normalize(cleanTitle.isNotEmpty ? cleanTitle : rawTitle);
    final wantedWords = wanted.split(' ').where((x) => x.length > 2).toSet();
    final wantedArtist = _normalize(firstArtist);
    for (final query in requests.take(3)) {
      try {
        final uri = Uri.https('lrclib.net', '/api/search', query);
        final response = await get(uri, headers: <String, String>{
          'Accept': 'application/json', 'User-Agent': 'Jotify/5.0 (lyrics lookup)',
        }).timeout(const Duration(seconds: 5));
        if (response.statusCode != 200 || response.body.length > 250000) continue;
        final decoded = jsonDecode(response.body);
        if (decoded is! List) continue;
        for (final entry in decoded.take(20)) {
          if (entry is! Map || entry['instrumental'] == true) continue;
          final foundTitle = _normalize((entry['trackName'] ?? '').toString());
          final foundArtist = _normalize((entry['artistName'] ?? '').toString());
          if (foundTitle.isEmpty || wanted.isEmpty) continue;
          final words = foundTitle.split(' ').where((x) => x.length > 2).toSet();
          final common = words.intersection(wantedWords).length;
          final titleMatch = foundTitle == wanted ||
              (wantedWords.isNotEmpty && common >= (wantedWords.length * 0.75).ceil() &&
                  common >= (words.length * 0.65).ceil());
          if (!titleMatch) continue;
          if (wantedArtist.isNotEmpty && foundArtist.isNotEmpty) {
            final names = wantedArtist.split(' ').where((w) => w.length >= 4);
            if (!foundArtist.contains(wantedArtist) &&
                !names.any((n) => foundArtist.contains(n))) continue;
          }
          final synced = (entry['syncedLyrics'] ?? '').toString().trim();
          final plain = (entry['plainLyrics'] ?? '').toString().trim();
          if (synced.isNotEmpty && synced.toLowerCase() != 'null') {
            return <String, String>{'lyrics': synced, 'type': 'lrc', 'source': 'LRCLIB (synced)'};
          }
          if (plain.isNotEmpty && plain.toLowerCase() != 'null') {
            return <String, String>{'lyrics': plain, 'type': 'text', 'source': 'LRCLIB'};
          }
        }
      } catch (error) {
        Logger.root.warning('LRCLIB search variant unavailable: $error');
      }
    }
    return Map<String, String>.from(empty);
  }

  static Future<String> getSaavnLyrics(String id) async {
    try {
      final Uri lyricsUrl = Uri.https('www.jiosaavn.com', '/api.php', {
        '__call': 'lyrics.getLyrics',
        'lyrics_id': id,
        'ctx': 'web6dot0',
        'api_version': '4',
        '_format': 'json',
      });
      final Response res =
          await get(lyricsUrl, headers: {'Accept': 'application/json'})
              .timeout(const Duration(seconds: 5));

      final List<String> rawLyrics = res.body.split('-->');
      Map fetchedLyrics = {};
      if (rawLyrics.length > 1) {
        fetchedLyrics = json.decode(rawLyrics[1]) as Map;
      } else {
        fetchedLyrics = json.decode(rawLyrics[0]) as Map;
      }
      final String lyrics =
          (fetchedLyrics['lyrics'] ?? '').toString()
              .replaceAll(RegExp(r'<br\s*/?>', caseSensitive: false), '\n');
      return lyrics;
    } catch (e) {
      Logger.root.severe('Error in getSaavnLyrics', e);
      return '';
    }
  }

  static Future<String> getGoogleLyrics({
    required String title,
    required String artist,
  }) async {
    const String url =
        'https://www.google.com/search?client=safari&rls=en&ie=UTF-8&oe=UTF-8&q=';
    const String delimiter1 =
        '</div></div></div></div><div class="hwc"><div class="BNeawe tAd8D AP7Wnd"><div><div class="BNeawe tAd8D AP7Wnd">';
    const String delimiter2 =
        '</div></div></div></div></div><div><span class="hwc"><div class="BNeawe uEec3 AP7Wnd">';
    String lyrics = '';
    try {
      lyrics = (await get(
        Uri.parse(Uri.encodeFull('$url$title by $artist lyrics')),
      ))
          .body;
      lyrics = lyrics.split(delimiter1).last;
      lyrics = lyrics.split(delimiter2).first;
      if (lyrics.contains('<meta charset="UTF-8">')) throw Error();
    } catch (_) {
      try {
        lyrics = (await get(
          Uri.parse(
            Uri.encodeFull('$url$title by $artist song lyrics'),
          ),
        ))
            .body;
        lyrics = lyrics.split(delimiter1).last;
        lyrics = lyrics.split(delimiter2).first;
        if (lyrics.contains('<meta charset="UTF-8">')) throw Error();
      } catch (_) {
        try {
          lyrics = (await get(
            Uri.parse(
              Uri.encodeFull(
                '$url${title.split("-").first} by $artist lyrics',
              ),
            ),
          ))
              .body;
          lyrics = lyrics.split(delimiter1).last;
          lyrics = lyrics.split(delimiter2).first;
          if (lyrics.contains('<meta charset="UTF-8">')) throw Error();
        } catch (_) {
          lyrics = '';
        }
      }
    }
    return lyrics.trim();
  }

  static Future<String> getOffLyrics(String path) async {
    try {
      final Audiotagger tagger = Audiotagger();
      final Tag? tags = await tagger.readTags(path: path);
      return tags?.lyrics ?? '';
    } catch (e) {
      return '';
    }
  }

  static Future<String> getLyricsLink(String song, String artist) async {
    const String authority = 'www.musixmatch.com';
    final String unencodedPath = '/search/$song $artist';
    final Response res = await get(Uri.https(authority, unencodedPath));
    if (res.statusCode != 200) return '';
    final RegExpMatch? result =
        RegExp(r'href=\"(\/lyrics\/.*?)\"').firstMatch(res.body);
    return result == null ? '' : result[1]!;
  }

  static Future<String> scrapLink(String unencodedPath) async {
    Logger.root.info('Trying to scrap lyrics from $unencodedPath');
    const String authority = 'www.musixmatch.com';
    final Response res = await get(Uri.https(authority, unencodedPath));
    if (res.statusCode != 200) return '';
    final List<String?> lyrics = RegExp(
      r'<span class=\"lyrics__content__ok\">(.*?)<\/span>',
      dotAll: true,
    ).allMatches(res.body).map((m) => m[1]).toList();

    return lyrics.isEmpty ? '' : lyrics.join('\n');
  }

  static Future<String> getMusixMatchLyrics({
    required String title,
    required String artist,
  }) async {
    try {
      final String link = await getLyricsLink(title, artist);
      Logger.root.info('Found Musixmatch Lyrics Link: $link');
      final String lyrics = await scrapLink(link);
      return lyrics;
    } catch (e) {
      Logger.root.severe('Error in getMusixMatchLyrics', e);
      return '';
    }
  }
}
