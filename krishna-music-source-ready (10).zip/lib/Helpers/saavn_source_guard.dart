/// Commercial online audio comes only from JioSaavn. Optional explicitly
/// paired LAN sessions may stream user's local files. Other providers remain
/// metadata / official video embeds and never feed this audio handler.
class SaavnSourceGuard {
  const SaavnSourceGuard._();

  static bool isSaavnUrl(Object? rawUrl) {
    final value = rawUrl?.toString().trim() ?? '';
    final uri = Uri.tryParse(value);
    if (uri == null || (uri.scheme != 'https' && uri.scheme != 'http')) {
      return false;
    }
    final host = uri.host.toLowerCase();
    return host == 'saavncdn.com' || host.endsWith('.saavncdn.com') ||
        host == 'jiosaavn.com' || host.endsWith('.jiosaavn.com') ||
        host == 'saavn.com' || host.endsWith('.saavn.com');
  }

  static bool isLocalUrl(Object? rawUrl) {
    final value = rawUrl?.toString().trim() ?? '';
    if (value.isEmpty) return false;
    final uri = Uri.tryParse(value);
    return value.startsWith('/') || uri?.scheme == 'file' ||
        uri?.scheme == 'content';
  }

  // Explicitly paired LAN sessions may stream opted-in local audio, not third
  // party streams. This trust exists in memory only and is removed on leave.
  static String _lanHost = '';
  static int _lanPort = -1;
  static void trustLanHost(String host, int port) { _lanHost = host; _lanPort = port; }
  static void clearLanHost() { _lanHost = ''; _lanPort = -1; }

  static bool isTrustedLanUrl(Object? rawUrl) {
    final uri = Uri.tryParse(rawUrl?.toString() ?? '');
    return uri != null && uri.scheme == 'http' && uri.host == _lanHost &&
      uri.port == _lanPort && uri.path == '/audio' &&
      RegExp(r'^\d{6}$').hasMatch(uri.queryParameters['code'] ?? '');
  }

  static bool isPlayableUrl(Object? rawUrl) =>
      isSaavnUrl(rawUrl) || isLocalUrl(rawUrl) || isTrustedLanUrl(rawUrl);

  static bool isPlayableTrack(Map item) =>
      isPlayableUrl(item['url'] ?? item['path']);
}
