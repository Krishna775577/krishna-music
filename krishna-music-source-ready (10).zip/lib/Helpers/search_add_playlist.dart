import 'package:jotify/APIs/api.dart';
import 'package:logging/logging.dart';

/// Import music only from an existing Saavn playlist link.
class SearchAddPlaylist {
  static Future<Map> addJioSaavnPlaylist(String inLink) async {
    try {
      final id = inLink.split('?').first.split('/').last;
      if (id.isEmpty || !inLink.contains('saavn.com')) return {};
      final data = await SaavnAPI().getSongFromToken(id, 'playlist', n: -1);
      return <String, dynamic>{
        'title': data['title'],
        'count': (data['songs'] as List).length,
        'tracks': data['songs'],
      };
    } catch (error, stack) {
      Logger.root.warning('Saavn playlist import failed', error, stack);
      return {};
    }
  }
}
