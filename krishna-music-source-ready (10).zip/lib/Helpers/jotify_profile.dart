import 'dart:io';

import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:hive/hive.dart';
import 'package:uuid/uuid.dart';

/// Local, one-time Jotify profile. This is NOT Spotify/Last.fm login.
/// The settings box is the primary store; secure storage is a best-effort
/// independent backup on mobile for old upgrades with missing Hive keys.
class JotifyProfile {
  JotifyProfile._();

  static const String _completedKey = 'jotifyProfileCreated';
  static const String _backupNameKey = 'jotify_local_profile_name_v1';
  static const String _backupIdKey = 'jotify_local_profile_id_v1';
  static const FlutterSecureStorage _secure = FlutterSecureStorage();
  static const Uuid _uuid = Uuid();

  static String? _usable(Object? value) {
    if (value is! String) return null;
    final text = value.trim();
    return text.isEmpty ? null : text;
  }

  static bool hasProfile(Box settings) {
    // Older versions did not store the completion flag. A name OR a userId
    // is proof that the user has already passed the name screen.
    return settings.get(_completedKey) == true ||
        _usable(settings.get('name')) != null ||
        _usable(settings.get('userId')) != null;
  }

  static Future<void> save(String suppliedName) async {
    final settings = Hive.box('settings');
    final name = suppliedName.trim().isEmpty ? 'Guest' : suppliedName.trim();
    final id = _usable(settings.get('userId')) ?? _uuid.v4();
    await settings.putAll(<String, dynamic>{
      'name': name,
      'userId': id,
      _completedKey: true,
    });
    await settings.flush();
    await _saveBackup(name, id);
  }

  static Future<void> restoreOnStartup() async {
    final settings = Hive.box('settings');
    var name = _usable(settings.get('name'));
    var id = _usable(settings.get('userId'));

    // Best effort repair if an old update lost one/both Hive keys.
    if (name == null || id == null) {
      final mobile = Platform.isAndroid || Platform.isIOS;
      if (mobile) {
        try {
          name ??= _usable(await _secure.read(key: _backupNameKey));
          id ??= _usable(await _secure.read(key: _backupIdKey));
        } catch (_) {
          // Android Keystore can be reset during OS/device migrations;
          // never crash Jotify or block startup over a backup failure.
        }
      }
    }

    // Recover legacy profiles. Never ask for a name if there was already a
    // userId, and never discard a name just because its old ID is missing.
    if (name == null && id != null) name = 'Guest';
    if (name != null && id == null) id = _uuid.v4();
    if (name == null && id == null && settings.get(_completedKey) == true) {
      name = 'Guest';
      id = _uuid.v4();
    }
    if (name == null || id == null) return; // Genuine first launch.

    final changed = settings.get('name') != name ||
        settings.get('userId') != id ||
        settings.get(_completedKey) != true;
    if (changed) {
      await settings.putAll(<String, dynamic>{
        'name': name,
        'userId': id,
        _completedKey: true,
      });
      await settings.flush();
    }
    await _saveBackup(name, id);
  }

  static Future<void> _saveBackup(String name, String id) async {
    if (!Platform.isAndroid && !Platform.isIOS) return;
    try {
      await _secure.write(key: _backupNameKey, value: name);
      await _secure.write(key: _backupIdKey, value: id);
    } catch (_) {
      // Hive is still persisted even if secure storage is unavailable.
    }
  }
}
