package com.shadow.blackhole

// Compatibility stub for older ZIP-overlaid projects.
// JotifyMusicWidget is defined only in JotifyMusicWidget.kt.
