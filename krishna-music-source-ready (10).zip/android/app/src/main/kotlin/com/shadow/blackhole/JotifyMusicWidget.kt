package com.shadow.blackhole

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.view.KeyEvent
import android.widget.RemoteViews

/** Updates a lightweight widget and forwards headset-style media keys to AudioService. */
class JotifyMusicWidget : AppWidgetProvider() {
    companion object {
        private const val TOGGLE = "jotify.widget.TOGGLE"
        private const val NEXT = "jotify.widget.NEXT"
        private const val PREVIOUS = "jotify.widget.PREVIOUS"

        fun refresh(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, JotifyMusicWidget::class.java))
            if (ids.isNotEmpty()) JotifyMusicWidget().onUpdate(context, manager, ids)
        }

        private fun keyCode(action: String?): Int? = when (action) {
            TOGGLE -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
            NEXT -> KeyEvent.KEYCODE_MEDIA_NEXT
            PREVIOUS -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            else -> null
        }
    }

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val prefs = context.getSharedPreferences("jotify_widget", Context.MODE_PRIVATE)
        val title = prefs.getString("title", "Jotify") ?: "Jotify"
        val artist = prefs.getString("artist", "Open Jotify to listen") ?: ""
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0
        for (id in ids) {
            val views = RemoteViews(context.packageName, R.layout.jotify_music_widget)
            views.setTextViewText(R.id.widget_title_text, title)
            views.setTextViewText(R.id.widget_subtitle_text, artist)
            views.setOnClickPendingIntent(R.id.widget_button_play_pause,
                PendingIntent.getBroadcast(context, 100, Intent(context, JotifyMusicWidget::class.java).setAction(TOGGLE), flags))
            views.setOnClickPendingIntent(R.id.widget_button_next,
                PendingIntent.getBroadcast(context, 101, Intent(context, JotifyMusicWidget::class.java).setAction(NEXT), flags))
            views.setOnClickPendingIntent(R.id.widget_button_prev,
                PendingIntent.getBroadcast(context, 102, Intent(context, JotifyMusicWidget::class.java).setAction(PREVIOUS), flags))
            val open = Intent(context, JotifyActivity::class.java).setAction(Intent.ACTION_MAIN)
            views.setOnClickPendingIntent(R.id.widget_container,
                PendingIntent.getActivity(context, 103, open, flags))
            manager.updateAppWidget(id, views)
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val code = keyCode(intent.action) ?: return
        // audio_service's MediaButtonReceiver is already declared in AndroidManifest.
        // Dispatch both DOWN and UP so the service can treat it as one key press.
        for (state in arrayOf(KeyEvent.ACTION_DOWN, KeyEvent.ACTION_UP)) {
            val event = KeyEvent(state, code)
            val mediaIntent = Intent(Intent.ACTION_MEDIA_BUTTON)
                .setClassName(context.packageName, "com.ryanheise.audioservice.MediaButtonReceiver")
                .putExtra(Intent.EXTRA_KEY_EVENT, event)
            context.sendBroadcast(mediaIntent)
        }
    }
}
