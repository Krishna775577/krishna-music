> Archive: this file describes previous versions. See README.md for the current Saavn-only V6 release.

# Jotify rebrand — change report

**Requested brand:** Jotify

**Customized and maintained by:** Krishna Bajaj

## Changed

- Dart package name in `pubspec.yaml` from `blackhole` to `jotify`.
- All active `package:blackhole/...` imports across `lib/` and `test/` updated to `package:jotify/...`.
- Localized user-visible "Made by" credit strings now use Krishna Bajaj.
- About screen and repository/share links now describe Jotify and Krishna Bajaj.
- Removed obsolete original-author UPI/payment/contact actions so the app does not accidentally send users to somebody else's account.
- Windows/Linux binary and app product display names updated where safe.
- Default backup folder/filename and audio notification channel's *displayed* name updated.
- Jotify URL-scheme aliases added while retaining legacy Android/iOS/macOS links.
- Website title and Android app store listing metadata updated.

## Deliberately NOT renamed

- Upstream BlackHole copyright notices credit **Ankit Sangwan** as original creator; changing them to Krishna Bajaj would falsely claim ownership.
- Android `applicationId`/Kotlin namespace `com.shadow.blackhole` stays the same to allow existing users to update the app without losing installed-app identity.
- Existing Hive database path `BlackHole/Database` and compatibility paths are retained so saved playlists/settings still load.
- Legacy app widget class and resource names, Firebase IDs, Spotify callback URI and existing deep links remain for compatibility.
- Historical translated README URLs and attribution remain, as records of the upstream project.

**Validation:** static ZIP integrity and internal local import checks performed. Flutter/Android runtime build and device playback have not been independently verified.
