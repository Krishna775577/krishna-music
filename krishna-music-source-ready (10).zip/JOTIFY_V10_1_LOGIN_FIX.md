# Jotify V10.0.1 (build 71) — one-time name setup fix

## Root cause
`lib/Screens/Common/routes.dart` previously checked only `settings.userId`. A previously saved local name with missing legacy ID therefore led to the name/login screen on every launch.

## Code changes
- Initial route recognizes an existing saved name, userId, or completed-profile flag.
- Legacy profiles are repaired once on app startup; a missing ID is generated without discarding the user's saved name.
- Profile name, stable ID, completion flag are written together to Hive, then flushed before navigating.
- Android/iOS secure-storage fallback attempts profile recovery if older updates lose Hive profile keys. Backup errors never block the app.
- Skip/Guest flow uses the same persistence method. Rapid repeated taps cannot create repeated profiles.
- Bumped to `10.0.1+71`, and aligned Home, login and installed-build version label.

## Test checklist after APK build
1. Fresh install: name screen appears; enter name, finish preferences, Home opens.
2. Force close and reopen 3 times: Home opens directly, same name retained.
3. Upgrade an existing installation without uninstalling: name screen should not return.
4. Guest/Skip on fresh install, restart: Home opens directly.
5. Existing Hive `name` with missing `userId` restores ID and skips setup.
6. Clear app data or uninstall: name screen returns (expected; app storage removed).

## Important
This is a source-level fix. Android APK build/device tests remain unverified. Keep the same Android applicationId (`com.shadow.blackhole`) for update-data compatibility. Do not clear app storage or uninstall without a backup.
