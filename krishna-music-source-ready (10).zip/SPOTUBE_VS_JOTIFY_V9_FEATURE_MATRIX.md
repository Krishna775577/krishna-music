# Spotube Master vs Jotify V9 — Source feature comparison

The comparison is based on `spotube-master.zip` and the edited Jotify V9 source. **Present** means a relevant code path was located, **partial** means the feature has limited scope, **not found** means no working equivalent was identified. Neither application has been run as a device APK in this audit.

| # | Feature | Spotube supplied source | Jotify V9 source | Notes |
|---:|---|---|---|---|
| 1 | Home, search, artist/album pages | Present | Present | Both have basic navigation/catalog browsing |
| 2 | Built-in JioSaavn catalog/audio | Plugin-dependent | Present | Jotify's main online audio backend |
| 3 | Pluggable audio backends | Present | Partial | New typed contracts; no executable adapters for arbitrary plugins |
| 4 | NewPipe YouTube audio | Present | Not found | Jotify only provides official video embed |
| 5 | YouTube video in-app | Partial | Partial | Official embeds, platform can block |
| 6 | YouTube Music native engine | Not confirmed | Not found | Web site link, not native player |
| 7 | Spotify account/library metadata | Plugin dependent | Partial | Read-only sync + new Saavn match/import |
| 8 | Spotify licensed-audio streaming | Not confirmed | Not found | Spotify audio is not available |
| 9 | Playlist browsing | Present | Present | Existing |
| 10 | Playlist create/edit | Present | Present | Jotify local playlists and Spotify match import |
| 11 | Liked songs/favourites | Present | Present | Existing |
| 12 | Local/offline playback | Present | Present | Existing |
| 13 | Music downloads | Present | Present | Jotify Saavn-based |
| 14 | Quality settings | Present | Present | Existing |
| 15 | Convert/download arbitrary output formats | Present | Not confirmed | Jotify has bitrate options, no transcoding pipeline |
| 16 | Music metadata tagging | Present | Partial | Existing audiotagger dependency |
| 17 | Synced lyrics | Present | Present | Existing LRCLIB/other |
| 18 | Local LRC import | Not confirmed | Present | Existing |
| 19 | Queue, shuffle, repeat | Present | Present | Existing |
| 20 | Sleep timer | Present | Present | Existing |
| 21 | Equalizer | Not confirmed | Present | Existing UI |
| 22 | Crossfade/gapless | Not confirmed | Partial | V4 feature code, untested transition |
| 23 | Playback speed | Not confirmed | Present | Existing audio handler |
| 24 | Block tracks/artists | Present | Present | V7 |
| 25 | Alternative track matching | Present | Present | New Spotify→Saavn confidence matching expands V7 Saavn alternatives |
| 26 | Radio/discovery | Plugin-dependent | Present | JioSaavn |
| 27 | Plugin management/install UI | Present | Partial | External link manifest plugins with explicit permission |
| 28 | Executable JS/Zipline plugins | Present | Not found | Flutter-compatible runtime still missing |
| 29 | Typed metadata/audio/lyrics interfaces | Present | Partial | New Dart contracts and built-in MusicBrainz, Saavn and LRCLIB adapters; not equivalent full runtime |
| 30 | Plugin permission controls | Present | Partial | Explicit external link grant only |
| 31 | Plugin marketplace/discovery | Present | Partial | Curated template examples, not full repository marketplace |
| 32 | Last.fm scrobbling | Present | Partial | Jotify V8 native module; auth and device test needed |
| 33 | Synchronized Jams | Present | Partial | V9 LAN, manual code pairing |
| 34 | Remote playback controls | Present | Partial | Jotify LAN commands |
| 35 | Automatic LAN room discovery | Present | Partial | **Added in V9** as UDP broadcast, not Spotube's mDNS |
| 36 | Device-to-device audio transfer | Network services | Partial | V8 opt-in locally owned audio files |
| 37 | Cloud/internet Jam hosting | Not confirmed | Not found | No deployment provided |
| 38 | Discord Rich Presence | Present desktop | Not found | Requires platform-specific IPC |
| 39 | Voice search | Not found | Present | Jotify V5 |
| 40 | Backup/restore | Not found equivalent | Present | Existing |
| 41 | Listening statistics | Partial | Present | Existing |
| 42 | Themes | Present | Present | Existing |
| 43 | Translations | Present | Present | Existing |
| 44 | Cross-platform source | Present | Present | Build targets not device verified |
| 45 | Privacy/no telemetry guarantee | Claimed in Spotube README | Not established | Review third-party services before public launch |

## Changes in V9 vs V8

- Spotify imported library entries now open a **reviewed Saavn track matcher**, not only the standard search page.
- New UDP LAN discovery displays nearby rooms without the user typing the host address. Room PIN still needed.
- Built-in MusicBrainz metadata discovery, typed provider adapters and audio policy are explicitly declared; external link manifests now require a user permission grant.
- New integration tests and cleaner ZIP-to-GitHub source import workflow.

**Limit:** This is a source audit; no verified APK compilation, phone-to-phone LAN test, live Spotify/Last.fm API calls, or YouTube playback test has been performed in this environment. A status of Present/Partial is not a claim of successful real-device functionality.
