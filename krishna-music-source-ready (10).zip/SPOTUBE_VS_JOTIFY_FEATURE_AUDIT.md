# Uploaded Spotube source vs Jotify V7 feature audit

Sources inspected: `spotube-master.zip` (Kotlin Multiplatform, Compose modules and README) and Jotify V6.1 Flutter source. Assessment is based on project source only, not successful live tests. Status = Jotify after V7 edits.

| Spotube feature | Jotify V7 status | Notes |
|---|---|---|
| Music search/discovery | EXISTING | Saavn search/catalogue; Spotify/YouTube external search shortcuts NEW |
| Track/artist blacklist | NEW SOURCE IMPLEMENTATION | Song menu, settings, search, queue and autoplay; Android behavior pending tests |
| Alternative track/version lookup | NEW SOURCE IMPLEMENTATION | Reruns a Saavn search with the selected title+artist |
| Synced lyrics / lyrics plugin | PARTIAL / EXISTING | Online + local `.lrc` lyrics present. No generic Spotube lyrics plugin API |
| Offline downloads with metadata tags | EXISTING | Saavn download + `audiotagger`; external streaming not supported |
| Local music import/playback | EXISTING | Jotify local library & offline player |
| Playlist creation/management | EXISTING | Jotify playlists; sharing/export/import in V5 |
| Music queue, shuffle, repeat | EXISTING | Player queue and V3 smart queue |
| Playback EQ, speed, sleep timer | EXISTING | Android equalizer, speed, sleep timer |
| UI themes, dark mode | EXISTING | Jotify themes and AMOLED |
| Privacy mode | EXISTING | V4 private listening |
| Community JS plugin marketplace | NOT IMPLEMENTED | Spotube uses Zipline, plugin interfaces, sandbox and permissions. Requires separate Flutter runtime and security design |
| Spotify metadata/account sync | NOT IMPLEMENTED | External Spotify search only; real sync requires authorized provider authentication/API and handling of service terms |
| YouTube / YouTube Music in-app audio/video | NOT IMPLEMENTED | External YouTube search only; prior embedded playback had errors; no deceptive claim of in-app playback |
| Multiple active audio-source backends | NOT IMPLEMENTED | Playback remains Saavn/local; provider abstraction, auth and compatibility required |
| Live synchronized listening jams | NOT IMPLEMENTED | V5 Together is file-based playlist sharing; not real-time synced sessions |
| LAN device discovery / remote play | NOT IMPLEMENTED | Spotube has dedicated network service; no Jotify Dart equivalent here |
| Discord Rich Presence | NOT IMPLEMENTED | Desktop-focused external RPC integration |
| Last.fm / plugin scrobbling | NOT IMPLEMENTED | Jotify has local play statistics, no verified remote scrobble client |
| Windows/macOS/Linux parity | PARTIAL | Flutter multi-platform code exists; this build workflow tests Android only |
| Auto-update / release channels | PARTIAL | Jotify update checker exists; no Spotube-style release channel machinery |

**Conclusion:** V7 adds several practical Spotube-inspired features to existing Jotify source, but does *not* deliver all Spotube features or claim a fully working Spotify/YouTube playback integration. The two application stacks are fundamentally different (Kotlin Multiplatform vs Flutter).
