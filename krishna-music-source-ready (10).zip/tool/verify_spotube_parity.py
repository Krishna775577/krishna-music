#!/usr/bin/env python3
"""Static Spotube-inspired Jotify integration checks; run before Flutter build."""
from pathlib import Path
import re, sys
r=Path(__file__).resolve().parents[1]
checks={
 'blocklist source': ('lib/Features/spotube_parity/blocklist.dart', ['blockTrack','blockArtist','isBlockedMap','isBlockedMediaItem']),
 'blocklist screen': ('lib/Features/spotube_parity/blocklist_page.dart', ['JotifyBlocklistPage','unblockArtist','unblockTrack']),
 'search filtering': ('lib/Screens/Search/search.dart',['JotifyBlocklist.isBlockedMap','_externalDiscovery','open.spotify.com','www.youtube.com']),
 'queue filter': ('lib/Services/player_service.dart',['JotifyBlocklist.isBlockedMap']),
 'audio source guard': ('lib/Services/audio_service.dart',['JotifyBlocklist.isBlockedMediaItem']),
 'settings entry': ('lib/Screens/Settings/new_settings_page.dart',['JotifyBlocklistPage']),
 'alternative version': ('lib/CustomWidgets/song_tile_trailing_menu.dart',['find_alternative','block_track','block_artist']),
}
errors=[]
for label,(path,fragments) in checks.items():
    text=(r/path).read_text() if (r/path).exists() else ''
    errors.extend(f'{label}: missing {x}' for x in fragments if x not in text)
if errors:
    print('\n'.join(errors));sys.exit(1)
print('Jotify V7 Spotube-inspired static integration checks passed.')
