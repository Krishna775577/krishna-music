#!/usr/bin/env python3
"""Deterministic SOURCE checks. Never claims Android compilation succeeded."""
from pathlib import Path
from xml.etree import ElementTree as ET
import json, re, sys, zipfile
r = Path(__file__).resolve().parents[1]
failures = []
def demand(ok, description):
    if not ok: failures.append(description)
source = lambda name: (r / name).read_text(encoding='utf-8')
demand('version: 10.0.0+70' in source('pubspec.yaml'), 'Incorrect pubspec version')
demand('V10 · Build 70' in source('lib/Screens/Login/auth.dart'), 'Old Login version')
demand('V10.0 · Unified Edition' in source('lib/Screens/Home/home_screen.dart'), 'Old Home version')
demand('Jotify V10' in source('lib/Screens/Settings/about.dart'), 'Old About version')
demand('Jotify V10 · All Features & Version' in source('lib/Screens/Settings/new_settings_page.dart'), 'Settings does not expose release center')
demand('JotifyReleaseCenter()' in source('lib/Screens/Home/home_screen.dart'), 'Home does not expose release center')
demand('JotifyReleaseCenter()' in source('lib/Screens/Settings/new_settings_page.dart'), 'Settings not wired to release center')
center = source('lib/Features/jotify_release/release_center.dart')
for feature in ('PackageInfo.fromPlatform()', 'JotifyV2Hub()', 'JotifyV3Hub()', 'JotifyV4Hub()', 'JotifyV5Hub()', 'JotifyConnectHub()', 'JotifyBlocklistPage()', 'hasStoredSession()', 'buildNumber'):
    demand(feature in center, 'Missing V10 release wiring: ' + feature)
for f in (r / 'lib').rglob('*.dart'):
    body = f.read_text(encoding='utf-8')
    for target in re.findall(r"(?m)^\s*import\s+['\"]package:jotify/([^'\"]+)['\"]", body):
        demand((r / 'lib' / target).is_file(), f'Missing import {target} from {f.relative_to(r)}')
for path in ('android/gradlew', 'android/gradle/wrapper/gradle-wrapper.jar', 'android/gradle/wrapper/gradle-wrapper.properties', 'lib/Services/audio_service.dart', 'lib/Services/player_service.dart', 'lib/Services/download.dart'):
    demand((r/path).is_file(), 'Missing ' + path)
for path in ('lib/Services/audio_service.dart', 'lib/Services/player_service.dart', 'lib/Services/download.dart'):
    demand('SaavnSourceGuard' in source(path), 'Missing Saavn stream guard in ' + path)
manifest = ET.parse(r/'android/app/src/main/AndroidManifest.xml')
android='{http://schemas.android.com/apk/res/android}'
app=manifest.getroot().find('application')
demand(app is not None and app.attrib.get(android+'label')=='Jotify', 'Manifest app label is not Jotify')
for f in (r/'lib/localization').glob('*.arb'):
    try: json.loads(f.read_text(encoding='utf-8'))
    except Exception as error: failures.append(f'Invalid localization {f.name}: {error}')
demand('actions/checkout@v6' in source('WORKFLOW_NODE24_REFERENCE.yml'), 'Reference CI not Node24 checkout')
demand('actions/setup-java@v5' in source('WORKFLOW_NODE24_REFERENCE.yml'), 'Reference CI not Node24 Java')
demand('actions/upload-artifact@v6' in source('WORKFLOW_NODE24_REFERENCE.yml'), 'Reference CI not Node24 artifact')
demand(not (r/'.github/workflows').exists(), 'Single ZIP must not overwrite protected workflow files')
if failures:
    for failure in failures: print('FAIL:', failure)
    sys.exit(1)
print('PASS: Jotify V10 release source, UI navigation, Android wrapper, providers, localization, imports, Node24 template')
print('NOT VERIFIED: Flutter compile, GitHub Actions run, app install, Spotify/YouTube/Last.fm live usage')
