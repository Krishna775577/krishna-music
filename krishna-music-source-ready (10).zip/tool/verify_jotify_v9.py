#!/usr/bin/env python3
"""Jotify V10 source wiring audit; NOT a Dart compile or physical-device test."""
from pathlib import Path
from xml.etree import ElementTree as ET
import json, re, sys
root = Path(__file__).resolve().parents[1]
errors=[]
def check(ok, msg):
    if not ok: errors.append(msg)

pub = (root / 'pubspec.yaml').read_text()
check(re.search(r'(?m)^name: jotify$',pub), 'Missing jotify package')
check(re.search(r'(?m)^version: 10\.0\.0\+70$',pub), 'Wrong V10 version')
for package in ['flutter_secure_storage','app_links','audio_service','webview_flutter','hive','crypto']:
    check(re.search(rf'(?m)^\s*{package}:',pub),f'Missing dependency: {package}')

required = {
    'LAN discovery': ('lib/Features/jotify_connect/lan_discovery.dart',
        ['RawDatagramSocket.bind', 'staleAfter', 'jam-beacon', 'isPrivateAddress']),
    'LAN room wiring': ('lib/Features/jotify_connect/jam_lan.dart',
        ['JotifyLanDiscovery.instance.advertise', 'stopAdvertising', 'JotifyLanDiscovery.isPrivateAddress']),
    'Spotify mapper': ('lib/Features/jotify_connect/spotify_import.dart',
        ['JotifySpotifyImportPage','JotifyTrackMatcher.score','SaavnSourceGuard.isSaavnUrl','addPlaylist(']),
    'Spotify matching algorithm': ('lib/Features/jotify_connect/track_matcher.dart',
        ['class JotifyTrackMatcher','durationMs','similarity']),
    'Spotify metadata duration': ('lib/Features/jotify_connect/spotify_auth.dart',
        ["'durationMs': raw['duration_ms']",'code_challenge_method']),
    'MusicBrainz metadata adapter': ('lib/Features/jotify_connect/provider_adapters.dart',
        ['JotifyMusicBrainzAdapter', 'parseRecordings', 'JotifyLrclibAdapter']),
    'Metadata search page': ('lib/Features/jotify_connect/metadata_search_page.dart',
        ['JotifyMetadataSearchPage','SearchPage(query:']),
    'Typed providers': ('lib/Features/jotify_connect/provider_contracts.dart',
        ['JotifyProviderCapability','JotifyTrackSearchProvider','JotifyLyricsLookupProvider','mayServeOnlineAudio']),
    'External plugin permission': ('lib/Features/jotify_connect/plugin_registry.dart',
        ['allowExternalLinks','permission','external_search']),
    'Screens': ('lib/Features/jotify_connect/connect_hub.dart',
        ['JotifySpotifyImportPage','nearby.rooms','JotifyProviderRegistry.builtIn','allowExternalLinks: true']),
    'Main startup': ('lib/main.dart', ['JotifySpotify.attach()', 'JotifyLastFm.start(', "'10.0.0+70'"]),
    'YouTube official embed': ('lib/Features/jotify_connect/youtube_embed.dart', ['WebViewWidget','Referer']),
    'Last.fm': ('lib/Features/jotify_connect/lastfm_scrobble.dart', ['track.scrobble','j8LastFmPending']),
    'Tests': ('test/jotify_v9_track_matcher_test.dart', ['unrelated tracks','duration mismatch']),
    'Metadata tests': ('test/jotify_v9_metadata_adapter_test.dart',['MusicBrainz JSON recording metadata']),
    'Discovery tests': ('test/jotify_v9_provider_discovery_test.dart',['LAN discovery rejects','only Saavn']),
}
for title,(path,need) in required.items():
    target=root/path
    check(target.is_file(),f'Missing {title} {path}')
    if target.is_file():
        value=target.read_text()
        for marker in need: check(marker in value,f'{title}: missing {marker}')

for f in (root/'lib').rglob('*.dart'):
    value=f.read_text()
    for inc in re.findall(r"(?m)^\s*import\s+['\"]package:jotify/([^'\"]+)['\"]",value):
        check((root/'lib'/inc).is_file(),f'Missing Dart import: {f.relative_to(root)} -> {inc}')

for path in ['lib/Services/player_service.dart','lib/Services/audio_service.dart','lib/Services/download.dart']:
    check('SaavnSourceGuard' in (root/path).read_text(),f'Audio guard removed from {path}')

manifest = ET.parse(root/'android/app/src/main/AndroidManifest.xml').getroot()
android='{http://schemas.android.com/apk/res/android}'
app=manifest.find('application')
check(app is not None and app.attrib.get(android+'label')=='Jotify','Launcher app name changed')
permissions={p.attrib.get(android+'name') for p in manifest.findall('uses-permission')}
check('android.permission.ACCESS_WIFI_STATE' in permissions,'Missing Wi-Fi-state permission')
check('android.permission.INTERNET' in permissions,'Missing network permission')
check('V10.0' in (root/'lib/Screens/Home/home_screen.dart').read_text(),'Missing V10 home marker')
for f in (root/'lib/localization').glob('*.arb'):
    try: json.loads(f.read_text())
    except Exception as exc: errors.append(f'Invalid localization {f.name}: {exc}')

if errors:
    print('\n'.join('FAIL: '+item for item in errors))
    sys.exit(1)
print(f'PASS: Jotify V10 source wiring / imports / manifest / localization; '
      f'{len(list((root/"lib").rglob("*.dart")))} Dart source files.')
print('NOT VERIFIED HERE: Dart compilation, Android APK, Spotify OAuth, two-device discovery, playback, live API.')
