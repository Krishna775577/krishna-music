# Jotify V9.0 — Spotube Parity Integration (source release)

**Build:** `9.0.0+60` · **Base:** Jotify V8 Connect Studio · **Compared against:** the user-supplied `spotube-master.zip` Kotlin/Compose Multiplatform source.

This is an **edited Flutter source release**, not a verified APK. The included GitHub Actions workflow is configured to perform Flutter analysis, tests and a debug APK build. A successful source-level audit does **not** prove the application compiled, accounts can authorize, YouTube videos can embed, or Wi-Fi discovery works on physical phones.

## What's newly implemented in V9

1. **Automatic nearby LAN Jam discovery**: opt-in UDP broadcasting/receiving on the same Wi-Fi, stale-room expiry and a nearby-rooms picker. Pairing still requires the 6-digit host code. The code is never broadcast. Manual IP connection remains as fallback. Broadcast discovery is not the same protocol as Spotube's DNS-SD/mDNS; Android/router broadcast isolation can prevent room detection.
2. **Spotify playlist → JioSaavn track matching/import**: after the existing Spotify OAuth library snapshot is synced, open liked tracks or a playlist, tap **Match & import into Jotify (Saavn)**, search Saavn candidates in batches of 12, review confidence scores and select the correct version, then save confirmed tracks into a new local Jotify playlist. This **does not play Spotify audio or change Spotify data**. The algorithm is conservative, and matching can fail due to track names/catalog differences.
3. **Built-in MusicBrainz metadata search and LRCLIB/ Saavn typed adapters**: a new Metadata Search Studio offers MusicBrainz recording discovery and Saavn results. A metadata result opens a Saavn search rather than pretending to play an external audio file. MusicBrainz calls are rate-limited and bounded; network availability remains untested.
4. **Typed provider capability contracts**: built-in providers now describe capabilities for Saavn audio, local files, Spotify metadata, YouTube official embeds, LRCLIB lyrics and Last.fm scrobbling. Audio-policy compatibility keeps Saavn as the only *online music-stream* backend. The contracts prepare a plugin architecture but do **not** execute Spotube JavaScript/Zipline plugins.
5. **Permissioned external-search manifest plugins**: install now requires in-app explicit approval to open external HTTPS search links, saved grants are checked before the link opens, old grants must be reapproved, and users can uninstall. Public-domain MusicBrainz and Bandcamp search-link examples have been added. These are **external discovery links**, not executable providers.
6. **Safer LAN pairing**: joining restricts host IPs to RFC1918/link-local private IPv4 addresses. Discovery beacons never contain a room PIN, song URL or account token.
7. **Regression tests and CI**: unit tests for title/artist/duration matching, MusicBrainz metadata parsing, provider audio restrictions and IP filtering; source audits verify features, imports, locales and Android manifest. New ZIP import workflow deletes stale Flutter/Kotlin files before overlaying V9.

## Retained from Jotify V2–V8

- Existing Saavn audio playback, album/artist/radio search, queue, local files, playlists, downloads, lyrics and `.lrc` imports.
- Voice search, favourites, blocklist, alternative Saavn tracks, visualizer/equalizer UI, sleep timer, settings, themes, local backups and listening statistics.
- Read-only Spotify account/library sync, official YouTube video embedding, YouTube API search, Last.fm client, local LAN Jams and opt-in local-file LAN streaming.

## Not equivalent to Spotube yet

| Feature | V9 reality |
|---|---|
| Dynamic executable Spotube JavaScript/Zipline plugins | **Not implemented**: Kotlin/Zipline runtime is not Flutter compatible. V9 has typed contracts and permissioned external URL discovery only. |
| NewPipe-based YouTube audio extraction | **Not implemented**. V9 retains official YouTube embeds (may be restricted by video owner/platform); normal music playback is Saavn/local. |
| Dedicated YouTube Music native audio engine | **Not implemented**; official YouTube Music external site link only. |
| Spotify full bidirectional write sync or licensed Spotify audio player | **Not implemented**. Read-only Spotify library sync and Saavn playlist matching/import are provided. |
| Internet-wide Jams, relay/hosting backend | **Not implemented**. V9 LAN sync and local-file transfer need same Wi-Fi. |
| DNS-SD discovery protocol compatibility with Spotube | **Not implemented**. V9 auto-discovery uses UDP broadcasts and needs on-device confirmation. |
| Discord Rich Presence desktop | **Not implemented**. Requires tested Discord IPC/SDK integration per desktop OS. |
| Download file transcoding into user-selected formats | **Not implemented**. Audio conversions need codecs/transcoder, and rights/format limitations apply. |

## Installing through GitHub Actions

1. In the GitHub repository root, upload and commit **`krishna-music-source-ready.zip`** from this release (replace any old archive).
2. Replace `.github/workflows/import-and-build.yml` with the separate V9 workflow file (`jotify-v9-import-and-build.yml`) and commit both.
3. Open **Actions → Import ZIP and Build Jotify V9 Spotube Parity → Run workflow**.
4. The workflow imports the ZIP, removes stale source, checks imports, runs Flutter analysis and tests, builds a debug APK and uploads `jotify-v9-spotube-parity-debug-apk` **if all stages pass**.
5. Install the APK; check `V9.0 · Spotube Parity` on Home. In **Settings → Jotify V9 · Spotube Parity**, check Spotify → Saavn import, Metadata Search Studio, Nearby Jams and Plugins & provider capabilities.

## Acceptance checklist (real devices/accounts)

- APK builds and starts, Saavn plays/searches/pauses/seeks, and downloaded audio is intact.
- New playlist import: login Spotify with your developer Client ID, sync library, preview suggested Saavn matches, review and import a test playlist. Verify unmapped tracks don't play.
- Two Android phones on same Wi-Fi: host a Jam, see it on another phone, enter room code, verify sync and remote controls. Router isolation may require manual IP.
- Last.fm authorized scrobbles and retries; official YouTube embed plays supported/embeddable videos.
- Ensure original saved playlists/files remain present after upgrade; back up before updating an APK signed by a different key.

### Licensing / safety

The V9 code is a Flutter-native implementation informed by Spotube feature *concepts*. No Kotlin/AGPL Spotube code was copied into this BlackHole/Jotify source. The existing repository has a GPL-3.0 root LICENSE while some upstream source headers cite LGPL-3.0-or-later; this pre-existing discrepancy requires a proper license review before redistribution. Preserve all original license and attribution files, and review obligations before distribution. No API keys are shipped in the ZIP.
