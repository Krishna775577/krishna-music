> Archive: this file describes previous versions. See README.md for the current Saavn-only V6 release.

# Jotify Premium UI & Themes (2026-11-21)

This package builds on the previous **Jotify-Rebranded-Complete-Source** (not the original BlackHole ZIP).

## Added
- Modernized dark/light material theme, more spacious surfaces and rounded cards.
- Seven one-tap looks: Jotify Green, AMOLED Black, Violet Pulse, Ocean Night, Rose Gold, Sunset, Pearl Light.
- Original advanced accent, gradient and user-saved theme editor retained under **Classic**.
- Compact, fixed-height animated bottom navigation, designed to avoid narrow-screen overflow.
- Polished Home greeting/search field, compact now-playing strip and rounded album artwork.
- Player album-color extraction is performed once per artwork instead of every playback rebuild.

## Safeguards
- No changes to Saavn, YouTube, YtMusic APIs or audio streaming code.
- No new Flutter/Dart dependency. Existing Jotify branding, custom name/logo settings and attribution preserved.
- Code-level scans only; Flutter/Dart SDK and Android emulator are not installed in this environment, so APK compilation and frame-time performance are NOT independently verified.
- If using the existing `import-and-build.yml` workflow, upload only `krishna-music-source-ready.zip` to the repository root; the workflow overlays the files. Alternatively, upload the unzipped full project contents from the Full Source ZIP to a fresh repository.
- Keep the earlier working repository as backup until a fresh APK passes build and smoke tests.

## Test checklist
1. Settings → Themes → select each preset and restart the app; ensure the preset persists.
2. Settings → Themes → Classic; confirm old custom gradient/accent and saved theme controls work.
3. Home, search, Library and YouTube tabs on 360 px wide device: no `BOTTOM OVERFLOWED` warnings.
4. Saavn search/play/next/pause and YouTube video screen still open correctly.
5. Test scrolling on a release/profile APK rather than debug when measuring animation smoothness.
