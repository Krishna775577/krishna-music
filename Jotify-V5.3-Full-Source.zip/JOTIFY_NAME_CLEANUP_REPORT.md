# Jotify — Name cleanup and compatibility report

This package uses **Jotify** as the user-facing music-app name and **Krishna Bajaj** as the developer/customizer display name.

## Corrected in this update
- Login/onboarding large `Black Hole Music` heading is now `Jotify Music`.
- Settings About display is Jotify-branded; original author identity remains in the original source credits.
- Android widget class and the widget's active XML references use Jotify names.
- macOS DMG packaging title and filename use Jotify.
- Translated README product headings and Jotify package description updated.
- Original custom app name/icon, premium themes, Saavn, YouTube, YtMusic and playback code were not otherwise modified.

## Original author and license (must remain accurate)
Jotify is based on the open-source **BlackHole** project, originally authored by **Ankit Sangwan**. The original source copyright/license headers and historical attribution are retained unchanged. **Krishna Bajaj** is credited for the Jotify customization, not retroactively claimed as author of the original code.

## Preserved technical identifiers (intentional)
- `com.shadow.blackhole`: Android package/application identity, Kotlin namespace, notification channel and legacy file-provider paths. Changing it would create a different Android app and can make existing local data inaccessible.
- `BlackHole/Database` and related Hive data paths: kept to let existing installs and persisted playlists/settings continue to load. New backup folder labels are Jotify, while older names remain readable.
- `blackhole://` and some historic deep-link aliases: older OAuth/deep-link configurations may rely on them; `jotify://` alias is already registered for app links. Re-register Spotify redirect URIs before changing OAuth callbacks.
- Original Firebase project identifiers in `GoogleService-Info.plist`: these identify actual external resources and cannot be renamed like ordinary labels.
- Original GitHub `Sangwan5688/BlackHole` copyright/source URLs and GPL license text.

## Build verification
- Source and ZIP structure checked locally.
- Flutter SDK was unavailable in this environment, so **APK compilation and in-app runtime have not been tested**. GitHub Actions build is still required.
