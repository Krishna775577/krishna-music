# Jotify V5.1 — YouTube / YtMusic Playback Repair

## Scope
- Replaces only `lib/Screens/YouTube/official_youtube_player.dart`, and adds explicit Flutter-3.19 compatible WebView dependencies in `pubspec.yaml`.
- Keeps V5 Saavn, Lyrics Studio 3.0, downloads, local library, Hive boxes, and app identity unchanged.
- Uses a **visible official YouTube IFrame Player API** embedded into Android WebView. The HTML has `baseUrl: https://com.shadow.blackhole/`, matching the unchanged installed Android package id, instead of an anonymous `about:blank` iframe.
- Captures player ready, playback state, duration, progress, error codes and updates seek/play/skip buttons.
- Stall timer starts **only after Play / buffering**; no false 00:00 timeout when video is merely cued.
- Retry clears state and reconstructs the iframe, and `Alternate embed` navigates directly to `youtube.com/embed` with the installed app identifier HTTP `Referer` header. This fallback uses YouTube's native controls.
- Errors 2, 5, 100, 101/150, and 153 show human-readable explanations. If a video disallows embedding, use `Open official YouTube`; do not bypass publisher restrictions.
- Origin Island is explicitly outside this release.

## Critical compatibility
- Do **not** replace these two pinned deps with newest `youtube_player` 4.x. It requires Dart 3.14 / Flutter 3.50. This project uses Flutter 3.19.6 / Dart 3.3.4.
- Pinned packages: `webview_flutter: 4.7.0`, `webview_flutter_android: 3.15.0`.
- Do **not** change Android applicationId `com.shadow.blackhole` just to remove the text: it would break existing installs and change the YouTube client identity.
- Existing `youtube_player_iframe: 4.0.4` is kept so other project dependencies/integration are not disturbed.
- User interaction may still be required by YouTube policy; no autoplay or playback of restricted/non-embeddable videos is guaranteed.

## GitHub installation
1. On `Krishna775577/krishna-music` replace the old `krishna-music-source-ready.zip` with the V5.1 overlay ZIP, then commit.
2. Run `.github/workflows/import-and-build.yml` on GitHub Actions. It extracts the ZIP overlay and builds the APK.
3. If `flutter pub get` fails, verify the pinned dependency versions and do not upgrade to incompatible latest packages.
4. Download APK artifact, preserve the V5 backup and install on vivo V50. Existing app data should remain because app id and database paths are untouched.

## Device test — vivo V50 / OriginOS 6
1. V5.1 launches; Saavn searches and plays (sanity test).
2. Lyrics Studio 3.0 online lyrics and local `.lrc` (sanity test).
3. Play a known **embeddable public** YouTube video. Tap Play within the video; verify duration >00:00 and progress increasing.
4. Test seek forward/back and Pause/Resume; wait longer than 20 seconds to ensure the stall alert does not trigger during pause.
5. Test YouTube Music item. Some music videos may be restricted by their publisher; classify embedding restriction separately from a player error.
6. Test Wi-Fi and mobile data. If iframe does not start, tap `Alternate embed` and try native embedded controls.
7. If error 153 persists in both modes, capture its visible code and Android System WebView version; this points to client-identity and WebView behavior rather than a Saavn problem.
8. If error 101/150, use the official YouTube button; do not attempt a bypass.
9. Verify Next/Previous updates title and queue; in alternate mode manual native player controls are used.
10. Restart app and verify all V5 settings and saved playlists remain intact.

## Test/verification status
- ZIP integrity and import/path static checks: performed locally.
- `flutter pub get`, `flutter analyze`, APK build, and real device playback: **not executed** in this environment. The changes are a test build, NOT confirmed working.
