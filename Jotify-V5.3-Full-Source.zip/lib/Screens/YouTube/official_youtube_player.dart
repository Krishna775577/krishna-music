/*
 * Jotify V5.3 YouTube/YtMusic player and queue UX repair.
 * Original BlackHole author copyright and license remain in the project.
 * Official, visible YouTube iframe with an OS app-id referrer.
 * No media extraction, hidden playback, or background video tricks.
 */
import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:webview_flutter_android/webview_flutter_android.dart';

@immutable
class KrishnaYoutubeTrack {
  final String videoId;
  final String title;
  final String artist;

  const KrishnaYoutubeTrack({
    required this.videoId,
    required this.title,
    this.artist = '',
  });
}

class OfficialYouTubePlayerPage extends StatefulWidget {
  final String videoId;
  final String title;
  final String artist;
  final List<KrishnaYoutubeTrack> queue;
  final int initialIndex;

  const OfficialYouTubePlayerPage({
    super.key,
    required this.videoId,
    required this.title,
    this.artist = '',
    this.queue = const [],
    this.initialIndex = 0,
  });

  @override
  State<OfficialYouTubePlayerPage> createState() =>
      _OfficialYouTubePlayerPageState();
}

class _OfficialYouTubePlayerPageState extends State<OfficialYouTubePlayerPage> {
  static const Color _background = Color(0xFF101114);
  static const Color _accent = Color(0xFF1ED760);
  // This is Jotify's *installed* Android applicationId; retain to keep old
  // installs compatible. Per YouTube embed requirements, do not spoof another
  // app's identity or use an unrelated website as referrer.
  static const String _appReferer = 'https://com.shadow.blackhole/';
  static const String _appOrigin = 'https://com.shadow.blackhole';
  static final RegExp _validVideoId = RegExp(r'^[A-Za-z0-9_-]{11}$');

  late final WebViewController _web;
  late final List<KrishnaYoutubeTrack> _queue;
  int _index = 0;
  int _stateCode = -1;
  int? _youtubeError;
  Timer? _startTimer;
  Timer? _initTimer;
  bool _webReady = false;
  bool _attempted = false;
  bool _showHelp = false;
  // Prefer YouTube's native embed controls. The older scripted iframe is kept
  // as an optional diagnostic mode because it may produce 152-4 in WebViews.
  bool _directEmbed = true;
  bool _usePrivacyHost = false;
  bool _pageLoading = true;
  String? _loadError;
  double _position = 0;
  double _duration = 0;

  KrishnaYoutubeTrack get _current => _queue[_index];

  @override
  void initState() {
    super.initState();
    final valid = widget.queue
        .where((item) => _validVideoId.hasMatch(item.videoId))
        .toList();
    _queue = valid.isEmpty
        ? <KrishnaYoutubeTrack>[
            KrishnaYoutubeTrack(videoId: widget.videoId,
                title: widget.title, artist: widget.artist),
          ]
        : valid;
    _index = widget.initialIndex.clamp(0, _queue.length - 1).toInt();
    _web = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.black)
      ..setNavigationDelegate(NavigationDelegate(
        onPageFinished: (url) {
          if (!mounted || !_directEmbed) return;
          setState(() => _pageLoading = false);
        },
        onWebResourceError: (error) {
          // Subresource errors (artwork, tracking etc.) must not stop playback.
          if (error.isForMainFrame != true || !mounted) return;
          setState(() {
            _loadError = 'WebView: ${error.description}';
            _pageLoading = false;
          });
        },
      ));
    unawaited(_initializeWebView());
  }

  Future<void> _initializeWebView() async {
    try {
      // Register the JS bridge before loading a page, otherwise the iframe
      // could become ready before Flutter starts listening for it.
      await _web.setJavaScriptMode(JavaScriptMode.unrestricted);
      await _web.setBackgroundColor(Colors.black);
      if (_web.platform is AndroidWebViewController) {
        await (_web.platform as AndroidWebViewController)
            .setMediaPlaybackRequiresUserGesture(false);
      }
      await _web.addJavaScriptChannel('JotifyBridge',
          onMessageReceived: (message) => _onPlayerMessage(message.message));
      if (mounted) await _loadCurrent(direct: true);
    } catch (error) {
      if (mounted) setState(() {
        _pageLoading = false;
        _loadError = 'WebView initialization failed: $error';
      });
    }
  }

  void _onPlayerMessage(String message) {
    if (!mounted || _directEmbed) return;
    Map<String, dynamic> event;
    try {
      event = Map<String, dynamic>.from(jsonDecode(message) as Map);
    } catch (_) {
      return;
    }
    final kind = event['type'];
    if (kind == 'ready') {
      _initTimer?.cancel();
      setState(() {
        _webReady = true;
        _pageLoading = false;
        _loadError = null;
      });
    } else if (kind == 'state') {
      final code = (event['code'] as num?)?.toInt() ?? -1;
      if (code == 1) {
        _attempted = true;
        _startTimer?.cancel();
      } else if (code == 3 && _attempted) {
        _armStallTimer();
      } else if (code == 2 || code == 5 || code == 0) {
        _startTimer?.cancel();
      }
      setState(() { _stateCode = code; _showHelp = false; });
      if (code == 0 && _index < _queue.length - 1) {
        // Completion from the official player, not a network timeout.
        _changeTrack(_index + 1);
      }
    } else if (kind == 'error') {
      _startTimer?.cancel();
      _initTimer?.cancel();
      setState(() {
        _youtubeError = (event['code'] as num?)?.toInt();
        _pageLoading = false;
        _showHelp = true;
      });
    } else if (kind == 'progress') {
      final current = (event['position'] as num?)?.toDouble() ?? 0;
      final duration = (event['duration'] as num?)?.toDouble() ?? 0;
      if (current.isFinite && duration.isFinite && mounted) {
        setState(() {
          _position = current.clamp(0.0, duration > 0 ? duration : 0.0).toDouble();
          _duration = duration > 0 ? duration : 0;
        });
      }
    }
  }

  String _htmlFor(String id) {
    // id is always validated before interpolation. The HTML has a real app-id
    // base URL, instead of being loaded from about:blank; the iframe can send
    // an appropriate referrer in compliant WebViews.
    return '''<!doctype html>
<html lang="en"><head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1" />
<meta name="referrer" content="strict-origin-when-cross-origin" />
<style>
html,body{margin:0;background:#000;color:#fff;overflow:hidden;width:100%;height:100%;}
#player{width:100vw;height:100vh;} iframe{width:100%;height:100%;border:0;}
</style></head><body><div id="player"></div>
<script>
(function(){
  var player=null, ready=false;
  function send(type,data){try{JotifyBridge.postMessage(JSON.stringify(Object.assign({type:type},data||{})));}catch(e){}}
  window.onYouTubeIframeAPIReady=function(){
    try {
      player=new YT.Player('player',{
        videoId:'$id', width:'100%', height:'100%',
        playerVars:{controls:1,fs:1,playsinline:1,rel:0,origin:'$_appOrigin'},
        events:{
          onReady:function(){ready=true;send('ready');},
          onStateChange:function(e){send('state',{code:e.data});},
          onError:function(e){send('error',{code:e.data});}
        }
      });
    }catch(e){send('error',{code:-2});}
  };
  window.jotifyCommand=function(command,value){
    if(!ready||!player){send('notReady');return;}
    try{
      if(command==='play')player.playVideo();
      else if(command==='pause')player.pauseVideo();
      else if(command==='stop')player.stopVideo();
      else if(command==='seek')player.seekTo(Number(value)||0,true);
    }catch(e){send('error',{code:-3});}
  };
  setInterval(function(){
    if(!ready||!player)return;
    try {send('progress',{position:player.getCurrentTime()||0,duration:player.getDuration()||0});}
    catch(e){}
  },1200);
})();
</script>
<script src="https://www.youtube.com/iframe_api"></script>
</body></html>''';
  }

  Future<void> _loadCurrent({bool direct = true}) async {
    _startTimer?.cancel();
    _initTimer?.cancel();
    if (!mounted) return;
    setState(() {
      _webReady = false;
      _attempted = false;
      _showHelp = false;
      _youtubeError = null;
      _loadError = null;
      _stateCode = -1;
      _position = 0;
      _duration = 0;
      _directEmbed = direct;
      _pageLoading = true;
    });
    if (!_validVideoId.hasMatch(_current.videoId)) {
      setState(() { _loadError = 'Invalid YouTube video ID'; _pageLoading = false; });
      return;
    }
    try {
      if (direct) {
        // Official documented direct-embed WebView configuration. Native
        // YouTube controls are used in this mode, not Jotify JS controls.
        await _web.loadRequest(
          Uri.https(_usePrivacyHost
              ? 'www.youtube-nocookie.com'
              : 'www.youtube.com', '/embed/${_current.videoId}',
            {'playsinline':'1','controls':'1','fs':'1','rel':'0'}),
          headers: const <String, String>{'Referer': _appReferer},
        );
      } else {
        await _web.loadHtmlString(_htmlFor(_current.videoId),
            baseUrl: _appReferer);
      }
      if (!direct) {
        _initTimer = Timer(const Duration(seconds: 18), () {
          if (mounted && !_webReady && _youtubeError == null) {
            setState(() {
              _pageLoading = false;
              _showHelp = true;
              _loadError = 'YouTube iframe did not become ready';
            });
          }
        });
      } else {
        if (mounted) setState(() => _pageLoading = false);
      }
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _pageLoading = false;
        _loadError = 'Player loading failed: $error';
        _showHelp = true;
      });
    }
  }

  void _armStallTimer() {
    _startTimer?.cancel();
    _startTimer = Timer(const Duration(seconds: 20), () {
      if (mounted && _stateCode != 1) {
        setState(() => _showHelp = true);
      }
    });
  }

  Future<void> _command(String action, [double? position]) async {
    if (_directEmbed || !_webReady) return;
    if (action == 'play') {
      _attempted = true;
      _armStallTimer();
    } else if (action == 'pause') {
      _startTimer?.cancel();
    }
    try {
      final encoded = jsonEncode(action);
      final arg = position == null ? 'null' : position.toStringAsFixed(2);
      await _web.runJavaScript('window.jotifyCommand($encoded,$arg);');
    } catch (error) {
      if (!mounted) return;
      setState(() => _loadError = 'Player command failed: $error');
    }
  }

  Future<void> _changeTrack(int next) async {
    if (next < 0 || next >= _queue.length || !mounted) return;
    setState(() => _index = next);
    await _loadCurrent(direct: _directEmbed);
  }

  void _retry() => _loadCurrent(direct: _directEmbed);

  Future<void> _openOfficialYouTube() async {
    final uri = Uri.https('www.youtube.com', '/watch', {'v': _current.videoId});
    try {
      if (!await launchUrl(uri, mode: LaunchMode.externalApplication) && mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('No app available to open YouTube')));
      }
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Could not open official YouTube')));
    }
  }

  String _errorDescription() {
    if (_loadError != null) return _loadError!;
    switch (_youtubeError) {
      case 2: return 'Invalid video parameters (YouTube error 2).';
      case 5: return 'This video cannot play in the HTML5 player (error 5).';
      case 100: return 'Video unavailable or private (YouTube error 100).';
      case 101:
      case 150: return 'The uploader disabled embedded playback (error $_youtubeError).';
      case 153: return 'YouTube needs the app identity/Referer (error 153). Try alternate embed.';
      case -2:
      case -3: return 'YouTube iframe failed to initialize.';
      default:
        return _youtubeError != null
          ? 'YouTube player error $_youtubeError.'
          : 'Playback did not start after 20 seconds.';
    }
  }

  String _status() {
    if (_youtubeError != null || _loadError != null) return _errorDescription();
    if (_pageLoading) return 'Loading official YouTube player…';
    if (_directEmbed) return 'YouTube video: use Play and Seek inside the video';
    switch (_stateCode) {
      case 1: return 'Playing';
      case 2: return 'Paused';
      case 3: return 'Buffering…';
      case 0: return 'Video finished';
      case 5: return 'Ready — tap Play';
      default: return _webReady ? 'Ready — tap Play' : 'Connecting to YouTube…';
    }
  }

  String _clock(double seconds) {
    final duration = Duration(seconds: seconds.isFinite ? seconds.toInt() : 0);
    final minutes = duration.inMinutes;
    final secs = duration.inSeconds.remainder(60);
    return '$minutes:${secs.toString().padLeft(2, '0')}';
  }

  @override
  void dispose() {
    _startTimer?.cancel();
    _initTimer?.cancel();
    // Stop playback when leaving this page; WebView itself belongs to its widget.
    if (_webReady && !_directEmbed) {
      unawaited(_web.runJavaScript('window.jotifyCommand("stop",null);')
          .catchError((Object _) {}));
    } else if (_directEmbed) {
      unawaited(_web.loadHtmlString('<html><body style="background:black"></body></html>')
          .catchError((Object _) {}));
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final playing = _stateCode == 1;
    return Scaffold(
      backgroundColor: _background,
      appBar: AppBar(
        title: const Text('Jotify V5.3 · Video', style: TextStyle(fontWeight: FontWeight.w700)),
        foregroundColor: Colors.white,
        backgroundColor: _background,
      ),
      body: SafeArea(
        child: ListView(
          children: <Widget>[
            AspectRatio(
              aspectRatio: 16/9,
              child: Stack(
                children: <Widget>[
                  ColoredBox(
                    color: Colors.black,
                    child: SizedBox.expand(child: WebViewWidget(controller: _web)),
                  ),
                  if (_pageLoading)
                    const Positioned(
                      bottom: 0, left: 0, right: 0,
                      child: LinearProgressIndicator(minHeight: 2, color: _accent),
                    ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 20, 18, 4),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(_current.title, maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: Colors.white,
                      fontSize: 22, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 4),
                  Text(_current.artist.isEmpty ? 'YouTube video' : _current.artist,
                    maxLines: 1, overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: Colors.white70)),
                  const SizedBox(height: 12),
                  Text(_status(), style: TextStyle(
                    color: _youtubeError != null || _loadError != null
                        ? Colors.orangeAccent : _accent,
                    fontSize: 13)),
                ],
              ),
            ),
            if (!_directEmbed) ...<Widget>[
              if (_duration > 0) ...<Widget>[
                Slider(
                  min: 0, max: _duration,
                  value: _position.clamp(0.0, _duration).toDouble(),
                  activeColor: _accent,
                  onChanged: (pos) => setState(() => _position = pos),
                  onChangeEnd: (pos) => _command('seek', pos),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 22),
                  child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(_clock(_position), style: const TextStyle(color: Colors.white70)),
                      Text(_clock(_duration), style: const TextStyle(color: Colors.white70)),
                    ]),
                ),
              ],
              Row(mainAxisAlignment: MainAxisAlignment.center, children: <Widget>[
                IconButton(
                  tooltip: 'Previous', color: Colors.white, iconSize: 36,
                  icon: const Icon(Icons.skip_previous_rounded),
                  onPressed: _index > 0 ? () => _changeTrack(_index - 1) : null),
                const SizedBox(width: 12),
                IconButton(
                  tooltip: playing ? 'Pause' : 'Play', iconSize: 54,
                  color: _accent,
                  icon: Icon(playing ? Icons.pause_circle_filled_rounded
                      : Icons.play_circle_fill_rounded),
                  onPressed: _webReady ? () => _command(playing ? 'pause' : 'play') : null),
                const SizedBox(width: 12),
                IconButton(
                  tooltip: 'Next', color: Colors.white, iconSize: 36,
                  icon: const Icon(Icons.skip_next_rounded),
                  onPressed: _index < _queue.length - 1
                      ? () => _changeTrack(_index + 1) : null),
              ]),
            ] else ...<Widget>[
              // Direct embeds own playback/seek; Jotify still owns its queue.
              // Switching tracks reloads a new official YouTube embed.
              if (_queue.length > 1)
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    IconButton(
                      tooltip: 'Previous video',
                      color: Colors.white,
                      iconSize: 34,
                      icon: const Icon(Icons.skip_previous_rounded),
                      onPressed: _index > 0
                          ? () => _changeTrack(_index - 1)
                          : null,
                    ),
                    const SizedBox(width: 28),
                    IconButton(
                      tooltip: 'Next video',
                      color: Colors.white,
                      iconSize: 34,
                      icon: const Icon(Icons.skip_next_rounded),
                      onPressed: _index < _queue.length - 1
                          ? () => _changeTrack(_index + 1)
                          : null,
                    ),
                  ],
                ),
              const Padding(
                padding: EdgeInsets.all(14),
                child: Text('Play, pause and seek using the YouTube video controls. '
                    'Jotify Previous/Next changes videos; auto-next is available in iframe mode.',
                  style: TextStyle(color: Colors.white70),
                  textAlign: TextAlign.center),
              ),
            ],
            if (_directEmbed)
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 18, vertical: 5),
                child: Text(
                  'Error 152-4 may indicate WebView embed identity/compatibility or a video restriction. '
                  'Try the other official embed below. Some videos only play in the YouTube app.',
                  style: TextStyle(color: Colors.white60, fontSize: 12),
                  textAlign: TextAlign.center,
                ),
              ),
            if (_showHelp || _youtubeError != null || _loadError != null)
              Padding(
                padding: const EdgeInsets.fromLTRB(18, 8, 18, 6),
                child: Text(_errorDescription(), textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.orangeAccent)),
              ),
            Wrap(
              alignment: WrapAlignment.center,
              spacing: 6, runSpacing: 0,
              children: <Widget>[
                TextButton.icon(
                  onPressed: _retry, icon: const Icon(Icons.refresh),
                  label: const Text('Retry')),
                TextButton.icon(
                  onPressed: () => _loadCurrent(direct: !_directEmbed),
                  icon: const Icon(Icons.smart_display_outlined),
                  label: Text(_directEmbed ? 'Try Jotify iframe controls' : 'Use native YouTube controls')),
                if (_directEmbed)
                  TextButton.icon(
                    onPressed: () {
                      _usePrivacyHost = !_usePrivacyHost;
                      _loadCurrent(direct: true);
                    },
                    icon: const Icon(Icons.swap_horiz_rounded),
                    label: Text(_usePrivacyHost
                      ? 'Try regular YouTube embed'
                      : 'Try privacy-enhanced embed')),
                TextButton.icon(
                  onPressed: _openOfficialYouTube,
                  icon: const Icon(Icons.open_in_new),
                  label: const Text('Open official YouTube')),
              ],
            ),
            if (_queue.length > 1) ...<Widget>[
              const Divider(color: Color(0xFF333333)),
              const Padding(
                padding: EdgeInsets.fromLTRB(18, 8, 18, 8),
                child: Text('Up next', style: TextStyle(
                  color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
              ),
              ...List<Widget>.generate(_queue.length, (i) {
                final track = _queue[i];
                return ListTile(
                  dense: true,
                  selected: i == _index,
                  selectedColor: _accent,
                  leading: Icon(i == _index ? Icons.equalizer_rounded
                      : Icons.play_arrow_rounded,
                    color: i == _index ? _accent : Colors.white70),
                  title: Text(track.title, maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: Colors.white)),
                  subtitle: Text(track.artist, maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: Colors.white54)),
                  onTap: () => _changeTrack(i),
                );
              }),
            ],
            const SizedBox(height: 28),
          ],
        ),
      ),
    );
  }
}
