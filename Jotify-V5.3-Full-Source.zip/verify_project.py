from pathlib import Path
import re
R=Path(__file__).resolve().parent
read=lambda name: (R/name).read_text(encoding="utf-8")
root=read("android/build.gradle")
app=read("android/app/build.gradle")
pub=read("pubspec.yaml")
manifest=read("android/app/src/main/AndroidManifest.xml")
player=read("lib/Screens/YouTube/official_youtube_player.dart")
nav=read("lib/Services/youtube_embed_navigation.dart")
auth=read("lib/Screens/Login/auth.dart")
assert not re.search(r"(?m)^\s*apply\s+plugin:\s*['\"]com\.android\.application", root)
assert "classpath 'com.android.tools.build:gradle:7.4.2'" in root
assert "apply plugin: 'com.android.application'" in app
assert 'compileSdkVersion 34' in app
assert re.search(r'(?m)^version: 1\.16\.3\+45$', pub)
assert 'android:label="Jotify"' in manifest
assert 'Jotify V5.3 · Build 45' in auth
assert "text: 'Jotify\\n'" in auth or "text: 'Jotify\n'" in auth
assert 'OfficialYouTubePlayerPage(' in nav and 'queue:' in nav
assert "headers: const <String, String>{'Referer': _appReferer}" in player
assert "_appReferer = 'https://com.shadow.blackhole/'" in player
assert 'www.youtube-nocookie.com' in player
assert "_loadCurrent(direct: !_directEmbed)" in player
assert 'Previous video' in player and 'Next video' in player
assert 'Jotify V5.3 · Video' in player
assert "Open official YouTube" in player
# Intentionally preserve app ID/database paths for in-place upgrade and playlists.
assert 'applicationId "com.shadow.blackhole"' in app
assert "Hive.initFlutter('BlackHole/Database')" in read('lib/main.dart')
print('PASS: branding, source-level player options, referrer, Android identity compatibility.')
print('NOTE: this is NOT a compiled Flutter APK or a playback-on-device test.')
