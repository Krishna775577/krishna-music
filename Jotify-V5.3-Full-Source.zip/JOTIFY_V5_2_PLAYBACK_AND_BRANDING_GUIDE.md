# Jotify V5.2 — YouTube error 152-4 + Branding/build mismatch

## What the screenshots prove
- The APK screenshot shows `Krishna Music` and `Black Hole Music`.
- This V5.2 source shows `Jotify V5.2 · Video`, `Jotify Music`, and a **Jotify V5.2 · Build 44** label on the welcome screen.
- Therefore the screenshot appears to come from **an older APK**, not the current source. Without verifying the build, changing code alone won't resolve the stale APK problem.

## Changes in V5.2
- Make the official **direct YouTube embed** the default. Flutter WebView sends `Referer: https://com.shadow.blackhole/` in the main navigation, using the app's actual installed Android ID. (This internal ID must not be renamed unless doing a full app migration.)
- Add a privacy-enhanced official YouTube embed as a second option, and retain the old Jotify scripted iframe as an optional diagnostic mode.
- Show a message explaining error 152-4 may be caused by embedded-player compatibility/identity, and offer opening the video in the official YouTube app as a last resort.
- Player title now visibly shows `Jotify V5.2 · Video`. The welcome screen shows `Jotify Music` with `Jotify V5.2 · Build 44` underneath. `pubspec.yaml` is now `1.16.2+44`.
- Existing Saavn, Lyrics, V1–V5 features, storage and playlists are unchanged.

## Critical caveat: cannot guarantee YouTube embed playback
YouTube determines which videos can play in embedded players. Error 152-4 has also been reported with otherwise public videos inside Android WebViews. Supplying the actual installed app ID Referer follows the official requirements but may not solve every video/device. We don't bypass these restrictions by extracting streams, spoofing a third-party app, or playing hidden audio.

## GitHub install steps
1. Upload/replace `krishna-music-source-ready.zip` at the **root** of `Krishna775577/krishna-music`, commit to `main`.
2. Go to `Actions` → `Import ZIP and Build Android APK` → `Run workflow` (**main**).
3. Check the `Import optional ZIP...` log says **Found ZIP overlay. Importing safe app files**. It should commit a change containing `pubspec.yaml` version 1.16.2+44. If log says `No ZIP overlay found`, this update **did not import**.
4. Download **app-debug.apk from this new workflow run**, not an old artifact. Preserve old APK/backups. Install over same package ID; if update installation is rejected due to signing key mismatch, backup app data before any uninstall and install the new APK.
5. Open welcome screen (if shown) and check the **Jotify V5.2 · Build 44** stamp. Open YouTube tab and check player title **Jotify V5.2 · Video**. If absent, old app/source was used.
6. Test known public embeddable video: regular embed → privacy-enhanced embed → Jotify iframe controls, in that order. Check Play/Seek and 00:00. Videos blocked by YouTube can't be forced to play in an embed.
7. Confirm Saavn still plays, online/imported lyrics still show, and settings/playlists survive restart. Check Wi-Fi and mobile data.

## Validation performed / not performed
- Performed: source file, package version, XML and ZIP/path integrity checks.
- Not available here: Flutter SDK / Android build, on-device video and WebView tests. This is **test code**, not a confirmed video playback fix.
- Original author's copyright notices and legacy app IDs were preserved as legally and technically necessary.
