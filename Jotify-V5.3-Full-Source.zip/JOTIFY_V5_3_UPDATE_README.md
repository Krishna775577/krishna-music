# Jotify V5.3 — Error 152-4 / stale APK / brand update

## What's fixed in the source
- App welcome screen explicitly reads **Jotify Music** with **Jotify V5.3 · Build 45**; Android app display name remains **Jotify**.
- YouTube page explicitly reads **Jotify V5.3 · Video** so the installed APK version is visible.
- Default YouTube playback uses official WebView direct embed with a Referer that identifies the app's **actual installed Android application ID**. This is consistent with YouTube's embedded-player identity guidance.
- Alternate official privacy-enhanced embed and official IFrame API modes remain available. Direct mode now retains Jotify queue Previous/Next navigation (no auto-next: direct mode cannot observe playback-complete reliably).
- Existing JioSaavn, lyrics, playlists, settings, and downloads were not edited.

## Important: error 152-4 is not guaranteed resolved
YouTube may reject some videos or WebView configurations. The YouTube iframe and YouTube itself decide what embeds are allowed. Jotify does not use prohibited stream extraction or hidden audio-only video playback.

## Safe GitHub update
1. On GitHub repo `Krishna775577/krishna-music`, put the supplied `krishna-music-source-ready.zip` at the repo ROOT (overwrite older one). Commit the file to the `main` branch.
2. Actions → `Import ZIP and Build Android APK` → Run workflow on `main`.
3. In the workflow logs look for `Found ZIP overlay. Importing safe app files`, and verify `pubspec.yaml` version is **1.16.3+45** in your newly committed source. Without that line, the new source was NOT imported.
4. Download the APK from the MOST RECENT run. Artifact may still be named `krishna-music-debug-apk` because the existing GitHub workflow retains its old artifact name, but installed Android label is **Jotify**.
5. Prefer installing over existing app to retain data. If Android rejects due to signing key mismatch, back up playlists/data before uninstalling.
6. Open player. Check **Jotify V5.3 · Video**. Test official embed first, then privacy-enhanced embed and Jotify IFrame mode.

## Why the internal string `com.shadow.blackhole` remains
It is the existing installed Android package ID, also used for deep links and persisted data paths. Renaming it blindly breaks upgrades. The name visible to the user is Jotify; these internal identity and legacy copyright strings are not the app branding.

## Validation
Source-level assertions run; Flutter SDK/Android runtime are unavailable in this environment, so APK build and on-device YouTube 152-4 playback remain unverified.
