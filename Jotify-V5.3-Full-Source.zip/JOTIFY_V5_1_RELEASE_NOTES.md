# Jotify V5.1 — Release Notes

Playback-only hotfix: official visible YouTube IFrame API on an identified app-origin WebView; correct 00:00 stall/Retry behavior, playback state and seek monitoring, YouTube error codes and direct-embed fallback. Does not extract audio or modify V5 Saavn/Lyrics. Flutter-3.19 compatible dependency pins. APK/device verification pending.
